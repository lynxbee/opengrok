# This is a special exit code that is recognized by sync.py to terminate
# the processing of the command sequence.
CONTINUE_EXITVAL = 2
SUCCESS_EXITVAL = 0
FAILURE_EXITVAL = 1
