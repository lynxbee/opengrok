<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304773331000</long>
      </object>
     </void>
     <void property="message">
      <string>Added shell script to drive the execution of the app</string>
     </void>
     <void property="revision">
      <string>f5ed0195</string>
     </void>
     <void property="tags">
      <string>RELEASE_1.1, RELEASE_1.0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
