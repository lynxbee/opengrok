<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Peter Bell &lt;peter@pbell.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1371584078000</long>
      </object>
     </void>
     <void property="message">
      <string>Even I can change the readme file</string>
     </void>
     <void property="revision">
      <string>a13dba1e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1305228112000</long>
      </object>
     </void>
     <void property="message">
      <string>Added text about image diff example</string>
     </void>
     <void property="revision">
      <string>8d2636da</string>
     </void>
     <void property="tags">
      <string>RELEASE_1.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1227586921000</long>
      </object>
     </void>
     <void property="message">
      <string>Addition of the README and basic Groovy source samples.
    
    - Addition of the README.txt file explaining what this repository is all about.
    - Addition of Groovy sample source.
    - Addition of sample resource Properties file.</string>
     </void>
     <void property="revision">
      <string>755fd577</string>
     </void>
     <void property="tags">
      <string>RELEASE_1.0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
