<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304775579000</long>
      </object>
     </void>
     <void property="message">
      <string>Added sum function and test call</string>
     </void>
     <void property="revision">
      <string>333fd9bc</string>
     </void>
     <void property="tags">
      <string>RELEASE_1.1, RELEASE_1.0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
