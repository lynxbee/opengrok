<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304788364000</long>
      </object>
     </void>
     <void property="message">
      <string>Removing subtraction from the division line of code</string>
     </void>
     <void property="revision">
      <string>57d0bf61</string>
     </void>
     <void property="tags">
      <string>RELEASE_1.1, RELEASE_1.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304775865000</long>
      </object>
     </void>
     <void property="message">
      <string>Added subtract feature</string>
     </void>
     <void property="revision">
      <string>cb2d322b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304786552000</long>
      </object>
     </void>
     <void property="message">
      <string>Added call and import for subtraction</string>
     </void>
     <void property="revision">
      <string>818f033c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304786222000</long>
      </object>
     </void>
     <void property="message">
      <string>Used static imports to simpify the math calls</string>
     </void>
     <void property="revision">
      <string>369adba0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304786168000</long>
      </object>
     </void>
     <void property="message">
      <string>Removed unused Square class import</string>
     </void>
     <void property="revision">
      <string>2956e1d2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304775579000</long>
      </object>
     </void>
     <void property="message">
      <string>Added sum function and test call</string>
     </void>
     <void property="revision">
      <string>333fd9bc</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304773196000</long>
      </object>
     </void>
     <void property="message">
      <string>Refactored squaring into a separate class</string>
     </void>
     <void property="revision">
      <string>dc64fe4a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1304772677000</long>
      </object>
     </void>
     <void property="message">
      <string>Added sqaring method</string>
     </void>
     <void property="revision">
      <string>32c27378</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Matthew McCullough &lt;matthewm@ambientideas.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1227586921000</long>
      </object>
     </void>
     <void property="message">
      <string>Addition of the README and basic Groovy source samples.
    
    - Addition of the README.txt file explaining what this repository is all about.
    - Addition of Groovy sample source.
    - Addition of sample resource Properties file.</string>
     </void>
     <void property="revision">
      <string>755fd577</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
