<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575298787000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix volume paths in docker readme
    
    While trying the examples in the readme I&apos;ve noticed the following errors:
    ```
    docker: Error response from daemon: create ~/opengrok-src/: &quot;~/opengrok-src/&quot; includes invalid characters for a local volume name, only &quot;[a-zA-Z0-9][a-zA-Z0-9_.-]&quot; are allowed. If you intended to pass a host directory, use absolute path.
    ```
    and
    ```
    docker: Error response from daemon: invalid volume specification: &apos;/Users/ahornace/opengrok-data/:opengrok/data&apos;: invalid mount config for type &quot;bind&quot;: invalid mount path: &apos;opengrok/data&apos; mount path must be absolute.
    ```
    Thanks.</string>
     </void>
     <void property="revision">
      <string>0b7e6c83</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575040088000</long>
      </object>
     </void>
     <void property="message">
      <string>Update docker readme
    
    I meant to do this change but I&apos;ve totally forgot about it :/
    
    Sorry of the inconvenience.
    
    Thanks.</string>
     </void>
     <void property="revision">
      <string>a321215d</string>
     </void>
     <void property="tags">
      <string>1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Shenghan Gao &lt;shenghang@nvidia.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565225926000</long>
      </object>
     </void>
     <void property="message">
      <string>change docker/readme.md
    
    add infomation about mount data folder and config folder</string>
     </void>
     <void property="revision">
      <string>64c0a233</string>
     </void>
     <void property="tags">
      <string>1.3.4, 1.3.3, 1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565163646000</long>
      </object>
     </void>
     <void property="message">
      <string>Try to use mvnw in CI</string>
     </void>
     <void property="revision">
      <string>86b0ab6b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564745178000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix docker readme typo</string>
     </void>
     <void property="revision">
      <string>a391bead</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563531391000</long>
      </object>
     </void>
     <void property="message">
      <string>document docker-compose</string>
     </void>
     <void property="revision">
      <string>33551f14</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563530669000</long>
      </object>
     </void>
     <void property="message">
      <string>document env vars properly</string>
     </void>
     <void property="revision">
      <string>15936b04</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562269823000</long>
      </object>
     </void>
     <void property="message">
      <string>fix formatting</string>
     </void>
     <void property="revision">
      <string>703bf669</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562269799000</long>
      </object>
     </void>
     <void property="message">
      <string>add more details</string>
     </void>
     <void property="revision">
      <string>bc2f6de0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562269646000</long>
      </object>
     </void>
     <void property="message">
      <string>add headline</string>
     </void>
     <void property="revision">
      <string>ab135123</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562268170000</long>
      </object>
     </void>
     <void property="message">
      <string>add SCMs</string>
     </void>
     <void property="revision">
      <string>84ed967b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561973874000</long>
      </object>
     </void>
     <void property="message">
      <string>add tag table</string>
     </void>
     <void property="revision">
      <string>eea6103d</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561816570000</long>
      </object>
     </void>
     <void property="message">
      <string>on tagging</string>
     </void>
     <void property="revision">
      <string>f70822c2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561750421000</long>
      </object>
     </void>
     <void property="message">
      <string>add microbadges</string>
     </void>
     <void property="revision">
      <string>e2736ff6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561731377000</long>
      </object>
     </void>
     <void property="message">
      <string>remove Travis status</string>
     </void>
     <void property="revision">
      <string>535bbb66</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561720413000</long>
      </object>
     </void>
     <void property="message">
      <string>fix formatting</string>
     </void>
     <void property="revision">
      <string>70960cd9</string>
     </void>
     <void property="tags">
      <string>1.2.20, 1.2.19, 1.2.18</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561719524000</long>
      </object>
     </void>
     <void property="message">
      <string>revert to fetcher</string>
     </void>
     <void property="revision">
      <string>6670a14a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561718535000</long>
      </object>
     </void>
     <void property="message">
      <string>rename and add more details</string>
     </void>
     <void property="revision">
      <string>1106ade6</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
