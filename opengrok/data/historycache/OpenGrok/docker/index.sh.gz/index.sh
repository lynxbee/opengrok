<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Lubos Kosco &lt;tarzanek@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569853477000</long>
      </object>
     </void>
     <void property="message">
      <string>Enable leading wildcard by default</string>
     </void>
     <void property="revision">
      <string>5b7cea89</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>ehurtado &lt;ehurtado.open.com.co&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564517659000</long>
      </object>
     </void>
     <void property="message">
      <string>Add --remote on index.sh for activate Historial in the svn repository
    
    fixes #2856</string>
     </void>
     <void property="revision">
      <string>a6cd125f</string>
     </void>
     <void property="tags">
      <string>1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565245425000</long>
      </object>
     </void>
     <void property="message">
      <string>fix wording</string>
     </void>
     <void property="revision">
      <string>6c2a95bb</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Shenghan Gao &lt;shenghang@nvidia.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565227088000</long>
      </object>
     </void>
     <void property="message">
      <string>fix typo on docker/index.sh</string>
     </void>
     <void property="revision">
      <string>6820ddff</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563445394000</long>
      </object>
     </void>
     <void property="message">
      <string>store webapp configuration under /opengrok/etc</string>
     </void>
     <void property="revision">
      <string>3185e592</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Shenghan Gao &lt;shenghang@nvidia.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1558655183000</long>
      </object>
     </void>
     <void property="message">
      <string>change according to review</string>
     </void>
     <void property="revision">
      <string>4aedc80c</string>
     </void>
     <void property="tags">
      <string>1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
