<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567433129000</long>
      </object>
     </void>
     <void property="message">
      <string>better LDAP query error reporting</string>
     </void>
     <void property="revision">
      <string>e5567996</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567175806000</long>
      </object>
     </void>
     <void property="message">
      <string>instance is optional</string>
     </void>
     <void property="revision">
      <string>e173e36d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567174237000</long>
      </object>
     </void>
     <void property="message">
      <string>package private</string>
     </void>
     <void property="revision">
      <string>bf4d2fd4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567174198000</long>
      </object>
     </void>
     <void property="message">
      <string>no need to supply array dimensions anymore</string>
     </void>
     <void property="revision">
      <string>b91b7b82</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567173949000</long>
      </object>
     </void>
     <void property="message">
      <string>fix more warnings</string>
     </void>
     <void property="revision">
      <string>d7630e3a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567172891000</long>
      </object>
     </void>
     <void property="message">
      <string>first working test</string>
     </void>
     <void property="revision">
      <string>f7f40d76</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566830968000</long>
      </object>
     </void>
     <void property="message">
      <string>introduce instance number of LdapUserPlugin</string>
     </void>
     <void property="revision">
      <string>66cf937c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566399400000</long>
      </object>
     </void>
     <void property="message">
      <string>fix test</string>
     </void>
     <void property="revision">
      <string>02df4614</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566389837000</long>
      </object>
     </void>
     <void property="message">
      <string>fix style</string>
     </void>
     <void property="revision">
      <string>0e7ff20b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566387084000</long>
      </object>
     </void>
     <void property="message">
      <string>add basic unit test of fillSession()</string>
     </void>
     <void property="revision">
      <string>3c16dad8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566300002000</long>
      </object>
     </void>
     <void property="message">
      <string>reverse the condition</string>
     </void>
     <void property="revision">
      <string>e188d1dd</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566299722000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid String.join()</string>
     </void>
     <void property="revision">
      <string>172ba845</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566296389000</long>
      </object>
     </void>
     <void property="message">
      <string>adjust comment</string>
     </void>
     <void property="revision">
      <string>9f40699f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566296049000</long>
      </object>
     </void>
     <void property="message">
      <string>fix condition</string>
     </void>
     <void property="revision">
      <string>fbd310be</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1556014879000</long>
      </object>
     </void>
     <void property="message">
      <string>make User logging consistent</string>
     </void>
     <void property="revision">
      <string>afd2f2f7</string>
     </void>
     <void property="tags">
      <string>1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1556014765000</long>
      </object>
     </void>
     <void property="message">
      <string>fix obj ref</string>
     </void>
     <void property="revision">
      <string>7e60ad99</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555769566000</long>
      </object>
     </void>
     <void property="message">
      <string>refactor User filter expansion</string>
     </void>
     <void property="revision">
      <string>f305899c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555595738000</long>
      </object>
     </void>
     <void property="message">
      <string>fix javadoc</string>
     </void>
     <void property="revision">
      <string>750d880b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555591737000</long>
      </object>
     </void>
     <void property="message">
      <string>honor useDN when creating LdapUser instance</string>
     </void>
     <void property="revision">
      <string>c17762fc</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555591480000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid faking DN as attribute</string>
     </void>
     <void property="revision">
      <string>17deb9ed</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555581560000</long>
      </object>
     </void>
     <void property="message">
      <string>LDAP changes to make the plugins work with SSO passing e-mail only
    
    - pass DN for LDAP lookups directly, not via User
    - determine DNs in LdapUserPlugin and store it in the session</string>
     </void>
     <void property="revision">
      <string>53c33ae5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565168290000</long>
      </object>
     </void>
     <void property="message">
      <string>Change plugins file structure to follow a standard way</string>
     </void>
     <void property="revision">
      <string>b28a5538</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
