<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1571055353000</long>
      </object>
     </void>
     <void property="message">
      <string>LDAP uid case (in)sensitivity fix for LdapFilter plugin (#2949)
    
    fixes #2946</string>
     </void>
     <void property="revision">
      <string>555fbbc8</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566828795000</long>
      </object>
     </void>
     <void property="message">
      <string>decode both email and username in Mellon
    
    also be more careful when expanding the filter</string>
     </void>
     <void property="revision">
      <string>5880dabe</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566303608000</long>
      </object>
     </void>
     <void property="message">
      <string>LdapServer::getUrl</string>
     </void>
     <void property="revision">
      <string>e0206179</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
