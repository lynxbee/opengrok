<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567174064000</long>
      </object>
     </void>
     <void property="message">
      <string>move attr comments</string>
     </void>
     <void property="revision">
      <string>1fc76d71</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567173949000</long>
      </object>
     </void>
     <void property="message">
      <string>fix more warnings</string>
     </void>
     <void property="revision">
      <string>d7630e3a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567173444000</long>
      </object>
     </void>
     <void property="message">
      <string>fix warnings reported by IDEA</string>
     </void>
     <void property="revision">
      <string>31639808</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567172891000</long>
      </object>
     </void>
     <void property="message">
      <string>first working test</string>
     </void>
     <void property="revision">
      <string>f7f40d76</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566919254000</long>
      </object>
     </void>
     <void property="message">
      <string>refactor for testing, avoid FAKE parameter</string>
     </void>
     <void property="revision">
      <string>41d15cd7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566918415000</long>
      </object>
     </void>
     <void property="message">
      <string>fix warning</string>
     </void>
     <void property="revision">
      <string>17eebd12</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566830968000</long>
      </object>
     </void>
     <void property="message">
      <string>introduce instance number of LdapUserPlugin</string>
     </void>
     <void property="revision">
      <string>66cf937c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566399400000</long>
      </object>
     </void>
     <void property="message">
      <string>fix test</string>
     </void>
     <void property="revision">
      <string>02df4614</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566296259000</long>
      </object>
     </void>
     <void property="message">
      <string>add return</string>
     </void>
     <void property="revision">
      <string>4126de0d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566295929000</long>
      </object>
     </void>
     <void property="message">
      <string>rename DN to id</string>
     </void>
     <void property="revision">
      <string>a3cc6ed8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555591480000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid faking DN as attribute</string>
     </void>
     <void property="revision">
      <string>17deb9ed</string>
     </void>
     <void property="tags">
      <string>1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1555581560000</long>
      </object>
     </void>
     <void property="message">
      <string>LDAP changes to make the plugins work with SSO passing e-mail only
    
    - pass DN for LDAP lookups directly, not via User
    - determine DNs in LdapUserPlugin and store it in the session</string>
     </void>
     <void property="revision">
      <string>53c33ae5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566896523000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix some lgtm warnings</string>
     </void>
     <void property="revision">
      <string>4b613ded</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565168290000</long>
      </object>
     </void>
     <void property="message">
      <string>Change plugins file structure to follow a standard way</string>
     </void>
     <void property="revision">
      <string>b28a5538</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
