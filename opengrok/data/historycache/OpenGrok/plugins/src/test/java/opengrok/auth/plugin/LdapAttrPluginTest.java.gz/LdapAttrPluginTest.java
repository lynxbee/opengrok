<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567173949000</long>
      </object>
     </void>
     <void property="message">
      <string>fix more warnings</string>
     </void>
     <void property="revision">
      <string>d7630e3a</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567172891000</long>
      </object>
     </void>
     <void property="message">
      <string>first working test</string>
     </void>
     <void property="revision">
      <string>f7f40d76</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566919383000</long>
      </object>
     </void>
     <void property="message">
      <string>fix comment</string>
     </void>
     <void property="revision">
      <string>464d259b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566919254000</long>
      </object>
     </void>
     <void property="message">
      <string>refactor for testing, avoid FAKE parameter</string>
     </void>
     <void property="revision">
      <string>41d15cd7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566832287000</long>
      </object>
     </void>
     <void property="message">
      <string>use shorter User constructor</string>
     </void>
     <void property="revision">
      <string>ef89dd12</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565168290000</long>
      </object>
     </void>
     <void property="message">
      <string>Change plugins file structure to follow a standard way</string>
     </void>
     <void property="revision">
      <string>b28a5538</string>
     </void>
     <void property="tags">
      <string>1.3.1</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
