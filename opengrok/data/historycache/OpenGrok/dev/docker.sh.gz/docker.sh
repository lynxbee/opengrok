<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1583777872000</long>
      </object>
     </void>
     <void property="message">
      <string>Microbadger needs a poke after Docker image is pushed</string>
     </void>
     <void property="revision">
      <string>2387ff1a</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1576072110000</long>
      </object>
     </void>
     <void property="message">
      <string>fix and simplify README update procedure</string>
     </void>
     <void property="revision">
      <string>e8ba77c1</string>
     </void>
     <void property="tags">
      <string>1.3.9, 1.3.8, 1.3.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563525460000</long>
      </object>
     </void>
     <void property="message">
      <string>refresh repository README on Docker hub after image push (#2868)</string>
     </void>
     <void property="revision">
      <string>89259090</string>
     </void>
     <void property="tags">
      <string>1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563446071000</long>
      </object>
     </void>
     <void property="message">
      <string>always build Docker image
    
    fixes #2867</string>
     </void>
     <void property="revision">
      <string>3e788c1b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561973571000</long>
      </object>
     </void>
     <void property="message">
      <string>publish x.y docker tags
    
    fixes #2842</string>
     </void>
     <void property="revision">
      <string>573d2ad6</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561729762000</long>
      </object>
     </void>
     <void property="message">
      <string>check Docker variables</string>
     </void>
     <void property="revision">
      <string>71bb21af</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561729654000</long>
      </object>
     </void>
     <void property="message">
      <string>do no fail on untagged builds</string>
     </void>
     <void property="revision">
      <string>b505526f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561726177000</long>
      </object>
     </void>
     <void property="message">
      <string>fix version setting</string>
     </void>
     <void property="revision">
      <string>f9bac693</string>
     </void>
     <void property="tags">
      <string>1.2.20</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561719804000</long>
      </object>
     </void>
     <void property="message">
      <string>cleanup</string>
     </void>
     <void property="revision">
      <string>c0e56161</string>
     </void>
     <void property="tags">
      <string>1.2.19, 1.2.18</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561719584000</long>
      </object>
     </void>
     <void property="message">
      <string>add docker build script from OpenGrok/docker repo</string>
     </void>
     <void property="revision">
      <string>675e1740</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
