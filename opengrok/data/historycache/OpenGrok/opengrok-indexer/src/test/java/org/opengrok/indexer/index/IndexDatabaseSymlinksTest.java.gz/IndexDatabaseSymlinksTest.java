<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574215181000</long>
      </object>
     </void>
     <void property="message">
      <string>Retire CtagsInstalled check. ctags is fundamental to OpenGrok.</string>
     </void>
     <void property="revision">
      <string>1cd4fdc4</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1568165008000</long>
      </object>
     </void>
     <void property="message">
      <string>Save symlinks data during indexing for use by UI
    
    Also: fix to include File.separator in comparison
    for IndexDatabase isLocal().</string>
     </void>
     <void property="revision">
      <string>7d004396</string>
     </void>
     <void property="tags">
      <string>1.3.4, 1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567962393000</long>
      </object>
     </void>
     <void property="message">
      <string>Do not use -C. Fix up --canonicalRoot and -N,--symlink verbiage.</string>
     </void>
     <void property="revision">
      <string>a483cb1c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567880149000</long>
      </object>
     </void>
     <void property="message">
      <string>Add (failing) tests of additional symlink scenarios</string>
     </void>
     <void property="revision">
      <string>1c3bcdb3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567831948000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix missing addition to acceptedNonlocalSymlinks
    
    ... after updating test that showed a bug existed.</string>
     </void>
     <void property="revision">
      <string>6d7e50d1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567723173000</long>
      </object>
     </void>
     <void property="message">
      <string>Add IndexDatabaseSymlinksTest</string>
     </void>
     <void property="revision">
      <string>fd216472</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
