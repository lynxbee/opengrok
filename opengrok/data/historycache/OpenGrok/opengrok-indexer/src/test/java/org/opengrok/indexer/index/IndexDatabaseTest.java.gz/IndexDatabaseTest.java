<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574215181000</long>
      </object>
     </void>
     <void property="message">
      <string>Retire CtagsInstalled check. ctags is fundamental to OpenGrok.</string>
     </void>
     <void property="revision">
      <string>1cd4fdc4</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543636617000</long>
      </object>
     </void>
     <void property="message">
      <string>Support ctags for historical revisions
    
    - Add webappCtags configuration flag, with
      --webappCtags switch, to indicate if the webapp
      is eligible to run ctags.
    - Add Repository.getHistoryGet() override to
      allow sub-classes to override to avoid a full
      in-memory version; and override for Git and
      Mercurial.
    - Revise BoundedBlockingObjectPool as LIFO-to-FIFO
      so the webapp does not start extraneous
      instances; Indexer switches to FIFO performance
      when the queue pool is emptied.
    - make IndexerParallelizer a lazy property of
      RuntimeEnvironment, and make the executors of
      IndexerParallelizer also lazy properties. Move
      the history-related executors into
      IndexerParallelizer so the lifecycle of all
      indexing/history executors are controlled in
      the same class.</string>
     </void>
     <void property="revision">
      <string>e829566c</string>
     </void>
     <void property="tags">
      <string>1.3.4, 1.3.3, 1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549374422000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of default project argument of prepareIndexer()</string>
     </void>
     <void property="revision">
      <string>369f83fb</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549366372000</long>
      </object>
     </void>
     <void property="message">
      <string>replace list files in Indexer with RESTful API endpoint</string>
     </void>
     <void property="revision">
      <string>7516a8e8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549363431000</long>
      </object>
     </void>
     <void property="message">
      <string>remove repository listing in indexer</string>
     </void>
     <void property="revision">
      <string>18d0c95f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549362905000</long>
      </object>
     </void>
     <void property="message">
      <string>add API endpoint for deleting history cache
    fixes #2655</string>
     </void>
     <void property="revision">
      <string>09dc2337</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1546136972000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2604, add TandemFilename and TandemPath
    
    Also:
    - Do case-insensitive comparison for .gz in
      GZIPAnalyzer.
    - Add a serialVersionUID to silence lint.</string>
     </void>
     <void property="revision">
      <string>4da26a1e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535379837000</long>
      </object>
     </void>
     <void property="message">
      <string>sanitize path
    fixes #2315</string>
     </void>
     <void property="revision">
      <string>b2315481</string>
     </void>
     <void property="tags">
      <string>1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
     <void property="tags">
      <string>1.1-rc38, 1.1-rc37, 1.1-rc36, 1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
