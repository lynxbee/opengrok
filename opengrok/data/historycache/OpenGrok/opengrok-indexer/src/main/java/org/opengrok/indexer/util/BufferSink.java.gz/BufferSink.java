<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543636617000</long>
      </object>
     </void>
     <void property="message">
      <string>Support ctags for historical revisions
    
    - Add webappCtags configuration flag, with
      --webappCtags switch, to indicate if the webapp
      is eligible to run ctags.
    - Add Repository.getHistoryGet() override to
      allow sub-classes to override to avoid a full
      in-memory version; and override for Git and
      Mercurial.
    - Revise BoundedBlockingObjectPool as LIFO-to-FIFO
      so the webapp does not start extraneous
      instances; Indexer switches to FIFO performance
      when the queue pool is emptied.
    - make IndexerParallelizer a lazy property of
      RuntimeEnvironment, and make the executors of
      IndexerParallelizer also lazy properties. Move
      the history-related executors into
      IndexerParallelizer so the lifecycle of all
      indexing/history executors are controlled in
      the same class.</string>
     </void>
     <void property="revision">
      <string>e829566c</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
