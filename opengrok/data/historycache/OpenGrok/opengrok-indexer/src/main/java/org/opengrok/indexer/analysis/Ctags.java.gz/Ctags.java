<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1583631405000</long>
      </object>
     </void>
     <void property="message">
      <string>Use --pattern-length-limit=180 to reduce likelihood of re-read</string>
     </void>
     <void property="revision">
      <string>24ef7da9</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575638932000</long>
      </object>
     </void>
     <void property="message">
      <string>remove -n from ctags fields
    
    fixes #2995</string>
     </void>
     <void property="revision">
      <string>d65161c5</string>
     </void>
     <void property="tags">
      <string>1.3.8, 1.3.7, 1.3.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575158079000</long>
      </object>
     </void>
     <void property="message">
      <string>Format argv logging to aid copy/paste execution
    
    Also, move determination of operating system name
    to PlatformUtils from web/Util.</string>
     </void>
     <void property="revision">
      <string>5c72ec3c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574217964000</long>
      </object>
     </void>
     <void property="message">
      <string>Check validateUniversalCtags() from web too</string>
     </void>
     <void property="revision">
      <string>50fd1283</string>
     </void>
     <void property="tags">
      <string>1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574216615000</long>
      </object>
     </void>
     <void property="message">
      <string>Remove redundant language mapping. Only do via registerAnalyzer()</string>
     </void>
     <void property="revision">
      <string>adc0ce11</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573928221000</long>
      </object>
     </void>
     <void property="message">
      <string>Use ctags --kinds-LANG instead of deprecated --LANG-kinds</string>
     </void>
     <void property="revision">
      <string>2a2c938a</string>
     </void>
     <void property="tags">
      <string>1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573927073000</long>
      </object>
     </void>
     <void property="message">
      <string>Do not conflict with ctags built-in langs which is now fatal
    
    Fix #2977 Fix #1137</string>
     </void>
     <void property="revision">
      <string>4db2ac07</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573954959000</long>
      </object>
     </void>
     <void property="message">
      <string>Also get --list-languages. getCtags() is always defined</string>
     </void>
     <void property="revision">
      <string>9c92ca95</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573925673000</long>
      </object>
     </void>
     <void property="message">
      <string>Show extra help with multiple -h,--help. Show ctags command-line</string>
     </void>
     <void property="revision">
      <string>2d875dde</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1571372820000</long>
      </object>
     </void>
     <void property="message">
      <string>Use LangMap to customize Ctags from -A,--analyzer</string>
     </void>
     <void property="revision">
      <string>6de4f5aa</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1571276737000</long>
      </object>
     </void>
     <void property="message">
      <string>Add getCtagsLang() method
    
    Also, use &quot;powershell&quot; not &quot;Posh&quot; for
    OpenGrok customizations, to match the built-in
    ctags language name as is done for e.g. &quot;clojure&quot;
    and &quot;pascal&quot; and their OpenGrok-overriden
    handling.</string>
     </void>
     <void property="revision">
      <string>973cf38a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1570490824000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2907 : Add support for TypeScript</string>
     </void>
     <void property="revision">
      <string>0ed261b2</string>
     </void>
     <void property="tags">
      <string>1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1570908672000</long>
      </object>
     </void>
     <void property="message">
      <string>Relocate clojure options to addClojureSupport()</string>
     </void>
     <void property="revision">
      <string>8d0f8374</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Lubos Kosco &lt;tarzanek@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1568717264000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok not able to index Java files due to stricter Universal ctags… (#2931)</string>
     </void>
     <void property="revision">
      <string>14a8a101</string>
     </void>
     <void property="tags">
      <string>1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567524383000</long>
      </object>
     </void>
     <void property="message">
      <string>use Future+Executor to enforce the timeout</string>
     </void>
     <void property="revision">
      <string>b124dbe6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566224159000</long>
      </object>
     </void>
     <void property="message">
      <string>enforce timeout for file processing in ctags
    
    fixes #2812</string>
     </void>
     <void property="revision">
      <string>b82c5e9d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
     <void property="tags">
      <string>1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>IamTHEvilONE &lt;jon.hemming@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1560760577000</long>
      </object>
     </void>
     <void property="message">
      <string>Update Ctags.java to address Issue 2804 (#2807)
    
    fixes #2804</string>
     </void>
     <void property="revision">
      <string>319b5c9c</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1547739871000</long>
      </object>
     </void>
     <void property="message">
      <string>fix some Javadoc warnings (#2627)</string>
     </void>
     <void property="revision">
      <string>81b586e6</string>
     </void>
     <void property="tags">
      <string>1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1518025411000</long>
      </object>
     </void>
     <void property="message">
      <string>Retry on ctags tagLine == null. Adjust ctags logging.</string>
     </void>
     <void property="revision">
      <string>4087ffbf</string>
     </void>
     <void property="tags">
      <string>1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39, 1.1-rc38, 1.1-rc37, 1.1-rc36, 1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30, 1.1-rc29, 1.1-rc28, 1.1-rc27, 1.1-rc26, 1.1-rc25, 1.1-rc24, 1.1-rc23, 1.1-rc22, 1.1-rc21</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534249332000</long>
      </object>
     </void>
     <void property="message">
      <string>enforce Universal ctags (#2294)
    
    fixes #2261</string>
     </void>
     <void property="revision">
      <string>2a63f72d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
