<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584631494000</long>
      </object>
     </void>
     <void property="message">
      <string>allow -S to specify search path</string>
     </void>
     <void property="revision">
      <string>937bd40d</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1572229391000</long>
      </object>
     </void>
     <void property="message">
      <string>Add --disableRepository handling</string>
     </void>
     <void property="revision">
      <string>29816c3b</string>
     </void>
     <void property="tags">
      <string>1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574506837000</long>
      </object>
     </void>
     <void property="message">
      <string>specify which Messages to delete with text</string>
     </void>
     <void property="revision">
      <string>1d0bbff4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573954959000</long>
      </object>
     </void>
     <void property="message">
      <string>Also get --list-languages. getCtags() is always defined</string>
     </void>
     <void property="revision">
      <string>9c92ca95</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1572434687000</long>
      </object>
     </void>
     <void property="message">
      <string>make getDiffData() parallel (#2955)
    
    fixes #2953</string>
     </void>
     <void property="revision">
      <string>fb531549</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567384895000</long>
      </object>
     </void>
     <void property="message">
      <string>Resolve #469 : Add -C,--canonicalRoot to whitelist symlink target roots</string>
     </void>
     <void property="revision">
      <string>0e0ac58d</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567222427000</long>
      </object>
     </void>
     <void property="message">
      <string>Move PathUtils.getPathRelativeToSourceRoot to RuntimeEnvironment
    
    Resolves odd circular dependency in that
    PathUtils.getPathRelativeToSourceRoot() is only
    called from the RuntimeEnvironment.getPathRelativeToSourceRoot()
    wrapper, but PathUtils.getPathRelativeToSourceRoot
    was needing to get a RuntimeEnvironment.Instance()
    for &quot;allowed symlinks&quot;.</string>
     </void>
     <void property="revision">
      <string>2738be5e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567221789000</long>
      </object>
     </void>
     <void property="message">
      <string>Remove unnecessary stripCount parameter</string>
     </void>
     <void property="revision">
      <string>9f5ca421</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569350865000</long>
      </object>
     </void>
     <void property="message">
      <string>revise auth framework locking in RuntimeEnvironment (#2934)
    
    fixes #2932</string>
     </void>
     <void property="revision">
      <string>1cbb0597</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567524383000</long>
      </object>
     </void>
     <void property="message">
      <string>use Future+Executor to enforce the timeout</string>
     </void>
     <void property="revision">
      <string>b124dbe6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1566224159000</long>
      </object>
     </void>
     <void property="message">
      <string>enforce timeout for file processing in ctags
    
    fixes #2812</string>
     </void>
     <void property="revision">
      <string>b82c5e9d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
     <void property="tags">
      <string>1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1551268893000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid returning null objects from getIndexSearcher() (#2701)
    
    fixes #2700</string>
     </void>
     <void property="revision">
      <string>f0df8b60</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543636617000</long>
      </object>
     </void>
     <void property="message">
      <string>Support ctags for historical revisions
    
    - Add webappCtags configuration flag, with
      --webappCtags switch, to indicate if the webapp
      is eligible to run ctags.
    - Add Repository.getHistoryGet() override to
      allow sub-classes to override to avoid a full
      in-memory version; and override for Git and
      Mercurial.
    - Revise BoundedBlockingObjectPool as LIFO-to-FIFO
      so the webapp does not start extraneous
      instances; Indexer switches to FIFO performance
      when the queue pool is emptied.
    - make IndexerParallelizer a lazy property of
      RuntimeEnvironment, and make the executors of
      IndexerParallelizer also lazy properties. Move
      the history-related executors into
      IndexerParallelizer so the lifecycle of all
      indexing/history executors are controlled in
      the same class.</string>
     </void>
     <void property="revision">
      <string>e829566c</string>
     </void>
     <void property="tags">
      <string>1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549374422000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of default project argument of prepareIndexer()</string>
     </void>
     <void property="revision">
      <string>369f83fb</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549029912000</long>
      </object>
     </void>
     <void property="message">
      <string>Add more CheckStyle rules</string>
     </void>
     <void property="revision">
      <string>d1e826fa</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1547739871000</long>
      </object>
     </void>
     <void property="message">
      <string>fix some Javadoc warnings (#2627)</string>
     </void>
     <void property="revision">
      <string>81b586e6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1544195057000</long>
      </object>
     </void>
     <void property="message">
      <string>add whitespace</string>
     </void>
     <void property="revision">
      <string>0f38abf3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540579299000</long>
      </object>
     </void>
     <void property="message">
      <string>treat compilation warnings as errors
    fixes #2246</string>
     </void>
     <void property="revision">
      <string>c4b1b1eb</string>
     </void>
     <void property="tags">
      <string>1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543825912000</long>
      </object>
     </void>
     <void property="message">
      <string>clear the groups before populating them (#2567)
    
    fixes #2566</string>
     </void>
     <void property="revision">
      <string>ba15b5bd</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542025502000</long>
      </object>
     </void>
     <void property="message">
      <string>Better synchronization of RE (#2501)
    
    fixes #2496</string>
     </void>
     <void property="revision">
      <string>5f6ae75c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540982665000</long>
      </object>
     </void>
     <void property="message">
      <string>using the project-repository map while being in write lock (#2451)</string>
     </void>
     <void property="revision">
      <string>68830e6d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540543007000</long>
      </object>
     </void>
     <void property="message">
      <string>Configuration rework (#2423)
    
    fixes #2382</string>
     </void>
     <void property="revision">
      <string>2ffbb0cf</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539119060000</long>
      </object>
     </void>
     <void property="message">
      <string>add global tunable for navigate window
    fixes #2397</string>
     </void>
     <void property="revision">
      <string>326dace0</string>
     </void>
     <void property="tags">
      <string>1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1538753984000</long>
      </object>
     </void>
     <void property="message">
      <string>rename host to uri</string>
     </void>
     <void property="revision">
      <string>55402125</string>
     </void>
     <void property="tags">
      <string>1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535718354000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of verbosity flag</string>
     </void>
     <void property="revision">
      <string>83adc92c</string>
     </void>
     <void property="tags">
      <string>1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535615752000</long>
      </object>
     </void>
     <void property="message">
      <string>add API endpoint for include files reload (#2325)
    
    fixes #2323</string>
     </void>
     <void property="revision">
      <string>6630f04d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534327787000</long>
      </object>
     </void>
     <void property="message">
      <string>fix the logic and report ctags version</string>
     </void>
     <void property="revision">
      <string>225d0855</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534249332000</long>
      </object>
     </void>
     <void property="message">
      <string>enforce Universal ctags (#2294)
    
    fixes #2261</string>
     </void>
     <void property="revision">
      <string>2a63f72d</string>
     </void>
     <void property="tags">
      <string>1.1-rc38</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
     <void property="tags">
      <string>1.1-rc37, 1.1-rc36, 1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
