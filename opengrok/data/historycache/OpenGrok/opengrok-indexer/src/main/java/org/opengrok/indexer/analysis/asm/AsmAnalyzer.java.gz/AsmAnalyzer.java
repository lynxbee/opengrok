<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1581656602000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2030 : all new from createComponents()</string>
     </void>
     <void property="revision">
      <string>9cd38b98</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574300440000</long>
      </object>
     </void>
     <void property="message">
      <string>Clone CAnalyzer as AsmAnalyzer, and associate .S and .ASM
    
    CtagsTest.bug19195() was newly failing from
    explicit registration of .S files for the Ctags C
    parser versus former implicit use of the Ctags
    Asm parser.
    
    With this change, OpenGrok now explicitly
    registers the Asm parser for .S and .ASM files.</string>
     </void>
     <void property="revision">
      <string>50065c95</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
