<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1581656602000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2030 : all new from createComponents()</string>
     </void>
     <void property="revision">
      <string>9cd38b98</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1570490824000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2907 : Add support for TypeScript</string>
     </void>
     <void property="revision">
      <string>0ed261b2</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
