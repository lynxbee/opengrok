<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1581656602000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2030 : all new from createComponents()</string>
     </void>
     <void property="revision">
      <string>9cd38b98</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1571276737000</long>
      </object>
     </void>
     <void property="message">
      <string>Add getCtagsLang() method
    
    Also, use &quot;powershell&quot; not &quot;Posh&quot; for
    OpenGrok customizations, to match the built-in
    ctags language name as is done for e.g. &quot;clojure&quot;
    and &quot;pascal&quot; and their OpenGrok-overriden
    handling.</string>
     </void>
     <void property="revision">
      <string>973cf38a</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1550404760000</long>
      </object>
     </void>
     <void property="message">
      <string>updating copyright to comply with CDDL
    
    fixes #2680</string>
     </void>
     <void property="revision">
      <string>312f4f68</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549110047000</long>
      </object>
     </void>
     <void property="message">
      <string>Extracting base classes for analyzer factory and analyzers
    
     - some base class is needed as a reference for the framework
    
    approaches #2588</string>
     </void>
     <void property="revision">
      <string>57eefa47</string>
     </void>
     <void property="tags">
      <string>1.2.1, 1.2.0</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
