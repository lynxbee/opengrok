<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1579100376000</long>
      </object>
     </void>
     <void property="message">
      <string>Messages class rework (#3011)
    
    reflect Message level in the UI
    
    make Message level first class citizen
    
    fixes #2974</string>
     </void>
     <void property="revision">
      <string>57396dcb</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574506837000</long>
      </object>
     </void>
     <void property="message">
      <string>specify which Messages to delete with text</string>
     </void>
     <void property="revision">
      <string>1d0bbff4</string>
     </void>
     <void property="tags">
      <string>1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornacek &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564748833000</long>
      </object>
     </void>
     <void property="message">
      <string>Update libraries to newer versions</string>
     </void>
     <void property="revision">
      <string>0223f1b8</string>
     </void>
     <void property="tags">
      <string>1.3.4, 1.3.3, 1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1548856993000</long>
      </object>
     </void>
     <void property="message">
      <string>use Jackson for JSON serialization of Messages (#2639)
    
    helps #2046</string>
     </void>
     <void property="revision">
      <string>3db691be</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1545235535000</long>
      </object>
     </void>
     <void property="message">
      <string>add serial version UID</string>
     </void>
     <void property="revision">
      <string>e90a4de6</string>
     </void>
     <void property="tags">
      <string>1.1.2, 1.1.1, 1.1.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530688329000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix issues after merge</string>
     </void>
     <void property="revision">
      <string>1a2bb6b6</string>
     </void>
     <void property="tags">
      <string>1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39, 1.1-rc38, 1.1-rc37, 1.1-rc36, 1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
