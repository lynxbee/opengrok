<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1581912779000</long>
      </object>
     </void>
     <void property="message">
      <string>Extract to QueryParameters named literals</string>
     </void>
     <void property="revision">
      <string>1c830032</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1572434687000</long>
      </object>
     </void>
     <void property="message">
      <string>make getDiffData() parallel (#2955)
    
    fixes #2953</string>
     </void>
     <void property="revision">
      <string>fb531549</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565329404000</long>
      </object>
     </void>
     <void property="message">
      <string>Minify js and css files (#2891)</string>
     </void>
     <void property="revision">
      <string>90c9bda4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1560862565000</long>
      </object>
     </void>
     <void property="message">
      <string>JSTL vs Paths (#2814)
    
    fixes #2806</string>
     </void>
     <void property="revision">
      <string>7cb64f39</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1553013192000</long>
      </object>
     </void>
     <void property="message">
      <string>Short URL for all projects search implemented (#2717)
    
    fixes #1357</string>
     </void>
     <void property="revision">
      <string>1161ac16</string>
     </void>
     <void property="tags">
      <string>1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1550222755000</long>
      </object>
     </void>
     <void property="message">
      <string>fix comments</string>
     </void>
     <void property="revision">
      <string>8fa4cadb</string>
     </void>
     <void property="tags">
      <string>1.2.4, 1.2.3, 1.2.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549110047000</long>
      </object>
     </void>
     <void property="message">
      <string>Extracting base classes for analyzer factory and analyzers
    
     - some base class is needed as a reference for the framework
    
    approaches #2588</string>
     </void>
     <void property="revision">
      <string>57eefa47</string>
     </void>
     <void property="tags">
      <string>1.2.1, 1.2.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549029912000</long>
      </object>
     </void>
     <void property="message">
      <string>Add more CheckStyle rules</string>
     </void>
     <void property="revision">
      <string>d1e826fa</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1547843465000</long>
      </object>
     </void>
     <void property="message">
      <string>Replace &quot;q&quot; query param name with &quot;full&quot;</string>
     </void>
     <void property="revision">
      <string>d21d069f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1547739871000</long>
      </object>
     </void>
     <void property="message">
      <string>fix some Javadoc warnings (#2627)</string>
     </void>
     <void property="revision">
      <string>81b586e6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1546136972000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix #2604, add TandemFilename and TandemPath
    
    Also:
    - Do case-insensitive comparison for .gz in
      GZIPAnalyzer.
    - Add a serialVersionUID to silence lint.</string>
     </void>
     <void property="revision">
      <string>4da26a1e</string>
     </void>
     <void property="tags">
      <string>1.1.2, 1.1.1, 1.1.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542619346000</long>
      </object>
     </void>
     <void property="message">
      <string>removing non indexed projects from requested projects</string>
     </void>
     <void property="revision">
      <string>6c8c59a6</string>
     </void>
     <void property="tags">
      <string>1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542185705000</long>
      </object>
     </void>
     <void property="message">
      <string>making protected constant again public (#2509)</string>
     </void>
     <void property="revision">
      <string>99b7d3fd</string>
     </void>
     <void property="tags">
      <string>1.1-rc74</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542103560000</long>
      </object>
     </void>
     <void property="message">
      <string>group parameter for search URL (#2507)
    
    approaches #1974</string>
     </void>
     <void property="revision">
      <string>70d510db</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541780659000</long>
      </object>
     </void>
     <void property="message">
      <string>preserve query string from the request when building reivision redirect (#2494)
    
    fixes #2492</string>
     </void>
     <void property="revision">
      <string>b9486080</string>
     </void>
     <void property="tags">
      <string>1.1-rc73, 1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Lubos Kosco &lt;tarzanek@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541512348000</long>
      </object>
     </void>
     <void property="message">
      <string>sanitize more paths on windows, fixes #2335</string>
     </void>
     <void property="revision">
      <string>807ead8f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540543007000</long>
      </object>
     </void>
     <void property="message">
      <string>Configuration rework (#2423)
    
    fixes #2382</string>
     </void>
     <void property="revision">
      <string>2ffbb0cf</string>
     </void>
     <void property="tags">
      <string>1.1-rc70, 1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540308325000</long>
      </object>
     </void>
     <void property="message">
      <string>avoiding npe when the index has not been done (#2437)</string>
     </void>
     <void property="revision">
      <string>697d307a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540293691000</long>
      </object>
     </void>
     <void property="message">
      <string>Using weak tag instead of just last modification date (#2435)
    
     - This enables us to reflect all other factors
       which contribute to the resource freshness
          the last file timestamp
          messages on the project
          the timestamp of last index
          the opengrok version
     - We assemble all these to the weak tag,
       and the resource is reloaded only in any of these change</string>
     </void>
     <void property="revision">
      <string>7d84fb5d</string>
     </void>
     <void property="tags">
      <string>1.1-rc65</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536246109000</long>
      </object>
     </void>
     <void property="message">
      <string>if economy mode is on and history off, generate xref on the fly
    fixes #2316</string>
     </void>
     <void property="revision">
      <string>17c862ae</string>
     </void>
     <void property="tags">
      <string>1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536239064000</long>
      </object>
     </void>
     <void property="message">
      <string>call getHistory() from PageConfig with ui = True</string>
     </void>
     <void property="revision">
      <string>bbfae115</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533635526000</long>
      </object>
     </void>
     <void property="message">
      <string>make jrcs external dependency (#2262)
    
    fixes #2258</string>
     </void>
     <void property="revision">
      <string>3bd78204</string>
     </void>
     <void property="tags">
      <string>1.1-rc40, 1.1-rc39, 1.1-rc38, 1.1-rc37, 1.1-rc36</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
     <void property="tags">
      <string>1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
