<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1585231253000</long>
      </object>
     </void>
     <void property="message">
      <string>print Java runtime version</string>
     </void>
     <void property="revision">
      <string>10670d68</string>
     </void>
     <void property="tags">
      <string>1.3.11</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584758743000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix up some code warnings</string>
     </void>
     <void property="revision">
      <string>786b9f4b</string>
     </void>
     <void property="tags">
      <string>1.3.10</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584751992000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix up some help descriptions</string>
     </void>
     <void property="revision">
      <string>f5124002</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584750827000</long>
      </object>
     </void>
     <void property="message">
      <string>Resolve #2638 : Add -h,--help repos</string>
     </void>
     <void property="revision">
      <string>cfbc0ba5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584748884000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix to follow &quot;concise formatting&quot; guide</string>
     </void>
     <void property="revision">
      <string>c49b2bab</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584748849000</long>
      </object>
     </void>
     <void property="message">
      <string>Specify a HelpMode to show various details</string>
     </void>
     <void property="revision">
      <string>5e426b1c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584631494000</long>
      </object>
     </void>
     <void property="message">
      <string>allow -S to specify search path</string>
     </void>
     <void property="revision">
      <string>937bd40d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575000675000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix alphabetical ordering of options. Tweak spacing.</string>
     </void>
     <void property="revision">
      <string>7271f92f</string>
     </void>
     <void property="tags">
      <string>1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574895174000</long>
      </object>
     </void>
     <void property="message">
      <string>Remove unused WebAddress</string>
     </void>
     <void property="revision">
      <string>ad0278b3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575428805000</long>
      </object>
     </void>
     <void property="message">
      <string>Add a debug log. Add test for &quot;Repository&quot; suffix.</string>
     </void>
     <void property="revision">
      <string>8f465e21</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1572229391000</long>
      </object>
     </void>
     <void property="message">
      <string>Add --disableRepository handling</string>
     </void>
     <void property="revision">
      <string>29816c3b</string>
     </void>
     <void property="tags">
      <string>1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575158079000</long>
      </object>
     </void>
     <void property="message">
      <string>Format argv logging to aid copy/paste execution
    
    Also, move determination of operating system name
    to PlatformUtils from web/Util.</string>
     </void>
     <void property="revision">
      <string>5c72ec3c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574218025000</long>
      </object>
     </void>
     <void property="message">
      <string>No need for &quot;UNDEFINED&quot; handling re Ctags argv</string>
     </void>
     <void property="revision">
      <string>2768fd73</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574484738000</long>
      </object>
     </void>
     <void property="message">
      <string>Also validate canonicalRoot when deserializing Configuration</string>
     </void>
     <void property="revision">
      <string>fcbdc96b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573927073000</long>
      </object>
     </void>
     <void property="message">
      <string>Do not conflict with ctags built-in langs which is now fatal
    
    Fix #2977 Fix #1137</string>
     </void>
     <void property="revision">
      <string>4db2ac07</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573925673000</long>
      </object>
     </void>
     <void property="message">
      <string>Show extra help with multiple -h,--help. Show ctags command-line</string>
     </void>
     <void property="revision">
      <string>2d875dde</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567962468000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix up some Indexer docs, and update for clarity
    
    Also, require option descriptions to be at the
    tail of Option.on() so that description lines
    (after the first) that start with -, --, =, or /
    are not confusingly parsed as option specs.</string>
     </void>
     <void property="revision">
      <string>5d6ffbcb</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567962393000</long>
      </object>
     </void>
     <void property="message">
      <string>Do not use -C. Fix up --canonicalRoot and -N,--symlink verbiage.</string>
     </void>
     <void property="revision">
      <string>a483cb1c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567384895000</long>
      </object>
     </void>
     <void property="message">
      <string>Resolve #469 : Add -C,--canonicalRoot to whitelist symlink target roots</string>
     </void>
     <void property="revision">
      <string>0e0ac58d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567293821000</long>
      </object>
     </void>
     <void property="message">
      <string>Restore historical -N option for --symlink</string>
     </void>
     <void property="revision">
      <string>875ab81a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1565687216000</long>
      </object>
     </void>
     <void property="message">
      <string>Add additional checkstyle checks (#2896)</string>
     </void>
     <void property="revision">
      <string>ff44f24a</string>
     </void>
     <void property="tags">
      <string>1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1550508084000</long>
      </object>
     </void>
     <void property="message">
      <string>fixes #1991</string>
     </void>
     <void property="revision">
      <string>cb82f663</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549166347000</long>
      </object>
     </void>
     <void property="message">
      <string>Output --help to stdout not stderr, with EXIT STATUS=0</string>
     </void>
     <void property="revision">
      <string>62b82a8d</string>
     </void>
     <void property="tags">
      <string>1.2.1, 1.2.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549153232000</long>
      </object>
     </void>
     <void property="message">
      <string>Short-circuit option -R if --help|-h|-? is used</string>
     </void>
     <void property="revision">
      <string>a4876aa6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543636617000</long>
      </object>
     </void>
     <void property="message">
      <string>Support ctags for historical revisions
    
    - Add webappCtags configuration flag, with
      --webappCtags switch, to indicate if the webapp
      is eligible to run ctags.
    - Add Repository.getHistoryGet() override to
      allow sub-classes to override to avoid a full
      in-memory version; and override for Git and
      Mercurial.
    - Revise BoundedBlockingObjectPool as LIFO-to-FIFO
      so the webapp does not start extraneous
      instances; Indexer switches to FIFO performance
      when the queue pool is emptied.
    - make IndexerParallelizer a lazy property of
      RuntimeEnvironment, and make the executors of
      IndexerParallelizer also lazy properties. Move
      the history-related executors into
      IndexerParallelizer so the lifecycle of all
      indexing/history executors are controlled in
      the same class.</string>
     </void>
     <void property="revision">
      <string>e829566c</string>
     </void>
     <void property="tags">
      <string>1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549374422000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of default project argument of prepareIndexer()</string>
     </void>
     <void property="revision">
      <string>369f83fb</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549366372000</long>
      </object>
     </void>
     <void property="message">
      <string>replace list files in Indexer with RESTful API endpoint</string>
     </void>
     <void property="revision">
      <string>7516a8e8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549363431000</long>
      </object>
     </void>
     <void property="message">
      <string>remove repository listing in indexer</string>
     </void>
     <void property="revision">
      <string>18d0c95f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549362905000</long>
      </object>
     </void>
     <void property="message">
      <string>add API endpoint for deleting history cache
    fixes #2655</string>
     </void>
     <void property="revision">
      <string>09dc2337</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1549029912000</long>
      </object>
     </void>
     <void property="message">
      <string>Add more CheckStyle rules</string>
     </void>
     <void property="revision">
      <string>d1e826fa</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1547739871000</long>
      </object>
     </void>
     <void property="message">
      <string>fix some Javadoc warnings (#2627)</string>
     </void>
     <void property="revision">
      <string>81b586e6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1545908552000</long>
      </object>
     </void>
     <void property="message">
      <string>--noindex should suppress history cache generation</string>
     </void>
     <void property="revision">
      <string>8ea3083f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540579299000</long>
      </object>
     </void>
     <void property="message">
      <string>treat compilation warnings as errors
    fixes #2246</string>
     </void>
     <void property="revision">
      <string>c4b1b1eb</string>
     </void>
     <void property="tags">
      <string>1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543826891000</long>
      </object>
     </void>
     <void property="message">
      <string>checking if projects are enabled before enabling them (#2571)
    
    fixes #2563</string>
     </void>
     <void property="revision">
      <string>5fc870e4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543413644000</long>
      </object>
     </void>
     <void property="message">
      <string>normalize project path</string>
     </void>
     <void property="revision">
      <string>bf37f367</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543411238000</long>
      </object>
     </void>
     <void property="message">
      <string>project path needs to use /
    fixes #2551</string>
     </void>
     <void property="revision">
      <string>bd3709da</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1516556687000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix casing issues
    
    - Fix &quot;README&quot; matching.
    - Review to[Lower,Upper]Case w.r.t. Locale. All
      reviewed cases except Locale.English in
    Repository were not dependent on either US,
    English, or Default locale; and would be properly
    specified as ROOT. Fixes #1768 for Turkish.
    - Use String toLowerCase and not Character
      toLowerCase in PathTokenizer for
    context-sensitive and 1:M character mappings.</string>
     </void>
     <void property="revision">
      <string>52dccac1</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39, 1.1-rc38, 1.1-rc37, 1.1-rc36, 1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30, 1.1-rc29, 1.1-rc28, 1.1-rc27, 1.1-rc26, 1.1-rc25, 1.1-rc24, 1.1-rc23, 1.1-rc22, 1.1-rc21, 1.1-rc20, 1.1-rc19</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542028497000</long>
      </object>
     </void>
     <void property="message">
      <string>printing the exception to stderr</string>
     </void>
     <void property="revision">
      <string>8426dcf4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Lubos Kosco &lt;tarzanek@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541512348000</long>
      </object>
     </void>
     <void property="message">
      <string>sanitize more paths on windows, fixes #2335</string>
     </void>
     <void property="revision">
      <string>807ead8f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540543007000</long>
      </object>
     </void>
     <void property="message">
      <string>Configuration rework (#2423)
    
    fixes #2382</string>
     </void>
     <void property="revision">
      <string>2ffbb0cf</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539255924000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid null pointer exceptions for project with no repositories</string>
     </void>
     <void property="revision">
      <string>eb782d75</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1538753984000</long>
      </object>
     </void>
     <void property="message">
      <string>rename host to uri</string>
     </void>
     <void property="revision">
      <string>55402125</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1538656487000</long>
      </object>
     </void>
     <void property="message">
      <string>make the output when scanning/listing repositories a bit more verbose (#2374)</string>
     </void>
     <void property="revision">
      <string>7c709768</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1538416340000</long>
      </object>
     </void>
     <void property="message">
      <string>remove unused import</string>
     </void>
     <void property="revision">
      <string>8da27e96</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1538403657000</long>
      </object>
     </void>
     <void property="message">
      <string>use java.net.URI to perform the verification</string>
     </void>
     <void property="revision">
      <string>fa2acf12</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536318742000</long>
      </object>
     </void>
     <void property="message">
      <string>check whether URL is valid
    fixes #2216</string>
     </void>
     <void property="revision">
      <string>53d11a05</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536312023000</long>
      </object>
     </void>
     <void property="message">
      <string>fix Do() w.r.t. coding style</string>
     </void>
     <void property="revision">
      <string>e93aeb4e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536310205000</long>
      </object>
     </void>
     <void property="message">
      <string>use die()</string>
     </void>
     <void property="revision">
      <string>1ce56cad</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536247793000</long>
      </object>
     </void>
     <void property="message">
      <string>remove references to Exuberant ctags</string>
     </void>
     <void property="revision">
      <string>a9a037c4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1536308414000</long>
      </object>
     </void>
     <void property="message">
      <string>get repositories for a project automatically
    fixes #2334</string>
     </void>
     <void property="revision">
      <string>22478587</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535533545000</long>
      </object>
     </void>
     <void property="message">
      <string>log indexer options
    fixes #2320</string>
     </void>
     <void property="revision">
      <string>11cc45af</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535731330000</long>
      </object>
     </void>
     <void property="message">
      <string>better help messages</string>
     </void>
     <void property="revision">
      <string>24291115</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535718354000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of verbosity flag</string>
     </void>
     <void property="revision">
      <string>83adc92c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535380553000</long>
      </object>
     </void>
     <void property="message">
      <string>use path separator for project path</string>
     </void>
     <void property="revision">
      <string>31256c90</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534249332000</long>
      </object>
     </void>
     <void property="message">
      <string>enforce Universal ctags (#2294)
    
    fixes #2261</string>
     </void>
     <void property="revision">
      <string>2a63f72d</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533653469000</long>
      </object>
     </void>
     <void property="message">
      <string>Opt parser private (#2265)</string>
     </void>
     <void property="revision">
      <string>46414f58</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529594298000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package</string>
     </void>
     <void property="revision">
      <string>9805b761</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529578237000</long>
      </object>
     </void>
     <void property="message">
      <string>Move indexer classes to org.opengrok.indexer package – move commit</string>
     </void>
     <void property="revision">
      <string>b5840353</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
