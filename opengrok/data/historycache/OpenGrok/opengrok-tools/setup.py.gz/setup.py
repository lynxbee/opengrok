<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573466306000</long>
      </object>
     </void>
     <void property="message">
      <string>add command handling to mirror.py
    
    - refactor disabled command handling
    - add tests
    
    fixes #2973</string>
     </void>
     <void property="revision">
      <string>73485e9f</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1568112431000</long>
      </object>
     </void>
     <void property="message">
      <string>use GitPython instead of pygit2</string>
     </void>
     <void property="revision">
      <string>3d8ff141</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567677904000</long>
      </object>
     </void>
     <void property="message">
      <string>use pytest-xdist to run the tests in parallel</string>
     </void>
     <void property="revision">
      <string>4aec9995</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1567677569000</long>
      </object>
     </void>
     <void property="message">
      <string>get rid of unittest
    
    fixes #2916</string>
     </void>
     <void property="revision">
      <string>0ab78dcc</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562248094000</long>
      </object>
     </void>
     <void property="message">
      <string>Python mirror tool refactor and test (#2851)
    
    fixes #2849</string>
     </void>
     <void property="revision">
      <string>eb236da4</string>
     </void>
     <void property="tags">
      <string>1.3.1, 1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1550764649000</long>
      </object>
     </void>
     <void property="message">
      <string>specify required python version (#2697)</string>
     </void>
     <void property="revision">
      <string>b6c40b30</string>
     </void>
     <void property="tags">
      <string>1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542388554000</long>
      </object>
     </void>
     <void property="message">
      <string>distribute the dist readme</string>
     </void>
     <void property="revision">
      <string>c732e174</string>
     </void>
     <void property="tags">
      <string>1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542097504000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok tools use pytest instead of unittest (#2504)</string>
     </void>
     <void property="revision">
      <string>c0d81b8e</string>
     </void>
     <void property="tags">
      <string>1.1-rc74</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542019819000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok tools version --version (#2499)
    
    * moving version to a python file</string>
     </void>
     <void property="revision">
      <string>6da51376</string>
     </void>
     <void property="tags">
      <string>1.1-rc73</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541881659000</long>
      </object>
     </void>
     <void property="message">
      <string>adding a test case for opengrok python scripts (#2498)</string>
     </void>
     <void property="revision">
      <string>4e163d8b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541531030000</long>
      </object>
     </void>
     <void property="message">
      <string>replace filelock with dependency (#2491)
    
    fixes #2490</string>
     </void>
     <void property="revision">
      <string>2965341b</string>
     </void>
     <void property="tags">
      <string>1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540989562000</long>
      </object>
     </void>
     <void property="message">
      <string>Tools setup install req (#2473)</string>
     </void>
     <void property="revision">
      <string>feabd844</string>
     </void>
     <void property="tags">
      <string>1.1-rc70, 1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540982112000</long>
      </object>
     </void>
     <void property="message">
      <string>upgrade requests to 2.20.0 (#2469)</string>
     </void>
     <void property="revision">
      <string>dae01460</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540643921000</long>
      </object>
     </void>
     <void property="message">
      <string>detecting local development version</string>
     </void>
     <void property="revision">
      <string>e082176f</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539962025000</long>
      </object>
     </void>
     <void property="message">
      <string>move opengrok-tools readme and requirements to top level
    fixes #2447</string>
     </void>
     <void property="revision">
      <string>de6c565a</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66, 1.1-rc65, 1.1-rc64</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539960056000</long>
      </object>
     </void>
     <void property="message">
      <string>Reading the python version from pom.xml (#2431)
    
    Use maven native plugins to read and transform
    the module version and place it into the setup.py.
    
    fixes #2393</string>
     </void>
     <void property="revision">
      <string>92ee3aec</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539940838000</long>
      </object>
     </void>
     <void property="message">
      <string>Removing module &apos;all&apos; as it is not needed (#2427)</string>
     </void>
     <void property="revision">
      <string>d9ed2e6e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539869934000</long>
      </object>
     </void>
     <void property="message">
      <string>moving all package to opengrok-tools</string>
     </void>
     <void property="revision">
      <string>394d7f37</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539858193000</long>
      </object>
     </void>
     <void property="message">
      <string>1.1-rc63</string>
     </void>
     <void property="revision">
      <string>c25ffb49</string>
     </void>
     <void property="tags">
      <string>1.1-rc63</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539773895000</long>
      </object>
     </void>
     <void property="message">
      <string>1.1-rc62</string>
     </void>
     <void property="revision">
      <string>22f642de</string>
     </void>
     <void property="tags">
      <string>1.1-rc62</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539768712000</long>
      </object>
     </void>
     <void property="message">
      <string>1.1-rc61</string>
     </void>
     <void property="revision">
      <string>88a521fd</string>
     </void>
     <void property="tags">
      <string>1.1-rc61</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539608518000</long>
      </object>
     </void>
     <void property="message">
      <string>1.1-rc60</string>
     </void>
     <void property="revision">
      <string>069b2c77</string>
     </void>
     <void property="tags">
      <string>1.1-rc60</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539271525000</long>
      </object>
     </void>
     <void property="message">
      <string>1.1-rc59</string>
     </void>
     <void property="revision">
      <string>5264cdba</string>
     </void>
     <void property="tags">
      <string>1.1-rc59</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539076604000</long>
      </object>
     </void>
     <void property="message">
      <string>Packaging python scripts (#2389)
    
    fixes #2251</string>
     </void>
     <void property="revision">
      <string>7ac1f5d2</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
