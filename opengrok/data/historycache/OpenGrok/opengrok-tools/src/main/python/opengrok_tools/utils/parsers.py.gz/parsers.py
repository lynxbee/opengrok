<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574780900000</long>
      </object>
     </void>
     <void property="message">
      <string>better -J help</string>
     </void>
     <void property="revision">
      <string>3a278792</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569587058000</long>
      </object>
     </void>
     <void property="message">
      <string>rename parsers</string>
     </void>
     <void property="revision">
      <string>bb305b63</string>
     </void>
     <void property="tags">
      <string>1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569586959000</long>
      </object>
     </void>
     <void property="message">
      <string>re-enable printing to the console by default in opengrok-indexer
    
    also make --doprint toggle-able
    
    fixes #2935</string>
     </void>
     <void property="revision">
      <string>e2ecd552</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1568125469000</long>
      </object>
     </void>
     <void property="message">
      <string>allow to set doprint</string>
     </void>
     <void property="revision">
      <string>c9dff538</string>
     </void>
     <void property="tags">
      <string>1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552898025000</long>
      </object>
     </void>
     <void property="message">
      <string>adding python tool specific version (#2720)
    
     - --version now reports the tool specific version along with the tools global version</string>
     </void>
     <void property="revision">
      <string>e1f92fa0</string>
     </void>
     <void property="tags">
      <string>1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542019819000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok tools version --version (#2499)
    
    * moving version to a python file</string>
     </void>
     <void property="revision">
      <string>6da51376</string>
     </void>
     <void property="tags">
      <string>1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
