<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575883584000</long>
      </object>
     </void>
     <void property="message">
      <string>use __str__ of the Command class for logging consistently (#2999)
    
    fixes #2991
    
    Also fix transposition bug in commandsequence#run() logging</string>
     </void>
     <void property="revision">
      <string>82f67fa5</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573466306000</long>
      </object>
     </void>
     <void property="message">
      <string>add command handling to mirror.py
    
    - refactor disabled command handling
    - add tests
    
    fixes #2973</string>
     </void>
     <void property="revision">
      <string>73485e9f</string>
     </void>
     <void property="tags">
      <string>1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573221786000</long>
      </object>
     </void>
     <void property="message">
      <string>refactor call_rest_api(), add tests</string>
     </void>
     <void property="revision">
      <string>9040eb16</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564056540000</long>
      </object>
     </void>
     <void property="message">
      <string>make cleanup a list in CommandSequence (#2878)
    
    fixes #2830</string>
     </void>
     <void property="revision">
      <string>114d3a0e</string>
     </void>
     <void property="tags">
      <string>1.3.3, 1.3.2, 1.3.1, 1.3.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563441027000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid compiling the regex too often</string>
     </void>
     <void property="revision">
      <string>5db10433</string>
     </void>
     <void property="tags">
      <string>1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563366764000</long>
      </object>
     </void>
     <void property="message">
      <string>match error strings in command output more precisely
    
    fixes #2845</string>
     </void>
     <void property="revision">
      <string>1c0e24d2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562067539000</long>
      </object>
     </void>
     <void property="message">
      <string>checking return values for incoming check (#2846)
    
     - refactoring the code to use the constants
    
    fixes #2843</string>
     </void>
     <void property="revision">
      <string>8805a059</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542622496000</long>
      </object>
     </void>
     <void property="message">
      <string>add driveon option to sync.py (#2511)
    
    fixes #2510</string>
     </void>
     <void property="revision">
      <string>5426cb00</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541519706000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid message multiplication</string>
     </void>
     <void property="revision">
      <string>11914aa1</string>
     </void>
     <void property="tags">
      <string>1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541163453000</long>
      </object>
     </void>
     <void property="message">
      <string>report project, set log level for induced break to DEBUG</string>
     </void>
     <void property="revision">
      <string>ee90434d</string>
     </void>
     <void property="tags">
      <string>1.1-rc70</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541162827000</long>
      </object>
     </void>
     <void property="message">
      <string>propagate log level version to CommandSequence</string>
     </void>
     <void property="revision">
      <string>846db8c5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541160893000</long>
      </object>
     </void>
     <void property="message">
      <string>rename Commands to CommandSequence</string>
     </void>
     <void property="revision">
      <string>d0a55b4f</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
