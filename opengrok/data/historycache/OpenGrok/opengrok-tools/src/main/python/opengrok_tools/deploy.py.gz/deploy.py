<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569587058000</long>
      </object>
     </void>
     <void property="message">
      <string>rename parsers</string>
     </void>
     <void property="revision">
      <string>bb305b63</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564579852000</long>
      </object>
     </void>
     <void property="message">
      <string>add option to insert XML snippet into web.xml (#2881)
    
    fixes #2877</string>
     </void>
     <void property="revision">
      <string>6ad20ecf</string>
     </void>
     <void property="tags">
      <string>1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1559224347000</long>
      </object>
     </void>
     <void property="message">
      <string>always use absolute path for webapp config file</string>
     </void>
     <void property="revision">
      <string>a1ee77a8</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554902078000</long>
      </object>
     </void>
     <void property="message">
      <string>fixups to mirroring functions (#2747)</string>
     </void>
     <void property="revision">
      <string>339e8d05</string>
     </void>
     <void property="tags">
      <string>1.2.8, 1.2.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542019819000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok tools version --version (#2499)
    
    * moving version to a python file</string>
     </void>
     <void property="revision">
      <string>6da51376</string>
     </void>
     <void property="tags">
      <string>1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541780626000</long>
      </object>
     </void>
     <void property="message">
      <string>add loglevel arg to tools (#2493)
    
    fixes #2488</string>
     </void>
     <void property="revision">
      <string>89524e9b</string>
     </void>
     <void property="tags">
      <string>1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541520132000</long>
      </object>
     </void>
     <void property="message">
      <string>make sure the logger is inherited</string>
     </void>
     <void property="revision">
      <string>49bfe4a3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541164208000</long>
      </object>
     </void>
     <void property="message">
      <string>remove unused import</string>
     </void>
     <void property="revision">
      <string>cdf56986</string>
     </void>
     <void property="tags">
      <string>1.1-rc70</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541163785000</long>
      </object>
     </void>
     <void property="message">
      <string>use __name__ to get a logger
    preparation for #2470</string>
     </void>
     <void property="revision">
      <string>27014975</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540998104000</long>
      </object>
     </void>
     <void property="message">
      <string>add better console logger (#2467)
    
    fixes #2466</string>
     </void>
     <void property="revision">
      <string>43bb8e2e</string>
     </void>
     <void property="tags">
      <string>1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540542513000</long>
      </object>
     </void>
     <void property="message">
      <string>fix headline</string>
     </void>
     <void property="revision">
      <string>67962695</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Nikolay Edigaryev &lt;edigaryev@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540069214000</long>
      </object>
     </void>
     <void property="message">
      <string>deploy.py: repackage WAR files using standard zipfile module
    
    This change removes dependency on jar/zip/unzip executables
    and simplifies code a bit.</string>
     </void>
     <void property="revision">
      <string>c55cba53</string>
     </void>
     <void property="tags">
      <string>1.1-rc65, 1.1-rc64</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539940838000</long>
      </object>
     </void>
     <void property="message">
      <string>Removing module &apos;all&apos; as it is not needed (#2427)</string>
     </void>
     <void property="revision">
      <string>d9ed2e6e</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539869934000</long>
      </object>
     </void>
     <void property="message">
      <string>moving all package to opengrok-tools</string>
     </void>
     <void property="revision">
      <string>394d7f37</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539076604000</long>
      </object>
     </void>
     <void property="message">
      <string>Packaging python scripts (#2389)
    
    fixes #2251</string>
     </void>
     <void property="revision">
      <string>7ac1f5d2</string>
     </void>
     <void property="tags">
      <string>1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
