<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569587058000</long>
      </object>
     </void>
     <void property="message">
      <string>rename parsers</string>
     </void>
     <void property="revision">
      <string>bb305b63</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562248094000</long>
      </object>
     </void>
     <void property="message">
      <string>Python mirror tool refactor and test (#2851)
    
    fixes #2849</string>
     </void>
     <void property="revision">
      <string>eb236da4</string>
     </void>
     <void property="tags">
      <string>1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562076949000</long>
      </object>
     </void>
     <void property="message">
      <string>Python tools improved incoming check (#2847)
    
    Improving --incoming check to check also the index presence
    for the particular project.
    
    After that, the name &quot;incoming&quot; could be a little misleading
    so I refactored the name to &quot;check changes&quot;.
    
    fixes #2844</string>
     </void>
     <void property="revision">
      <string>dd247241</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562067539000</long>
      </object>
     </void>
     <void property="message">
      <string>checking return values for incoming check (#2846)
    
     - refactoring the code to use the constants
    
    fixes #2843</string>
     </void>
     <void property="revision">
      <string>8805a059</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561227554000</long>
      </object>
     </void>
     <void property="message">
      <string>initialize logdir
    
    fixes #2823</string>
     </void>
     <void property="revision">
      <string>0149c871</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554989358000</long>
      </object>
     </void>
     <void property="message">
      <string>remove debug print</string>
     </void>
     <void property="revision">
      <string>1ef860ca</string>
     </void>
     <void property="tags">
      <string>1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554902078000</long>
      </object>
     </void>
     <void property="message">
      <string>fixups to mirroring functions (#2747)</string>
     </void>
     <void property="revision">
      <string>339e8d05</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554899188000</long>
      </object>
     </void>
     <void property="message">
      <string>parallelize repository mirroring (#2744)
    
    fixes #2743</string>
     </void>
     <void property="revision">
      <string>c8ea2017</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554712186000</long>
      </object>
     </void>
     <void property="message">
      <string>make it possible to mirror more projects at once (#2731)</string>
     </void>
     <void property="revision">
      <string>f3fa009a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552815540000</long>
      </object>
     </void>
     <void property="message">
      <string>moving repofactory to scm module
    
     - removing the cross module dependency forcing
       the imports to be in particular order</string>
     </void>
     <void property="revision">
      <string>19618883</string>
     </void>
     <void property="tags">
      <string>1.2.6, 1.2.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552898025000</long>
      </object>
     </void>
     <void property="message">
      <string>adding python tool specific version (#2720)
    
     - --version now reports the tool specific version along with the tools global version</string>
     </void>
     <void property="revision">
      <string>e1f92fa0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552225351000</long>
      </object>
     </void>
     <void property="message">
      <string>fail mirroring if incoming check raises exception (#2709)</string>
     </void>
     <void property="revision">
      <string>60bb8bf0</string>
     </void>
     <void property="tags">
      <string>1.2.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1543783015000</long>
      </object>
     </void>
     <void property="message">
      <string>allowing wildcards in mirror-config
    fixes #2568</string>
     </void>
     <void property="revision">
      <string>0c031679</string>
     </void>
     <void property="tags">
      <string>1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1542019819000</long>
      </object>
     </void>
     <void property="message">
      <string>Opengrok tools version --version (#2499)
    
    * moving version to a python file</string>
     </void>
     <void property="revision">
      <string>6da51376</string>
     </void>
     <void property="tags">
      <string>1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541780626000</long>
      </object>
     </void>
     <void property="message">
      <string>add loglevel arg to tools (#2493)
    
    fixes #2488</string>
     </void>
     <void property="revision">
      <string>89524e9b</string>
     </void>
     <void property="tags">
      <string>1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541520132000</long>
      </object>
     </void>
     <void property="message">
      <string>make sure the logger is inherited</string>
     </void>
     <void property="revision">
      <string>49bfe4a3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541531030000</long>
      </object>
     </void>
     <void property="message">
      <string>replace filelock with dependency (#2491)
    
    fixes #2490</string>
     </void>
     <void property="revision">
      <string>2965341b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541163785000</long>
      </object>
     </void>
     <void property="message">
      <string>use __name__ to get a logger
    preparation for #2470</string>
     </void>
     <void property="revision">
      <string>27014975</string>
     </void>
     <void property="tags">
      <string>1.1-rc70</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540998104000</long>
      </object>
     </void>
     <void property="message">
      <string>add better console logger (#2467)
    
    fixes #2466</string>
     </void>
     <void property="revision">
      <string>43bb8e2e</string>
     </void>
     <void property="tags">
      <string>1.1-rc69</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540542740000</long>
      </object>
     </void>
     <void property="message">
      <string>check URI
    fixes #2446</string>
     </void>
     <void property="revision">
      <string>61221f06</string>
     </void>
     <void property="tags">
      <string>1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539940838000</long>
      </object>
     </void>
     <void property="message">
      <string>Removing module &apos;all&apos; as it is not needed (#2427)</string>
     </void>
     <void property="revision">
      <string>d9ed2e6e</string>
     </void>
     <void property="tags">
      <string>1.1-rc65, 1.1-rc64</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539869934000</long>
      </object>
     </void>
     <void property="message">
      <string>moving all package to opengrok-tools</string>
     </void>
     <void property="revision">
      <string>394d7f37</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539338478000</long>
      </object>
     </void>
     <void property="message">
      <string>check incoming changes
    fixes #2399</string>
     </void>
     <void property="revision">
      <string>f73c656e</string>
     </void>
     <void property="tags">
      <string>1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539333580000</long>
      </object>
     </void>
     <void property="message">
      <string>instantiate repositories first</string>
     </void>
     <void property="revision">
      <string>ce212200</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539076604000</long>
      </object>
     </void>
     <void property="message">
      <string>Packaging python scripts (#2389)
    
    fixes #2251</string>
     </void>
     <void property="revision">
      <string>7ac1f5d2</string>
     </void>
     <void property="tags">
      <string>1.1-rc59</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
