<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1580384688000</long>
      </object>
     </void>
     <void property="message">
      <string>fix timeout inheritance in mirror.py (#3025)
    
    fixes #3022</string>
     </void>
     <void property="revision">
      <string>cf1700cd</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575883584000</long>
      </object>
     </void>
     <void property="message">
      <string>use __str__ of the Command class for logging consistently (#2999)
    
    fixes #2991
    
    Also fix transposition bug in commandsequence#run() logging</string>
     </void>
     <void property="revision">
      <string>82f67fa5</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569829733000</long>
      </object>
     </void>
     <void property="message">
      <string>log output continuously from hook runs
    
    fixes #2939</string>
     </void>
     <void property="revision">
      <string>e3c4fcc2</string>
     </void>
     <void property="tags">
      <string>1.3.5, 1.3.4, 1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569586959000</long>
      </object>
     </void>
     <void property="message">
      <string>re-enable printing to the console by default in opengrok-indexer
    
    also make --doprint toggle-able
    
    fixes #2935</string>
     </void>
     <void property="revision">
      <string>e2ecd552</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1568197789000</long>
      </object>
     </void>
     <void property="message">
      <string>handle exceptions when printing in OutputThread
    
    fixes #2926</string>
     </void>
     <void property="revision">
      <string>ec3dd02a</string>
     </void>
     <void property="tags">
      <string>1.3.2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1561234502000</long>
      </object>
     </void>
     <void property="message">
      <string>be more careful with err
    
    fixes #2824</string>
     </void>
     <void property="revision">
      <string>ac7a8cfa</string>
     </void>
     <void property="tags">
      <string>1.3.1, 1.3.0, 1.2.25, 1.2.24, 1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541429316000</long>
      </object>
     </void>
     <void property="message">
      <string>modify the opengrok-tools env paths on windows (#2463)</string>
     </void>
     <void property="revision">
      <string>c5f38475</string>
     </void>
     <void property="tags">
      <string>1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7, 1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541164229000</long>
      </object>
     </void>
     <void property="message">
      <string>avoid logging.basicConfig()</string>
     </void>
     <void property="revision">
      <string>a7a22da0</string>
     </void>
     <void property="tags">
      <string>1.1-rc70</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540390392000</long>
      </object>
     </void>
     <void property="message">
      <string>fix flake8</string>
     </void>
     <void property="revision">
      <string>dfa6eab6</string>
     </void>
     <void property="tags">
      <string>1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540389783000</long>
      </object>
     </void>
     <void property="message">
      <string>fix pylint reported problems</string>
     </void>
     <void property="revision">
      <string>26b3a826</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540381987000</long>
      </object>
     </void>
     <void property="message">
      <string>fix exception handling</string>
     </void>
     <void property="revision">
      <string>5bf5bbfd</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1539940838000</long>
      </object>
     </void>
     <void property="message">
      <string>Removing module &apos;all&apos; as it is not needed (#2427)</string>
     </void>
     <void property="revision">
      <string>d9ed2e6e</string>
     </void>
     <void property="tags">
      <string>1.1-rc65, 1.1-rc64</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
