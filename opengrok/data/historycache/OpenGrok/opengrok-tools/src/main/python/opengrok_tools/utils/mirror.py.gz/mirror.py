<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1580720166000</long>
      </object>
     </void>
     <void property="message">
      <string>fix comment</string>
     </void>
     <void property="revision">
      <string>f2b8e4af</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1580484593000</long>
      </object>
     </void>
     <void property="message">
      <string>fix style</string>
     </void>
     <void property="revision">
      <string>7024be0c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1580482355000</long>
      </object>
     </void>
     <void property="message">
      <string>make get_repos_for_project(), get_repository use kwargs
    
    add tests</string>
     </void>
     <void property="revision">
      <string>13dcf262</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1580384688000</long>
      </object>
     </void>
     <void property="message">
      <string>fix timeout inheritance in mirror.py (#3025)
    
    fixes #3022</string>
     </void>
     <void property="revision">
      <string>cf1700cd</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573466306000</long>
      </object>
     </void>
     <void property="message">
      <string>add command handling to mirror.py
    
    - refactor disabled command handling
    - add tests
    
    fixes #2973</string>
     </void>
     <void property="revision">
      <string>73485e9f</string>
     </void>
     <void property="tags">
      <string>1.3.7, 1.3.6, 1.3.5, 1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1569332507000</long>
      </object>
     </void>
     <void property="message">
      <string>check_project_configuration() should be more robust (#2933)
    
    in the face of empty per project dictionary</string>
     </void>
     <void property="revision">
      <string>71b37936</string>
     </void>
     <void property="tags">
      <string>1.3.3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563353892000</long>
      </object>
     </void>
     <void property="message">
      <string>fix arguments of get_project_properties()
    
    fixes #2862</string>
     </void>
     <void property="revision">
      <string>0715f9bd</string>
     </void>
     <void property="tags">
      <string>1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562248094000</long>
      </object>
     </void>
     <void property="message">
      <string>Python mirror tool refactor and test (#2851)
    
    fixes #2849</string>
     </void>
     <void property="revision">
      <string>eb236da4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562076949000</long>
      </object>
     </void>
     <void property="message">
      <string>Python tools improved incoming check (#2847)
    
    Improving --incoming check to check also the index presence
    for the particular project.
    
    After that, the name &quot;incoming&quot; could be a little misleading
    so I refactored the name to &quot;check changes&quot;.
    
    fixes #2844</string>
     </void>
     <void property="revision">
      <string>dd247241</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562067539000</long>
      </object>
     </void>
     <void property="message">
      <string>checking return values for incoming check (#2846)
    
     - refactoring the code to use the constants
    
    fixes #2843</string>
     </void>
     <void property="revision">
      <string>8805a059</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554902078000</long>
      </object>
     </void>
     <void property="message">
      <string>fixups to mirroring functions (#2747)</string>
     </void>
     <void property="revision">
      <string>339e8d05</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554712186000</long>
      </object>
     </void>
     <void property="message">
      <string>make it possible to mirror more projects at once (#2731)</string>
     </void>
     <void property="revision">
      <string>f3fa009a</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
