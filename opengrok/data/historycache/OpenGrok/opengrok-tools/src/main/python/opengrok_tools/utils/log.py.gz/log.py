<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562248094000</long>
      </object>
     </void>
     <void property="message">
      <string>Python mirror tool refactor and test (#2851)
    
    fixes #2849</string>
     </void>
     <void property="revision">
      <string>eb236da4</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5, 1.3.4, 1.3.3, 1.3.2, 1.3.1, 1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Kryštof Tulinger &lt;k.tulinger@seznam.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562067539000</long>
      </object>
     </void>
     <void property="message">
      <string>checking return values for incoming check (#2846)
    
     - refactoring the code to use the constants
    
    fixes #2843</string>
     </void>
     <void property="revision">
      <string>8805a059</string>
     </void>
     <void property="tags">
      <string>1.2.23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554902078000</long>
      </object>
     </void>
     <void property="message">
      <string>fixups to mirroring functions (#2747)</string>
     </void>
     <void property="revision">
      <string>339e8d05</string>
     </void>
     <void property="tags">
      <string>1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9, 1.2.8, 1.2.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554899188000</long>
      </object>
     </void>
     <void property="message">
      <string>parallelize repository mirroring (#2744)
    
    fixes #2743</string>
     </void>
     <void property="revision">
      <string>c8ea2017</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554712186000</long>
      </object>
     </void>
     <void property="message">
      <string>make it possible to mirror more projects at once (#2731)</string>
     </void>
     <void property="revision">
      <string>f3fa009a</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1552075194000</long>
      </object>
     </void>
     <void property="message">
      <string>logger must cover all levels</string>
     </void>
     <void property="revision">
      <string>0439bf23</string>
     </void>
     <void property="tags">
      <string>1.2.6, 1.2.5, 1.2.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541780626000</long>
      </object>
     </void>
     <void property="message">
      <string>add loglevel arg to tools (#2493)
    
    fixes #2488</string>
     </void>
     <void property="revision">
      <string>89524e9b</string>
     </void>
     <void property="tags">
      <string>1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0, 1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1541520132000</long>
      </object>
     </void>
     <void property="message">
      <string>make sure the logger is inherited</string>
     </void>
     <void property="revision">
      <string>49bfe4a3</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540998104000</long>
      </object>
     </void>
     <void property="message">
      <string>add better console logger (#2467)
    
    fixes #2466</string>
     </void>
     <void property="revision">
      <string>43bb8e2e</string>
     </void>
     <void property="tags">
      <string>1.1-rc70, 1.1-rc69</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
