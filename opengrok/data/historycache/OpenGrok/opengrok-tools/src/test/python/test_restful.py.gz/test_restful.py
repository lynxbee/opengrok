<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574690487000</long>
      </object>
     </void>
     <void property="message">
      <string>check command structure in call_rest_api()
    
    add tests</string>
     </void>
     <void property="revision">
      <string>c34ee2e8</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7, 1.3.6, 1.3.5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574684856000</long>
      </object>
     </void>
     <void property="message">
      <string>make call_rest_api() robust in the face of None args
    
    add tests for HTTP header handling</string>
     </void>
     <void property="revision">
      <string>5b8788be</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1574680591000</long>
      </object>
     </void>
     <void property="message">
      <string>add comment</string>
     </void>
     <void property="revision">
      <string>4454e308</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573227041000</long>
      </object>
     </void>
     <void property="message">
      <string>add missing param (verb)</string>
     </void>
     <void property="revision">
      <string>f207e559</string>
     </void>
     <void property="tags">
      <string>1.3.4</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1573221786000</long>
      </object>
     </void>
     <void property="message">
      <string>refactor call_rest_api(), add tests</string>
     </void>
     <void property="revision">
      <string>9040eb16</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
