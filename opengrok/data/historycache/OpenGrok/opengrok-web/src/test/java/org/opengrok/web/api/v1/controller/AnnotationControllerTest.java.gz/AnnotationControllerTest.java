<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Chris Fraire &lt;cfraire@me.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1584417411000</long>
      </object>
     </void>
     <void property="message">
      <string>Marshal random port through CONTAINER_PORT forced property</string>
     </void>
     <void property="revision">
      <string>fd17fd12</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1582726072000</long>
      </object>
     </void>
     <void property="message">
      <string>implement annotation API endpoint
    
    fixes #3046</string>
     </void>
     <void property="revision">
      <string>754a7a39</string>
     </void>
     <void property="tags">
      <string>1.3.9</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
