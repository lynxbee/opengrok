<?xml version="1.0" encoding="UTF-8"?>
<java version="1.8.0_242" class="java.beans.XMLDecoder">
 <object class="org.opengrok.indexer.history.History" id="History0">
  <void property="historyEntries">
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1578683632000</long>
      </object>
     </void>
     <void property="message">
      <string>disable AppVeyor</string>
     </void>
     <void property="revision">
      <string>b2b9cf7e</string>
     </void>
     <void property="tags">
      <string>1.3.11, 1.3.10, 1.3.9, 1.3.8, 1.3.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1575308202000</long>
      </object>
     </void>
     <void property="message">
      <string>remove Wercker badge</string>
     </void>
     <void property="revision">
      <string>a984fba3</string>
     </void>
     <void property="tags">
      <string>1.3.6</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1564581505000</long>
      </object>
     </void>
     <void property="message">
      <string>capitals</string>
     </void>
     <void property="revision">
      <string>c9c55d5c</string>
     </void>
     <void property="tags">
      <string>1.3.5, 1.3.4, 1.3.3, 1.3.2, 1.3.1</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1563453781000</long>
      </object>
     </void>
     <void property="message">
      <string>bump year</string>
     </void>
     <void property="revision">
      <string>5e0c6b22</string>
     </void>
     <void property="tags">
      <string>1.3.0, 1.2.25, 1.2.24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1562150385000</long>
      </object>
     </void>
     <void property="message">
      <string>fix broken link</string>
     </void>
     <void property="revision">
      <string>ff3edb47</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Shenghan Gao &lt;shenghang@nvidia.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1558655183000</long>
      </object>
     </void>
     <void property="message">
      <string>change according to review</string>
     </void>
     <void property="revision">
      <string>4aedc80c</string>
     </void>
     <void property="tags">
      <string>1.2.23, 1.2.22, 1.2.21, 1.2.20, 1.2.19, 1.2.18, 1.2.17, 1.2.16, 1.2.15, 1.2.14, 1.2.13, 1.2.12, 1.2.11, 1.2.10, 1.2.9</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1554213949000</long>
      </object>
     </void>
     <void property="message">
      <string>demo site unavailable</string>
     </void>
     <void property="revision">
      <string>79dec9c2</string>
     </void>
     <void property="tags">
      <string>1.2.8, 1.2.7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1545916085000</long>
      </object>
     </void>
     <void property="message">
      <string>mention docker image</string>
     </void>
     <void property="revision">
      <string>40e6c66e</string>
     </void>
     <void property="tags">
      <string>1.2.6, 1.2.5, 1.2.4, 1.2.3, 1.2.2, 1.2.1, 1.2.0, 1.1.2, 1.1.1, 1.1.0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1540326178000</long>
      </object>
     </void>
     <void property="message">
      <string>mention Slack</string>
     </void>
     <void property="revision">
      <string>2af09da3</string>
     </void>
     <void property="tags">
      <string>1.1, 1.1-rc82, 1.1-rc81, 1.1-rc80, 1.1-rc79, 1.1-rc78, 1.1-rc77, 1.1-rc76, 1.1-rc75, 1.1-rc74, 1.1-rc73, 1.1-rc72, 1.1-rc71, 1.1-rc70, 1.1-rc69, 1.1-rc68, 1.1-rc67, 1.1-rc66</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1535639174000</long>
      </object>
     </void>
     <void property="message">
      <string>add license badge</string>
     </void>
     <void property="revision">
      <string>3059077e</string>
     </void>
     <void property="tags">
      <string>1.1-rc65, 1.1-rc64, 1.1-rc63, 1.1-rc62, 1.1-rc61, 1.1-rc60, 1.1-rc59, 1.1-rc58, 1.1-rc57, 1.1-rc56, 1.1-rc55, 1.1-rc54, 1.1-rc53, 1.1-rc52, 1.1-rc51, 1.1-rc50, 1.1-rc49, 1.1-rc47, 1.1-rc46, 1.1-rc44, 1.1-rc43, 1.1-rc42, 1.1-rc41, 1.1-rc40, 1.1-rc39</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1534407312000</long>
      </object>
     </void>
     <void property="message">
      <string>add AppVeyor badge</string>
     </void>
     <void property="revision">
      <string>0a6524d0</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1533237299000</long>
      </object>
     </void>
     <void property="message">
      <string>change the Sonar link to point to the report</string>
     </void>
     <void property="revision">
      <string>cb50956b</string>
     </void>
     <void property="tags">
      <string>1.1-rc38, 1.1-rc37, 1.1-rc36</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1525087480000</long>
      </object>
     </void>
     <void property="message">
      <string>enable SonarQube checker
    fixes #2090</string>
     </void>
     <void property="revision">
      <string>cb86d517</string>
     </void>
     <void property="tags">
      <string>1.1-rc35, 1.1-rc34, 1.1-rc33, 1.1-rc32, 1.1-rc31, 1.1-rc30, 1.1-rc29, 1.1-rc28, 1.1-rc27, 1.1-rc26</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1532717417000</long>
      </object>
     </void>
     <void property="message">
      <string>cleanup</string>
     </void>
     <void property="revision">
      <string>b79fbf80</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531230570000</long>
      </object>
     </void>
     <void property="message">
      <string>remove search CLI</string>
     </void>
     <void property="revision">
      <string>386b37ca</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531149601000</long>
      </object>
     </void>
     <void property="message">
      <string>another linewrap formatting fix</string>
     </void>
     <void property="revision">
      <string>b7573543</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531149524000</long>
      </object>
     </void>
     <void property="message">
      <string>fix linewrap formatting</string>
     </void>
     <void property="revision">
      <string>97dfe5c2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531149446000</long>
      </object>
     </void>
     <void property="message">
      <string>fix formatting of the bootstrap command</string>
     </void>
     <void property="revision">
      <string>20499cae</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531145352000</long>
      </object>
     </void>
     <void property="message">
      <string>move to Wiki</string>
     </void>
     <void property="revision">
      <string>d942e6e2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1531142530000</long>
      </object>
     </void>
     <void property="message">
      <string>replace Messages with RESTful API call</string>
     </void>
     <void property="revision">
      <string>12a6a780</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530442296000</long>
      </object>
     </void>
     <void property="message">
      <string>Update README to REST API</string>
     </void>
     <void property="revision">
      <string>32763715</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530261678000</long>
      </object>
     </void>
     <void property="message">
      <string>omit error message</string>
     </void>
     <void property="revision">
      <string>0ec9e9c8</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1530095416000</long>
      </object>
     </void>
     <void property="message">
      <string>add Wercker badge</string>
     </void>
     <void property="revision">
      <string>6daa3676</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1529683896000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix issues with indexer package renaming</string>
     </void>
     <void property="revision">
      <string>686556f2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1528301695000</long>
      </object>
     </void>
     <void property="message">
      <string>Add demo link to README</string>
     </void>
     <void property="revision">
      <string>8c095922</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1527859455000</long>
      </object>
     </void>
     <void property="message">
      <string>ignore history should be per project tunable
    fixes #1728</string>
     </void>
     <void property="revision">
      <string>2b892162</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1527607401000</long>
      </object>
     </void>
     <void property="message">
      <string>shorten the author section</string>
     </void>
     <void property="revision">
      <string>34b2d0e5</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1527607205000</long>
      </object>
     </void>
     <void property="message">
      <string>Update Servlet API to 3.1 (#2131)</string>
     </void>
     <void property="revision">
      <string>532ab028</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1524152062000</long>
      </object>
     </void>
     <void property="message">
      <string>mention Maven</string>
     </void>
     <void property="revision">
      <string>9b3c5397</string>
     </void>
     <void property="tags">
      <string>1.1-rc25, 1.1-rc24</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1524139234000</long>
      </object>
     </void>
     <void property="message">
      <string>add Coveralls.io link</string>
     </void>
     <void property="revision">
      <string>2b96a331</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@icloud.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523963194000</long>
      </object>
     </void>
     <void property="message">
      <string>&apos;org.opensolaris.opengrok&apos; -&gt; &apos;org.opengrok&apos;
    fixes #1778</string>
     </void>
     <void property="revision">
      <string>56f072ca</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523891424000</long>
      </object>
     </void>
     <void property="message">
      <string>move OS specific scripts/files to separate repository</string>
     </void>
     <void property="revision">
      <string>e4984526</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523374476000</long>
      </object>
     </void>
     <void property="message">
      <string>move Messages content to wiki</string>
     </void>
     <void property="revision">
      <string>5a11068f</string>
     </void>
     <void property="tags">
      <string>1.1-rc23</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523367537000</long>
      </object>
     </void>
     <void property="message">
      <string>move developer info to wiki</string>
     </void>
     <void property="revision">
      <string>f08a97bf</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523367336000</long>
      </object>
     </void>
     <void property="message">
      <string>move tuning content to wiki</string>
     </void>
     <void property="revision">
      <string>0b77564c</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523366579000</long>
      </object>
     </void>
     <void property="message">
      <string>move more content about webapp config to wiki</string>
     </void>
     <void property="revision">
      <string>7098e0fc</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1523366260000</long>
      </object>
     </void>
     <void property="message">
      <string>move content to wiki</string>
     </void>
     <void property="revision">
      <string>17eea3d7</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>John Eismeier &lt;32205350+jeis2497052@users.noreply.github.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1519328729000</long>
      </object>
     </void>
     <void property="message">
      <string>Propose fix some typos (#2025)</string>
     </void>
     <void property="revision">
      <string>c375d8c9</string>
     </void>
     <void property="tags">
      <string>1.1-rc22</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;vlada@devnull.cz&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1515602776000</long>
      </object>
     </void>
     <void property="message">
      <string>add repository mirroring scripts</string>
     </void>
     <void property="revision">
      <string>e2f6c3e7</string>
     </void>
     <void property="tags">
      <string>1.1-rc21, 1.1-rc20, 1.1-rc19</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Bruno Borges &lt;bruno.borges@gmail.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1513728174000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix README with badge from travis-ci/oracle</string>
     </void>
     <void property="revision">
      <string>2ef9c29b</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;Vladimir.Kotal@Oracle.COM&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1513002388000</long>
      </object>
     </void>
     <void property="message">
      <string>try to describe logging</string>
     </void>
     <void property="revision">
      <string>822cda18</string>
     </void>
     <void property="tags">
      <string>1.1-rc18</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Ivo Raisr &lt;ivosh@ivosh.net&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512863321000</long>
      </object>
     </void>
     <void property="message">
      <string>Table of contents with navigation.</string>
     </void>
     <void property="revision">
      <string>bb9873dd</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Ivo Raisr &lt;ivosh@ivosh.net&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512580685000</long>
      </object>
     </void>
     <void property="message">
      <string>Download junit and hamcrest jar files automatically by ant.
    
    hamcrest is a dependency for junit, so check that first.
    Fix also README.md instructions.</string>
     </void>
     <void property="revision">
      <string>bb8ee6ac</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Ivo Raisr &lt;ivosh@ivosh.net&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1512510909000</long>
      </object>
     </void>
     <void property="message">
      <string>Fix a typo in README.md</string>
     </void>
     <void property="revision">
      <string>d74fc6b2</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Vladimir Kotal &lt;Vladimir.Kotal@Oracle.COM&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1507033702000</long>
      </object>
     </void>
     <void property="message">
      <string>add get-repos-type Message</string>
     </void>
     <void property="revision">
      <string>d683b7d7</string>
     </void>
     <void property="tags">
      <string>1.1-rc17, 1.1-rc16</string>
     </void>
    </object>
   </void>
   <void method="add">
    <object class="org.opengrok.indexer.history.HistoryEntry">
     <void property="active">
      <boolean>true</boolean>
     </void>
     <void property="author">
      <string>Adam Hornáček &lt;adam.hornacek@oracle.com&gt;</string>
     </void>
     <void property="date">
      <object class="java.util.Date">
       <long>1504107732000</long>
      </object>
     </void>
     <void property="message">
      <string>Rewrite README.txt to use markdown syntax</string>
     </void>
     <void property="revision">
      <string>c55d5891</string>
     </void>
     <void property="tags">
      <string>1.1-rc15, 1.1-rc14</string>
     </void>
    </object>
   </void>
  </void>
 </object>
</java>
