<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>[![](<a href="https://images.microbadger.com/badges/image/opengrok/docker.svg)">https://images.microbadger.com/badges/image/opengrok/docker.svg)</a>](<a href="https://microbadger.com/images/opengrok/docker">https://microbadger.com/images/opengrok/docker</a> &quot;Get your own image badge on <a href="/source/s?path=microbadger.com&amp;project=OpenGrok">microbadger.com</a>&quot;)
<a class="l" name="2" href="#2">2</a>[![](<a href="https://images.microbadger.com/badges/version/opengrok/docker.svg)">https://images.microbadger.com/badges/version/opengrok/docker.svg)</a>](<a href="https://microbadger.com/images/opengrok/docker">https://microbadger.com/images/opengrok/docker</a> &quot;Get your own version badge on <a href="/source/s?path=microbadger.com&amp;project=OpenGrok">microbadger.com</a>&quot;)
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a># A Docker container for OpenGrok
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>## OpenGrok from official source
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>Built from official source: <a href="https://github.com/oracle/opengrok/releases/">https://github.com/oracle/opengrok/releases/</a>
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>You can learn more about OpenGrok at <a href="http://oracle.github.io/opengrok/">http://oracle.github.io/opengrok/</a>
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>The container is available from DockerHub at <a href="https://hub.docker.com/r/opengrok/docker/">https://hub.docker.com/r/opengrok/docker/</a>
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>## When not to use it
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>This image is simple wrapper around OpenGrok environment. It is basically a small appliance. The indexer and the web container are **not** tuned for large workloads.
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a>If you happen to have one of the following:
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a>  - large source data (<a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> [AOSP](<a href="https://en.wikipedia.org/wiki/Android_Open_Source_Project)">https://en.wikipedia.org/wiki/Android_Open_Source_Project)</a> or the like)
<a class="l" name="21" href="#21">21</a>  - stable service
<a class="l" name="22" href="#22">22</a>  - Source Code Management systems not supported in the image (<a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> Perforce,
<a class="l" name="23" href="#23">23</a>    Clearcase, etc.)
<a class="l" name="24" href="#24">24</a>  - need for <a href="/source/s?path=authentication/authorization&amp;project=OpenGrok">authentication/authorization</a>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>then it is advisable to run OpenGrok standalone or construct your own Docker
<a class="l" name="27" href="#27">27</a>image based on the official one.
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>## Additional info about the image
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>* Tomcat 9
<a class="l" name="32" href="#32">32</a>* JRE 8 (Required for Opengrok 1.0+)
<a class="l" name="33" href="#33">33</a>* Configurable <a href="/source/s?path=mirroring/reindexing&amp;project=OpenGrok">mirroring/reindexing</a> (default every 10 min)
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>The mirroring step works by going through all projects and attempting to
<a class="l" name="36" href="#36">36</a>synchronize all its repositories (<a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> it will do `git pull` for Git
<a class="l" name="37" href="#37">37</a>repositories).
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>### Indexer logs
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>The <a href="/source/s?path=indexer/mirroring&amp;project=OpenGrok">indexer/mirroring</a> is set so that it does not log into files.
<a class="l" name="42" href="#42">42</a>Rather, everything goes to standard (error) output. To see how the indexer
<a class="l" name="43" href="#43">43</a>is doing, use the `docker logs` command.
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>### Source Code Management systems supported
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>- Mercurial
<a class="l" name="48" href="#48">48</a>- Git
<a class="l" name="49" href="#49">49</a>- Subversion
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>### Tags and versioning
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>Each OpenGrok release triggers creation of new Docker image.
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>| Tag      | Note                                                    |
<a class="l" name="56" href="#56">56</a>| -------- |:--------------------------------------------------------|
<a class="l" name="57" href="#57">57</a>| `latest` | tracks the latest version                               |
<a class="l" name="58" href="#58">58</a>| `<a href="/source/s?path=x.y.z&amp;project=OpenGrok">x.y.z</a>`  | if you want to pin against a specific version           |
<a class="l" name="59" href="#59">59</a>| `<a href="/source/s?path=x.y&amp;project=OpenGrok">x.y</a>`    | stay on micro versions to avoid reindexing from scratch |
<a class="hl" name="60" href="#60">60</a>
<a class="l" name="61" href="#61">61</a>## How to run
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>### From DockerHub
<a class="l" name="64" href="#64">64</a>
<a class="l" name="65" href="#65">65</a>    docker run -d -v &lt;<a href="/source/s?path=path/to/your/src&amp;project=OpenGrok">path/to/your/src</a>&gt;:<a href="/source/s?path=/opengrok/src&amp;project=OpenGrok">/opengrok/src</a> -p 8080:8080 <a href="/source/s?path=opengrok/docker&amp;project=OpenGrok">opengrok/docker</a>:latest
<a class="l" name="66" href="#66">66</a>
<a class="l" name="67" href="#67">67</a>The container exports ports 8080 for OpenGrok.
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>The volume mounted to `<a href="/source/s?path=/opengrok/src&amp;project=OpenGrok">/opengrok/src</a>` should contain the projects you want to make searchable (in sub directories). You can use common revision control checkouts (git, svn, etc...) and OpenGrok will make history and blame information available.
<a class="hl" name="70" href="#70">70</a>
<a class="l" name="71" href="#71">71</a>## Environment Variables
<a class="l" name="72" href="#72">72</a>
<a class="l" name="73" href="#73">73</a>| Docker Environment Var. | Description |
<a class="l" name="74" href="#74">74</a>| ----------------------- | ----------- |
<a class="l" name="75" href="#75">75</a>`REINDEX: &lt;time_in_minutes&gt;`&lt;br/&gt; *Optional* *Default: 10* | Period of automatic <a href="/source/s?path=mirroring/reindexing&amp;project=OpenGrok">mirroring/reindexing</a>. Setting to `0` will disable automatic indexing. You can manually trigger an reindex using docker exec: `docker exec &lt;container&gt; <a href="/source/s?path=/scripts/index.sh&amp;project=OpenGrok">/scripts/index.sh</a>`
<a class="l" name="76" href="#76">76</a>`INDEXER_OPT` | pass extra options to opengrok-indexer. For example, &quot;-i d:vendor&quot; will remove all the `*/vendor/*` files from the index. You can check the indexer options on <a href="https://github.com/oracle/opengrok/wiki/Python-scripts-transition-guide">https://github.com/oracle/opengrok/wiki/Python-scripts-transition-guide</a>
<a class="l" name="77" href="#77">77</a>`NOMIRROR` | To avoid the mirroring step, set the variable to non-empty value.
<a class="l" name="78" href="#78">78</a>
<a class="l" name="79" href="#79">79</a>To specify environment variable for `docker run`, use the `-e` option, <a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> `-e REINDEX=30`
<a class="hl" name="80" href="#80">80</a>
<a class="l" name="81" href="#81">81</a>## OpenGrok Web-Interface
<a class="l" name="82" href="#82">82</a>
<a class="l" name="83" href="#83">83</a>The container has OpenGrok as default web app installed (accessible directly from `/`). With the above container setup, you can find it running on
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a><a href="http://localhost:8080/">http://localhost:8080/</a>
<a class="l" name="86" href="#86">86</a>
<a class="l" name="87" href="#87">87</a>The first reindex will take some time to finish. Subsequent reindex will be incremental so will take signigicantly less time.
<a class="l" name="88" href="#88">88</a>
<a class="l" name="89" href="#89">89</a>## Using Docker compose
<a class="hl" name="90" href="#90">90</a>
<a class="l" name="91" href="#91">91</a>[Docker-compose](<a href="https://docs.docker.com/compose/install/)">https://docs.docker.com/compose/install/)</a> example:
<a class="l" name="92" href="#92">92</a>
<a class="l" name="93" href="#93">93</a>```yaml
<a class="l" name="94" href="#94">94</a>version: &quot;3&quot;
<a class="l" name="95" href="#95">95</a>
<a class="l" name="96" href="#96">96</a># More info at <a href="https://github.com/oracle/opengrok/docker/">https://github.com/oracle/opengrok/docker/</a>
<a class="l" name="97" href="#97">97</a>services:
<a class="l" name="98" href="#98">98</a>  opengrok:
<a class="l" name="99" href="#99">99</a>    container_name: opengrok
<a class="hl" name="100" href="#100">100</a>    image: <a href="/source/s?path=opengrok/docker&amp;project=OpenGrok">opengrok/docker</a>:latest
<a class="l" name="101" href="#101">101</a>    ports:
<a class="l" name="102" href="#102">102</a>      - &quot;8080:8080/tcp&quot;
<a class="l" name="103" href="#103">103</a>    environment:
<a class="l" name="104" href="#104">104</a>      REINDEX: &apos;60&apos;
<a class="l" name="105" href="#105">105</a>    # Volumes store your data between container upgrades
<a class="l" name="106" href="#106">106</a>    volumes:
<a class="l" name="107" href="#107">107</a>       - &apos;~/opengrok-src/:<a href="/source/s?path=/opengrok/src&amp;project=OpenGrok">/opengrok/src</a>/&apos;  # source code
<a class="l" name="108" href="#108">108</a>       - &apos;~/opengrok-etc/:<a href="/source/s?path=/opengrok/etc&amp;project=OpenGrok">/opengrok/etc</a>/&apos;  # folder contains <a href="/source/s?path=configuration.xml&amp;project=OpenGrok">configuration.xml</a>
<a class="l" name="109" href="#109">109</a>       - &apos;~/opengrok-data/:<a href="/source/s?path=/opengrok/data&amp;project=OpenGrok">/opengrok/data</a>/&apos;  # index and other things for source code
<a class="hl" name="110" href="#110">110</a>```
<a class="l" name="111" href="#111">111</a>
<a class="l" name="112" href="#112">112</a>Save the file into `<a href="/source/s?path=docker-compose.yml&amp;project=OpenGrok">docker-compose.yml</a>` and then simply run
<a class="l" name="113" href="#113">113</a>
<a class="l" name="114" href="#114">114</a>    docker-compose up -d
<a class="l" name="115" href="#115">115</a>
<a class="l" name="116" href="#116">116</a>Equivalent `docker run` command would look like this:
<a class="l" name="117" href="#117">117</a>
<a class="l" name="118" href="#118">118</a>```bash
<a class="l" name="119" href="#119">119</a>docker run -d \
<a class="hl" name="120" href="#120">120</a>    --name opengrok \
<a class="l" name="121" href="#121">121</a>    -p 8080:8080/tcp \
<a class="l" name="122" href="#122">122</a>    -e REINDEX=&quot;60&quot; \
<a class="l" name="123" href="#123">123</a>    -v ~/opengrok-src/:<a href="/source/s?path=/opengrok/src&amp;project=OpenGrok">/opengrok/src</a>/ \
<a class="l" name="124" href="#124">124</a>    -v ~/opengrok-etc/:<a href="/source/s?path=/opengrok/etc&amp;project=OpenGrok">/opengrok/etc</a>/ \
<a class="l" name="125" href="#125">125</a>    -v ~/opengrok-data/:<a href="/source/s?path=/opengrok/data&amp;project=OpenGrok">/opengrok/data</a>/ \
<a class="l" name="126" href="#126">126</a>    <a href="/source/s?path=opengrok/docker&amp;project=OpenGrok">opengrok/docker</a>:latest
<a class="l" name="127" href="#127">127</a>```
<a class="l" name="128" href="#128">128</a>
<a class="l" name="129" href="#129">129</a>## Build image locally
<a class="hl" name="130" href="#130">130</a>
<a class="l" name="131" href="#131">131</a>If you want to do your own development, you can build the image yourself:
<a class="l" name="132" href="#132">132</a>
<a class="l" name="133" href="#133">133</a>    docker build -t opengrok-dev .
<a class="l" name="134" href="#134">134</a>
<a class="l" name="135" href="#135">135</a>Then run the container:
<a class="l" name="136" href="#136">136</a>
<a class="l" name="137" href="#137">137</a>    docker run -d -v &lt;<a href="/source/s?path=path/to/your/src&amp;project=OpenGrok">path/to/your/src</a>&gt;:<a href="/source/s?path=/opengrok/src&amp;project=OpenGrok">/opengrok/src</a> -p 8080:8080 opengrok-dev
<a class="l" name="138" href="#138">138</a>
<a class="l" name="139" href="#139">139</a>## Inspecting the container
<a class="hl" name="140" href="#140">140</a>
<a class="l" name="141" href="#141">141</a>You can get inside a container using the [command below](<a href="https://docs.docker.com/engine/reference/commandline/exec/):">https://docs.docker.com/engine/reference/commandline/exec/):</a>
<a class="l" name="142" href="#142">142</a>
<a class="l" name="143" href="#143">143</a>```bash
<a class="l" name="144" href="#144">144</a>docker exec -it &lt;container&gt; bash
<a class="l" name="145" href="#145">145</a>```
<a class="l" name="146" href="#146">146</a>
<a class="l" name="147" href="#147">147</a>Enjoy.
<a class="l" name="148" href="#148">148</a>