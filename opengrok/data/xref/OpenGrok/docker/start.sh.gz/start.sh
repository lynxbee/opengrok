<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["indexer",8]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/bin/&amp;project=OpenGrok">bin</a>/<a href="/source/s?path=/bin/bash&amp;project=OpenGrok">bash</a></span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c"># default period for reindexing (in minutes)</span>
<a class="l" name="4" href="#4">4</a><b>if</b> [ -z <span class="s">&quot;<a href="/source/s?refs=%24REINDEX&amp;project=OpenGrok">$REINDEX</a>&quot;</span> ]; <b>then</b>
<a class="l" name="5" href="#5">5</a>	<a href="/source/s?defs=REINDEX&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">REINDEX</a>=<span class="n">10</span>
<a class="l" name="6" href="#6">6</a><b>fi</b>
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><a class="xf" name="indexer"/><a href="/source/s?refs=indexer&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">indexer</a>(){
<a class="l" name="9" href="#9">9</a>	<span class="c"># Wait for Tomcat startup.</span>
<a class="hl" name="10" href="#10">10</a>	<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> +<span class="s">&quot;%F %T Waiting for Tomcat startup...&quot;</span>
<a class="l" name="11" href="#11">11</a>	<b>while</b> [ <span class="s">&quot;</span>`<a href="/source/s?defs=curl&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">curl</a> --<a href="/source/s?defs=silent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">silent</a> --<a href="/source/s?defs=write&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">write</a>-<a href="/source/s?defs=out&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">out</a> <span class="s">&apos;%{response_code}&apos;</span> -o /<a href="/source/s?path=/dev/&amp;project=OpenGrok">dev</a>/<a href="/source/s?path=/dev/null&amp;project=OpenGrok">null</a> <span class="s">&apos;<a href="http://localhost:8080/">http://localhost:8080/</a>&apos;</span>`<span class="s">&quot;</span> == <span class="s">&quot;000&quot;</span> ]; <b>do</b>
<a class="l" name="12" href="#12">12</a>		<a href="/source/s?defs=sleep&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sleep</a> <span class="n">1</span>;
<a class="l" name="13" href="#13">13</a>	<b>done</b>
<a class="l" name="14" href="#14">14</a>	<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> +<span class="s">&quot;%F %T Startup finished&quot;</span>
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>	<b>if</b> [[ ! -d /<a href="/source/s?path=/opengrok/&amp;project=OpenGrok">opengrok</a>/<a href="/source/s?path=/opengrok/data/&amp;project=OpenGrok">data</a>/<a href="/source/s?path=/opengrok/data/index&amp;project=OpenGrok">index</a> ]]; <b>then</b>
<a class="l" name="17" href="#17">17</a>		<span class="c"># Populate the webapp with bare configuration.</span>
<a class="l" name="18" href="#18">18</a>		<a href="/source/s?defs=BODY_INCLUDE_FILE&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">BODY_INCLUDE_FILE</a>=<span class="s">&quot;/<a href="/source/s?path=/opengrok/&amp;project=OpenGrok">opengrok</a>/<a href="/source/s?path=/opengrok/data/&amp;project=OpenGrok">data</a>/<a href="/source/s?path=/opengrok/data/body_include&amp;project=OpenGrok">body_include</a>&quot;</span>
<a class="l" name="19" href="#19">19</a>		<b>if</b> [[ -f <a href="/source/s?defs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$BODY_INCLUDE_FILE</a> ]]; <b>then</b>
<a class="hl" name="20" href="#20">20</a>			<a href="/source/s?defs=mv&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">mv</a> <span class="s">&quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>&quot; &quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>.orig&quot;</span>
<a class="l" name="21" href="#21">21</a>		<b>fi</b>
<a class="l" name="22" href="#22">22</a>		<b>echo</b> <span class="s">&apos;&lt;p&gt;&lt;h1&gt;Waiting on the initial reindex to finish.. Stay tuned !&lt;/h1&gt;&lt;/p&gt;&apos;</span> &gt; <span class="s">&quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>&quot;</span>
<a class="l" name="23" href="#23">23</a>		/<a href="/source/s?path=/scripts/&amp;project=OpenGrok">scripts</a>/<a href="/source/s?path=/scripts/index.sh&amp;project=OpenGrok">index.sh</a> --<a href="/source/s?defs=noIndex&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">noIndex</a>
<a class="l" name="24" href="#24">24</a>		<a href="/source/s?defs=rm&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">rm</a> -f <span class="s">&quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>&quot;</span>
<a class="l" name="25" href="#25">25</a>		<b>if</b> [[ -f <a href="/source/s?defs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$BODY_INCLUDE_FILE</a>.<a href="/source/s?defs=orig&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">orig</a> ]]; <b>then</b>
<a class="l" name="26" href="#26">26</a>			<a href="/source/s?defs=mv&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">mv</a> <span class="s">&quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>.orig&quot; &quot;<a href="/source/s?refs=%24BODY_INCLUDE_FILE&amp;project=OpenGrok">$BODY_INCLUDE_FILE</a>&quot;</span>
<a class="l" name="27" href="#27">27</a>		<b>fi</b>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>		<span class="c"># Perform initial indexing.</span>
<a class="hl" name="30" href="#30">30</a>		<a href="/source/s?defs=NOMIRROR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">NOMIRROR</a>=<span class="n">1</span> /<a href="/source/s?path=/scripts/&amp;project=OpenGrok">scripts</a>/<a href="/source/s?path=/scripts/index.sh&amp;project=OpenGrok">index.sh</a>
<a class="l" name="31" href="#31">31</a>		<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> +<span class="s">&quot;%F %T Initial reindex finished&quot;</span>
<a class="l" name="32" href="#32">32</a>	<b>fi</b>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>	<span class="c"># Continue to index every $REINDEX minutes.</span>
<a class="l" name="35" href="#35">35</a>	<b>if</b> [ <span class="s">&quot;<a href="/source/s?refs=%24REINDEX&amp;project=OpenGrok">$REINDEX</a>&quot;</span> == <span class="s">&quot;0&quot;</span> ]; <b>then</b>
<a class="l" name="36" href="#36">36</a>		<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> +<span class="s">&quot;%F %T Automatic reindexing disabled&quot;</span>
<a class="l" name="37" href="#37">37</a>		<b>return</b>
<a class="l" name="38" href="#38">38</a>	<b>else</b>
<a class="l" name="39" href="#39">39</a>		<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> +<span class="s">&quot;%F %T Automatic reindexing in <a href="/source/s?refs=%24REINDEX&amp;project=OpenGrok">$REINDEX</a> minutes...&quot;</span>
<a class="hl" name="40" href="#40">40</a>	<b>fi</b>
<a class="l" name="41" href="#41">41</a>	<b>while</b> <b>true</b>; <b>do</b>
<a class="l" name="42" href="#42">42</a>		<a href="/source/s?defs=sleep&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sleep</a> `<a href="/source/s?defs=expr&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">expr</a> <span class="n">60</span> \* <a href="/source/s?defs=%24REINDEX&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$REINDEX</a>`
<a class="l" name="43" href="#43">43</a>		/<a href="/source/s?path=/scripts/&amp;project=OpenGrok">scripts</a>/<a href="/source/s?path=/scripts/index.sh&amp;project=OpenGrok">index.sh</a>
<a class="l" name="44" href="#44">44</a>	<b>done</b>
<a class="l" name="45" href="#45">45</a>}
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a><span class="c"># Start all necessary services.</span>
<a class="l" name="48" href="#48">48</a><a class="d intelliWindow-symbol" href="#indexer" data-definition-place="defined-in-file">indexer</a> &amp;
<a class="l" name="49" href="#49">49</a><a href="/source/s?path=catalina.sh&amp;project=OpenGrok">catalina.sh</a> <a href="/source/s?defs=run&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">run</a>
<a class="hl" name="50" href="#50">50</a>