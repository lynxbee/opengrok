<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["bug15890",26]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">// -*- coding: utf-8 -*-</span>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * Test for bug #15890. Ctags and JFlex do not agree on line
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * numbering. JFlex regards \u000B, \u000C, \u0085, \u2028 and \u2029
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * as line terminator, whereas ctags doesn&apos;t. If one of these
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> * characters occurred in a file, definitions that came after it would
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * not be recognized as definitions by the xrefs, since the line
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * numbers didn&apos;t match what ctags returned.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">/* This line contains \u000B:  */</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span><span class="c">/* This line contains \u000C:  */</span>
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span><span class="c">/* This line contains \u0085: &#133; */</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><span class="c">/* This line contains \u2028: &#8232; */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/* This line contains \u2029: &#8233; */</span>
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span> * Now add a definition for the tests to check.
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<span id='scope_id_244e994f' class='scope-head'><span class='scope-signature'>bug15890(int x)</span><a class="l" name="26" href="#26">26</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_244e994f_fold_icon'><span class='fold-icon'>&nbsp;</span></a><b>int</b> <a class="xf" name="bug15890"/><a href="/source/s?refs=bug15890&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">bug15890</a>(<b>int</b> <a class="xa" name="x"/><a href="/source/s?refs=x&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">x</a>)</span>
<span id='scope_id_244e994f_fold' class='scope-body'><a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>&#123;
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span>  <b>return</b> <a class="d intelliWindow-symbol" href="#x" data-definition-place="defined-in-file">x</a><span class="n">+1</span>&#59;
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>&#125;
</span><a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>