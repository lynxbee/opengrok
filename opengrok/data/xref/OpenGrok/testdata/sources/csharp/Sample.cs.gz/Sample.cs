<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["InnerClass",32],["TopClass",9]]],["Namespace","xn",[["MyNamespace",3]]],["Method","xmt",[["M1",10],["M2",12],["M3",19],["M5",34]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><b>using</b> <a href="/source/s?defs=System&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">System</a>&#59;
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><b>namespace</b> <a class="xn" name="MyNamespace"/><a href="/source/s?refs=MyNamespace&amp;project=OpenGrok" class="xn intelliWindow-symbol" data-definition-place="def">MyNamespace</a>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span>&#123;
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span>    <span class="c">/// &lt;summary&gt;</span>
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>    <span class="c">/// summary</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span>    <span class="c">/// &lt;/summary&gt;</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span>    [<a href="/source/s?defs=Tag&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Tag</a>]
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span>    <b>class</b> <a class="xc" name="TopClass"/><a href="/source/s?refs=TopClass&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">TopClass</a> &#123;
<span id='scope_id_56659c24' class='scope-head'><span class='scope-signature'>M1()</span><a class="hl" name="10" href="#10">10</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_56659c24_fold_icon'><span class='fold-icon'>&nbsp;</span></a>        <b>public</b> <b>int</b> <a class="xmt" name="M1"/><a href="/source/s?refs=M1&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">M1</a>() &#123; &#125;
</span><a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>
<span id='scope_id_5681cee7' class='scope-head'><span class='scope-signature'>M2()</span><a class="l" name="12" href="#12">12</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_5681cee7_fold_icon'><span class='fold-icon'>&nbsp;</span></a>        <b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="M2"/><a href="/source/s?refs=M2&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">M2</a>() &#123;</span>
<span id='scope_id_5681cee7_fold' class='scope-body'><a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span>            <span class="c">//public static int MERR() {}</span>
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span>        &#125;
</span><a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>        <span class="c">/// &lt;summary&gt;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span>        <span class="c">/// sum</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span>        <span class="c">/// &lt;/summary&gt;</span>
<span id='scope_id_56e4772f' class='scope-head'><span class='scope-signature'>M3()</span><a class="l" name="19" href="#19">19</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_56e4772f_fold_icon'><span class='fold-icon'>&nbsp;</span></a>        <b>public</b> <b>void</b> <a class="xmt" name="M3"/><a href="/source/s?refs=M3&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">M3</a>()</span>
<span id='scope_id_56e4772f_fold' class='scope-body'><a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span>        &#123;
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span>            <span class="c">/* hi
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span>                public static int MERR() {
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>                }
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>            */</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>        &#125;
</span><a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>        [<a href="/source/s?defs=Tag&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Tag</a>]
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span>        <b>private</b> <a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a> <a href="/source/s?defs=M4&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">M4</a>&lt;<a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a>&gt;(<a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a> <a href="/source/s?defs=p&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">p</a>) <b>where</b> <a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a> : <b>new</b>()
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>        &#123;
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>        &#125;
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>        <b>public</b> <b>class</b> <a class="xc" name="InnerClass"/><a href="/source/s?refs=InnerClass&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">InnerClass</a>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>        &#123;
<span id='scope_id_6017bae1' class='scope-head'><span class='scope-signature'>M5(int x)</span><a class="l" name="34" href="#34">34</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_6017bae1_fold_icon'><span class='fold-icon'>&nbsp;</span></a>            <b>private</b> <b>string</b> <a class="xmt" name="M5"/><a href="/source/s?refs=M5&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">M5</a>(<b>int</b> <a class="xa" name="x"/><a href="/source/s?refs=x&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">x</a>) &#123;</span>
<span id='scope_id_6017bae1_fold' class='scope-body'><a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>                <b>return</b> <b>null</b>&#59;
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>            &#125;
</span><a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>        &#125;
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>    &#123;
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>