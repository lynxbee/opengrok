<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">-- test case for bug #18586 - ArrayIndexOutOfBoundsException when indexing SQL file</span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><b>create</b> <b>table</b> <a class="d" name="abcdef"/><a href="/source/s?refs=abcdef&amp;project=OpenGrok" class="d intelliWindow-symbol" data-definition-place="def">abcdef</a>(
<a class="l" name="4" href="#4">4</a>  <a class="xfld" name="x"/><a href="/source/s?refs=x&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">x</a> <b>int</b>,
<a class="l" name="5" href="#5">5</a>  <a class="xfld" name="y"/><a href="/source/s?refs=y&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">y</a> <b>int</b>);
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a><b>insert</b> <b>into</b> <a class="d intelliWindow-symbol" href="#abcdef" data-definition-place="defined-in-file">abcdef</a> <b>values</b> (<span class="n">1</span>,<span class="n">2</span>), (<span class="n">3</span>,<span class="n">4</span>);
<a class="l" name="8" href="#8">8</a>