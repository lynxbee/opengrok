<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>CREATE</b> <b>TABLE</b> <a class="d" name="foo"/><a href="/source/s?refs=foo&amp;project=OpenGrok" class="d intelliWindow-symbol" data-definition-place="def">foo</a> (
<a class="l" name="2" href="#2">2</a>   <a class="xfld" name="col1"/><a href="/source/s?refs=col1&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">col1</a> <b>INT</b> <b>NOT</b> <b>NULL</b> <b>PRIMARY</b> <a href="/source/s?defs=KEY&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">KEY</a>,
<a class="l" name="3" href="#3">3</a>   <a class="xfld" name="col2"/><a href="/source/s?refs=col2&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">col2</a> <b>VARCHAR</b>(<span class="n">100</span>)
<a class="l" name="4" href="#4">4</a>);
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><b>SELECT</b> * <b>FROM</b> <a class="d intelliWindow-symbol" href="#foo" data-definition-place="defined-in-file">foo</a>;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a><b>INSERT</b> <b>INTO</b> <a class="d intelliWindow-symbol" href="#foo" data-definition-place="defined-in-file">foo</a> (<a class="d intelliWindow-symbol" href="#col1" data-definition-place="defined-in-file">col1</a>, <a class="d intelliWindow-symbol" href="#col2" data-definition-place="defined-in-file">col2</a>) <b>VALUES</b> (<span class="n">1</span>, <span class="s">&apos;something&apos;</span>), (<span class="n">5</span>, <span class="s">&apos;something else&apos;</span>);
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a><span class="c">-- This is an SQL comment with a email address: username@example.com</span>
<a class="l" name="11" href="#11">11</a><b>DELETE</b> <b>FROM</b> <a class="d intelliWindow-symbol" href="#foo" data-definition-place="defined-in-file">foo</a> <b>WHERE</b> <a href="/source/s?defs=id&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">id</a>=<span class="n">5</span>;
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a><b>SELECT</b> <b>COUNT</b>(<a class="d intelliWindow-symbol" href="#col1" data-definition-place="defined-in-file">col1</a>) <b>FROM</b> <a class="d intelliWindow-symbol" href="#foo" data-definition-place="defined-in-file">foo</a>;
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a><span class="c">-- This en an SQL comment with strange characters: &lt;, &gt; and &amp;</span>
<a class="l" name="16" href="#16">16</a><b>DROP</b> <b>TABLE</b> <span class="s">&quot;foo&quot;</span>;
<a class="l" name="17" href="#17">17</a>
<a class="l" name="18" href="#18">18</a><b>CREATE</b> <b>TABLE</b> <span class="s">&quot;foo&quot;&quot;&quot;</span>;
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><span class="c">/* Other supported comment */</span>
<a class="l" name="21" href="#21">21</a><b>SELECT</b> <span class="n">123.45</span> + <span class="n">543E-2</span> <b>FROM</b> <a href="/source/s?defs=DUAL&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DUAL</a>;
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a><span class="c">/* /* Comment inside comment */ */</span>
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><span class="c">-- Text values:</span>
<a class="l" name="26" href="#26">26</a><b>INSERT</b> <b>INTO</b> <a class="d intelliWindow-symbol" href="#foo" data-definition-place="defined-in-file">foo</a>(<a class="d intelliWindow-symbol" href="#col2" data-definition-place="defined-in-file">col2</a>) <b>VALUES</b> (<span class="s">&apos;this&apos;</span>), (<span class="s">&apos;and this&apos;</span>), (<span class="s">&apos;and &apos;&apos; too&apos;</span>);
<a class="l" name="27" href="#27">27</a>