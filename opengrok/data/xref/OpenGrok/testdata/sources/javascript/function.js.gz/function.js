<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["date",5],["ndate",29],["numberliteral",25],["ref",7],["sameobjectasndate",30]]],["Function","xf",[["main",18]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">/*
<a class="l" name="2" href="#2">2</a> * Sample js program
<a class="l" name="3" href="#3">3</a> */</span>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a><b>var</b> <a class="xv" name="date"/><a href="/source/s?refs=date&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">date</a> = <b>new</b> <b>Date</b>(<span class="n">96</span>, <span class="n">11</span>, <span class="n">25</span>);
<a class="l" name="6" href="#6">6</a><span class="c">//reference</span>
<a class="l" name="7" href="#7">7</a><b>var</b> <a class="xv" name="ref"/><a href="/source/s?refs=ref&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">ref</a> = <a class="d intelliWindow-symbol" href="#date" data-definition-place="defined-in-file">date</a>;
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a><a class="d intelliWindow-symbol" href="#ref" data-definition-place="defined-in-file">ref</a>.<a href="/source/s?defs=setDate&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">setDate</a>(<span class="n">21</span>);
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a><a class="d intelliWindow-symbol" href="#date" data-definition-place="defined-in-file">date</a>.<a href="/source/s?defs=getDate&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getDate</a>(); <span class="c">//21</span>
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a><span class="c">// The same is true when objects and arrays are passed to functions.</span>
<a class="l" name="14" href="#14">14</a><span class="c">// The following function adds a value to each element of an array.</span>
<a class="l" name="15" href="#15">15</a><span class="c">// A reference to the array is passed to the function, not a copy of the array.</span>
<a class="l" name="16" href="#16">16</a><span class="c">// Therefore, the function can change the contents of the array through</span>
<a class="l" name="17" href="#17">17</a><span class="c">// the reference, and those changes will be visible when the function returns.</span>
<a class="l" name="18" href="#18">18</a><b>function</b> <a class="xf" name="main"/><a href="/source/s?refs=main&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">main</a>(<a class="xa" name="totals"/><a href="/source/s?refs=totals&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">totals</a>, <a class="xa" name="x"/><a href="/source/s?refs=x&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">x</a>)
<a class="l" name="19" href="#19">19</a>{
<a class="hl" name="20" href="#20">20</a>    <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">0</span>] = <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">0</span>] + <a class="d intelliWindow-symbol" href="#x" data-definition-place="defined-in-file">x</a>;
<a class="l" name="21" href="#21">21</a>    <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">1</span>] = <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">1</span>] + <a class="d intelliWindow-symbol" href="#x" data-definition-place="defined-in-file">x</a>;
<a class="l" name="22" href="#22">22</a>    <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">2</span>] = <a class="d intelliWindow-symbol" href="#totals" data-definition-place="defined-in-file">totals</a>[<span class="n">2</span>] + <a class="d intelliWindow-symbol" href="#x" data-definition-place="defined-in-file">x</a>;
<a class="l" name="23" href="#23">23</a>}
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a><b>var</b> <a class="xv" name="numberliteral"/><a href="/source/s?refs=numberliteral&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">numberliteral</a> = <span class="n">0x4f</span>;
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>(<a class="d intelliWindow-symbol" href="#date" data-definition-place="defined-in-file">date</a> == <a class="d intelliWindow-symbol" href="#ref" data-definition-place="defined-in-file">ref</a>)           <span class="c">// Evaluates to true</span>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><b>var</b> <a class="xv" name="ndate"/><a href="/source/s?refs=ndate&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">ndate</a>= <b>new</b> <b>Date</b>(<span class="n">96</span>, <span class="n">11</span>, <span class="n">25</span>);
<a class="hl" name="30" href="#30">30</a><b>var</b> <a class="xv" name="sameobjectasndate"/><a href="/source/s?refs=sameobjectasndate&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">sameobjectasndate</a> = <b>new</b> <b>Date</b>(<span class="n">96</span>, <span class="n">11</span>, <span class="n">25</span>);
<a class="l" name="31" href="#31">31</a>
<a class="l" name="32" href="#32">32</a>(<a class="d intelliWindow-symbol" href="#ndate" data-definition-place="defined-in-file">ndate</a> != <a class="d intelliWindow-symbol" href="#sameobjectasndate" data-definition-place="defined-in-file">sameobjectasndate</a>)    <span class="c">// true !</span>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>