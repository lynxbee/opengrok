<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Macro","xm",[["BKEXLIB_HPP",2]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span>#<b>ifndef</b> <a class="d intelliWindow-symbol" href="#BKEXLIB_HPP" data-definition-place="defined-in-file">BKEXLIB_HPP</a>
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>#<b>define</b> <a class="xm" name="BKEXLIB_HPP"/><a href="/source/s?refs=BKEXLIB_HPP&amp;project=OpenGrok" class="xm intelliWindow-symbol" data-definition-place="def">BKEXLIB_HPP</a>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span><b>int</b> <a href="/source/s?defs=getRandomNumber&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getRandomNumber</a>(<b>void</b>)&#59;
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span><b>int</b> <a href="/source/s?defs=butActuallyThough&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">butActuallyThough</a>(<b>void</b>)&#59;
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span>#<b>endif</b> <span class="c">/* BKEXLIB_HPP */</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span>