<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/source/s?path=stdlib.h&amp;project=OpenGrok">stdlib.h</a>&gt;
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>#<b>include</b> &lt;<a href="/source/s?path=stdio.h&amp;project=OpenGrok">stdio.h</a>&gt;
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span>