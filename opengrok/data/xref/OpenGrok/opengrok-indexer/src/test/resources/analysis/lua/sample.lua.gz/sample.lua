<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["[MIME_TYPES.form_url_encoded]",268],["[MIME_TYPES.json]",257],["[MIME_TYPES.multipart]",250],["_M.get_body_args",341],["_M.get_body_info",347],["get_body_info",283]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">--</span>
<a class="l" name="2" href="#2">2</a><span class="c">--                                  Apache License</span>
<a class="l" name="3" href="#3">3</a><span class="c">--                            Version 2.0, January 2004</span>
<a class="l" name="4" href="#4">4</a><span class="c">--                         <a href="http://www.apache.org/licenses/">http://www.apache.org/licenses/</a></span>
<a class="l" name="5" href="#5">5</a><span class="c">--</span>
<a class="l" name="6" href="#6">6</a><span class="c">--    TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION</span>
<a class="l" name="7" href="#7">7</a><span class="c">--</span>
<a class="l" name="8" href="#8">8</a><span class="c">--    1. Definitions.</span>
<a class="l" name="9" href="#9">9</a><span class="c">--</span>
<a class="hl" name="10" href="#10">10</a><span class="c">--       &quot;License&quot; shall mean the terms and conditions for use, reproduction,</span>
<a class="l" name="11" href="#11">11</a><span class="c">--       and distribution as defined by Sections 1 through 9 of this document.</span>
<a class="l" name="12" href="#12">12</a><span class="c">--</span>
<a class="l" name="13" href="#13">13</a><span class="c">--       &quot;Licensor&quot; shall mean the copyright owner or entity authorized by</span>
<a class="l" name="14" href="#14">14</a><span class="c">--       the copyright owner that is granting the License.</span>
<a class="l" name="15" href="#15">15</a><span class="c">--</span>
<a class="l" name="16" href="#16">16</a><span class="c">--       &quot;Legal Entity&quot; shall mean the union of the acting entity and all</span>
<a class="l" name="17" href="#17">17</a><span class="c">--       other entities that control, are controlled by, or are under common</span>
<a class="l" name="18" href="#18">18</a><span class="c">--       control with that entity. For the purposes of this definition,</span>
<a class="l" name="19" href="#19">19</a><span class="c">--       &quot;control&quot; means (i) the power, direct or indirect, to cause the</span>
<a class="hl" name="20" href="#20">20</a><span class="c">--       direction or management of such entity, whether by contract or</span>
<a class="l" name="21" href="#21">21</a><span class="c">--       otherwise, or (ii) ownership of fifty percent (50%) or more of the</span>
<a class="l" name="22" href="#22">22</a><span class="c">--       outstanding shares, or (iii) beneficial ownership of such entity.</span>
<a class="l" name="23" href="#23">23</a><span class="c">--</span>
<a class="l" name="24" href="#24">24</a><span class="c">--       &quot;You&quot; (or &quot;Your&quot;) shall mean an individual or Legal Entity</span>
<a class="l" name="25" href="#25">25</a><span class="c">--       exercising permissions granted by this License.</span>
<a class="l" name="26" href="#26">26</a><span class="c">--</span>
<a class="l" name="27" href="#27">27</a><span class="c">--       &quot;Source&quot; form shall mean the preferred form for making modifications,</span>
<a class="l" name="28" href="#28">28</a><span class="c">--       including but not limited to software source code, documentation</span>
<a class="l" name="29" href="#29">29</a><span class="c">--       source, and configuration files.</span>
<a class="hl" name="30" href="#30">30</a><span class="c">--</span>
<a class="l" name="31" href="#31">31</a><span class="c">--       &quot;Object&quot; form shall mean any form resulting from mechanical</span>
<a class="l" name="32" href="#32">32</a><span class="c">--       transformation or translation of a Source form, including but</span>
<a class="l" name="33" href="#33">33</a><span class="c">--       not limited to compiled object code, generated documentation,</span>
<a class="l" name="34" href="#34">34</a><span class="c">--       and conversions to other media types.</span>
<a class="l" name="35" href="#35">35</a><span class="c">--</span>
<a class="l" name="36" href="#36">36</a><span class="c">--       &quot;Work&quot; shall mean the work of authorship, whether in Source or</span>
<a class="l" name="37" href="#37">37</a><span class="c">--       Object form, made available under the License, as indicated by a</span>
<a class="l" name="38" href="#38">38</a><span class="c">--       copyright notice that is included in or attached to the work</span>
<a class="l" name="39" href="#39">39</a><span class="c">--       (an example is provided in the Appendix below).</span>
<a class="hl" name="40" href="#40">40</a><span class="c">--</span>
<a class="l" name="41" href="#41">41</a><span class="c">--       &quot;Derivative Works&quot; shall mean any work, whether in Source or Object</span>
<a class="l" name="42" href="#42">42</a><span class="c">--       form, that is based on (or derived from) the Work and for which the</span>
<a class="l" name="43" href="#43">43</a><span class="c">--       editorial revisions, annotations, elaborations, or other modifications</span>
<a class="l" name="44" href="#44">44</a><span class="c">--       represent, as a whole, an original work of authorship. For the purposes</span>
<a class="l" name="45" href="#45">45</a><span class="c">--       of this License, Derivative Works shall not include works that remain</span>
<a class="l" name="46" href="#46">46</a><span class="c">--       separable from, or merely link (or bind by name) to the interfaces of,</span>
<a class="l" name="47" href="#47">47</a><span class="c">--       the Work and Derivative Works thereof.</span>
<a class="l" name="48" href="#48">48</a><span class="c">--</span>
<a class="l" name="49" href="#49">49</a><span class="c">--       &quot;Contribution&quot; shall mean any work of authorship, including</span>
<a class="hl" name="50" href="#50">50</a><span class="c">--       the original version of the Work and any modifications or additions</span>
<a class="l" name="51" href="#51">51</a><span class="c">--       to that Work or Derivative Works thereof, that is intentionally</span>
<a class="l" name="52" href="#52">52</a><span class="c">--       submitted to Licensor for inclusion in the Work by the copyright owner</span>
<a class="l" name="53" href="#53">53</a><span class="c">--       or by an individual or Legal Entity authorized to submit on behalf of</span>
<a class="l" name="54" href="#54">54</a><span class="c">--       the copyright owner. For the purposes of this definition, &quot;submitted&quot;</span>
<a class="l" name="55" href="#55">55</a><span class="c">--       means any form of electronic, verbal, or written communication sent</span>
<a class="l" name="56" href="#56">56</a><span class="c">--       to the Licensor or its representatives, including but not limited to</span>
<a class="l" name="57" href="#57">57</a><span class="c">--       communication on electronic mailing lists, source code control systems,</span>
<a class="l" name="58" href="#58">58</a><span class="c">--       and issue tracking systems that are managed by, or on behalf of, the</span>
<a class="l" name="59" href="#59">59</a><span class="c">--       Licensor for the purpose of discussing and improving the Work, but</span>
<a class="hl" name="60" href="#60">60</a><span class="c">--       excluding communication that is conspicuously marked or otherwise</span>
<a class="l" name="61" href="#61">61</a><span class="c">--       designated in writing by the copyright owner as &quot;Not a Contribution.&quot;</span>
<a class="l" name="62" href="#62">62</a><span class="c">--</span>
<a class="l" name="63" href="#63">63</a><span class="c">--       &quot;Contributor&quot; shall mean Licensor and any individual or Legal Entity</span>
<a class="l" name="64" href="#64">64</a><span class="c">--       on behalf of whom a Contribution has been received by Licensor and</span>
<a class="l" name="65" href="#65">65</a><span class="c">--       subsequently incorporated within the Work.</span>
<a class="l" name="66" href="#66">66</a><span class="c">--</span>
<a class="l" name="67" href="#67">67</a><span class="c">--    2. Grant of Copyright License. Subject to the terms and conditions of</span>
<a class="l" name="68" href="#68">68</a><span class="c">--       this License, each Contributor hereby grants to You a perpetual,</span>
<a class="l" name="69" href="#69">69</a><span class="c">--       worldwide, non-exclusive, no-charge, royalty-free, irrevocable</span>
<a class="hl" name="70" href="#70">70</a><span class="c">--       copyright license to reproduce, prepare Derivative Works of,</span>
<a class="l" name="71" href="#71">71</a><span class="c">--       publicly display, publicly perform, sublicense, and distribute the</span>
<a class="l" name="72" href="#72">72</a><span class="c">--       Work and such Derivative Works in Source or Object form.</span>
<a class="l" name="73" href="#73">73</a><span class="c">--</span>
<a class="l" name="74" href="#74">74</a><span class="c">--    3. Grant of Patent License. Subject to the terms and conditions of</span>
<a class="l" name="75" href="#75">75</a><span class="c">--       this License, each Contributor hereby grants to You a perpetual,</span>
<a class="l" name="76" href="#76">76</a><span class="c">--       worldwide, non-exclusive, no-charge, royalty-free, irrevocable</span>
<a class="l" name="77" href="#77">77</a><span class="c">--       (except as stated in this section) patent license to make, have made,</span>
<a class="l" name="78" href="#78">78</a><span class="c">--       use, offer to sell, sell, import, and otherwise transfer the Work,</span>
<a class="l" name="79" href="#79">79</a><span class="c">--       where such license applies only to those patent claims licensable</span>
<a class="hl" name="80" href="#80">80</a><span class="c">--       by such Contributor that are necessarily infringed by their</span>
<a class="l" name="81" href="#81">81</a><span class="c">--       Contribution(s) alone or by combination of their Contribution(s)</span>
<a class="l" name="82" href="#82">82</a><span class="c">--       with the Work to which such Contribution(s) was submitted. If You</span>
<a class="l" name="83" href="#83">83</a><span class="c">--       institute patent litigation against any entity (including a</span>
<a class="l" name="84" href="#84">84</a><span class="c">--       cross-claim or counterclaim in a lawsuit) alleging that the Work</span>
<a class="l" name="85" href="#85">85</a><span class="c">--       or a Contribution incorporated within the Work constitutes direct</span>
<a class="l" name="86" href="#86">86</a><span class="c">--       or contributory patent infringement, then any patent licenses</span>
<a class="l" name="87" href="#87">87</a><span class="c">--       granted to You under this License for that Work shall terminate</span>
<a class="l" name="88" href="#88">88</a><span class="c">--       as of the date such litigation is filed.</span>
<a class="l" name="89" href="#89">89</a><span class="c">--</span>
<a class="hl" name="90" href="#90">90</a><span class="c">--    4. Redistribution. You may reproduce and distribute copies of the</span>
<a class="l" name="91" href="#91">91</a><span class="c">--       Work or Derivative Works thereof in any medium, with or without</span>
<a class="l" name="92" href="#92">92</a><span class="c">--       modifications, and in Source or Object form, provided that You</span>
<a class="l" name="93" href="#93">93</a><span class="c">--       meet the following conditions:</span>
<a class="l" name="94" href="#94">94</a><span class="c">--</span>
<a class="l" name="95" href="#95">95</a><span class="c">--       (a) You must give any other recipients of the Work or</span>
<a class="l" name="96" href="#96">96</a><span class="c">--           Derivative Works a copy of this License; and</span>
<a class="l" name="97" href="#97">97</a><span class="c">--</span>
<a class="l" name="98" href="#98">98</a><span class="c">--       (b) You must cause any modified files to carry prominent notices</span>
<a class="l" name="99" href="#99">99</a><span class="c">--           stating that You changed the files; and</span>
<a class="hl" name="100" href="#100">100</a><span class="c">--</span>
<a class="l" name="101" href="#101">101</a><span class="c">--       (c) You must retain, in the Source form of any Derivative Works</span>
<a class="l" name="102" href="#102">102</a><span class="c">--           that You distribute, all copyright, patent, trademark, and</span>
<a class="l" name="103" href="#103">103</a><span class="c">--           attribution notices from the Source form of the Work,</span>
<a class="l" name="104" href="#104">104</a><span class="c">--           excluding those notices that do not pertain to any part of</span>
<a class="l" name="105" href="#105">105</a><span class="c">--           the Derivative Works; and</span>
<a class="l" name="106" href="#106">106</a><span class="c">--</span>
<a class="l" name="107" href="#107">107</a><span class="c">--       (d) If the Work includes a &quot;NOTICE&quot; text file as part of its</span>
<a class="l" name="108" href="#108">108</a><span class="c">--           distribution, then any Derivative Works that You distribute must</span>
<a class="l" name="109" href="#109">109</a><span class="c">--           include a readable copy of the attribution notices contained</span>
<a class="hl" name="110" href="#110">110</a><span class="c">--           within such NOTICE file, excluding those notices that do not</span>
<a class="l" name="111" href="#111">111</a><span class="c">--           pertain to any part of the Derivative Works, in at least one</span>
<a class="l" name="112" href="#112">112</a><span class="c">--           of the following places: within a NOTICE text file distributed</span>
<a class="l" name="113" href="#113">113</a><span class="c">--           as part of the Derivative Works; within the Source form or</span>
<a class="l" name="114" href="#114">114</a><span class="c">--           documentation, if provided along with the Derivative Works; or,</span>
<a class="l" name="115" href="#115">115</a><span class="c">--           within a display generated by the Derivative Works, if and</span>
<a class="l" name="116" href="#116">116</a><span class="c">--           wherever such third-party notices normally appear. The contents</span>
<a class="l" name="117" href="#117">117</a><span class="c">--           of the NOTICE file are for informational purposes only and</span>
<a class="l" name="118" href="#118">118</a><span class="c">--           do not modify the License. You may add Your own attribution</span>
<a class="l" name="119" href="#119">119</a><span class="c">--           notices within Derivative Works that You distribute, alongside</span>
<a class="hl" name="120" href="#120">120</a><span class="c">--           or as an addendum to the NOTICE text from the Work, provided</span>
<a class="l" name="121" href="#121">121</a><span class="c">--           that such additional attribution notices cannot be construed</span>
<a class="l" name="122" href="#122">122</a><span class="c">--           as modifying the License.</span>
<a class="l" name="123" href="#123">123</a><span class="c">--</span>
<a class="l" name="124" href="#124">124</a><span class="c">--       You may add Your own copyright statement to Your modifications and</span>
<a class="l" name="125" href="#125">125</a><span class="c">--       may provide additional or different license terms and conditions</span>
<a class="l" name="126" href="#126">126</a><span class="c">--       for use, reproduction, or distribution of Your modifications, or</span>
<a class="l" name="127" href="#127">127</a><span class="c">--       for any such Derivative Works as a whole, provided Your use,</span>
<a class="l" name="128" href="#128">128</a><span class="c">--       reproduction, and distribution of the Work otherwise complies with</span>
<a class="l" name="129" href="#129">129</a><span class="c">--       the conditions stated in this License.</span>
<a class="hl" name="130" href="#130">130</a><span class="c">--</span>
<a class="l" name="131" href="#131">131</a><span class="c">--    5. Submission of Contributions. Unless You explicitly state otherwise,</span>
<a class="l" name="132" href="#132">132</a><span class="c">--       any Contribution intentionally submitted for inclusion in the Work</span>
<a class="l" name="133" href="#133">133</a><span class="c">--       by You to the Licensor shall be under the terms and conditions of</span>
<a class="l" name="134" href="#134">134</a><span class="c">--       this License, without any additional terms or conditions.</span>
<a class="l" name="135" href="#135">135</a><span class="c">--       Notwithstanding the above, nothing herein shall supersede or modify</span>
<a class="l" name="136" href="#136">136</a><span class="c">--       the terms of any separate license agreement you may have executed</span>
<a class="l" name="137" href="#137">137</a><span class="c">--       with Licensor regarding such Contributions.</span>
<a class="l" name="138" href="#138">138</a><span class="c">--</span>
<a class="l" name="139" href="#139">139</a><span class="c">--    6. Trademarks. This License does not grant permission to use the trade</span>
<a class="hl" name="140" href="#140">140</a><span class="c">--       names, trademarks, service marks, or product names of the Licensor,</span>
<a class="l" name="141" href="#141">141</a><span class="c">--       except as required for reasonable and customary use in describing the</span>
<a class="l" name="142" href="#142">142</a><span class="c">--       origin of the Work and reproducing the content of the NOTICE file.</span>
<a class="l" name="143" href="#143">143</a><span class="c">--</span>
<a class="l" name="144" href="#144">144</a><span class="c">--    7. Disclaimer of Warranty. Unless required by applicable law or</span>
<a class="l" name="145" href="#145">145</a><span class="c">--       agreed to in writing, Licensor provides the Work (and each</span>
<a class="l" name="146" href="#146">146</a><span class="c">--       Contributor provides its Contributions) on an &quot;AS IS&quot; BASIS,</span>
<a class="l" name="147" href="#147">147</a><span class="c">--       WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or</span>
<a class="l" name="148" href="#148">148</a><span class="c">--       implied, including, without limitation, any warranties or conditions</span>
<a class="l" name="149" href="#149">149</a><span class="c">--       of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A</span>
<a class="hl" name="150" href="#150">150</a><span class="c">--       PARTICULAR PURPOSE. You are solely responsible for determining the</span>
<a class="l" name="151" href="#151">151</a><span class="c">--       appropriateness of using or redistributing the Work and assume any</span>
<a class="l" name="152" href="#152">152</a><span class="c">--       risks associated with Your exercise of permissions under this License.</span>
<a class="l" name="153" href="#153">153</a><span class="c">--</span>
<a class="l" name="154" href="#154">154</a><span class="c">--    8. Limitation of Liability. In no event and under no legal theory,</span>
<a class="l" name="155" href="#155">155</a><span class="c">--       whether in tort (including negligence), contract, or otherwise,</span>
<a class="l" name="156" href="#156">156</a><span class="c">--       unless required by applicable law (such as deliberate and grossly</span>
<a class="l" name="157" href="#157">157</a><span class="c">--       negligent acts) or agreed to in writing, shall any Contributor be</span>
<a class="l" name="158" href="#158">158</a><span class="c">--       liable to You for damages, including any direct, indirect, special,</span>
<a class="l" name="159" href="#159">159</a><span class="c">--       incidental, or consequential damages of any character arising as a</span>
<a class="hl" name="160" href="#160">160</a><span class="c">--       result of this License or out of the use or inability to use the</span>
<a class="l" name="161" href="#161">161</a><span class="c">--       Work (including but not limited to damages for loss of goodwill,</span>
<a class="l" name="162" href="#162">162</a><span class="c">--       work stoppage, computer failure or malfunction, or any and all</span>
<a class="l" name="163" href="#163">163</a><span class="c">--       other commercial damages or losses), even if such Contributor</span>
<a class="l" name="164" href="#164">164</a><span class="c">--       has been advised of the possibility of such damages.</span>
<a class="l" name="165" href="#165">165</a><span class="c">--</span>
<a class="l" name="166" href="#166">166</a><span class="c">--    9. Accepting Warranty or Additional Liability. While redistributing</span>
<a class="l" name="167" href="#167">167</a><span class="c">--       the Work or Derivative Works thereof, You may choose to offer,</span>
<a class="l" name="168" href="#168">168</a><span class="c">--       and charge a fee for, acceptance of support, warranty, indemnity,</span>
<a class="l" name="169" href="#169">169</a><span class="c">--       or other liability obligations <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> rights consistent with this</span>
<a class="hl" name="170" href="#170">170</a><span class="c">--       License. However, in accepting such obligations, You may act only</span>
<a class="l" name="171" href="#171">171</a><span class="c">--       on Your own behalf and on Your sole responsibility, not on behalf</span>
<a class="l" name="172" href="#172">172</a><span class="c">--       of any other Contributor, and only if You agree to indemnify,</span>
<a class="l" name="173" href="#173">173</a><span class="c">--       defend, and hold each Contributor harmless for any liability</span>
<a class="l" name="174" href="#174">174</a><span class="c">--       incurred by, or claims asserted against, such Contributor by reason</span>
<a class="l" name="175" href="#175">175</a><span class="c">--       of your accepting any such warranty or additional liability.</span>
<a class="l" name="176" href="#176">176</a><span class="c">--</span>
<a class="l" name="177" href="#177">177</a><span class="c">--    END OF TERMS AND CONDITIONS</span>
<a class="l" name="178" href="#178">178</a><span class="c">--</span>
<a class="l" name="179" href="#179">179</a><span class="c">--    APPENDIX: How to apply the Apache License to your work.</span>
<a class="hl" name="180" href="#180">180</a><span class="c">--</span>
<a class="l" name="181" href="#181">181</a><span class="c">--       To apply the Apache License to your work, attach the following</span>
<a class="l" name="182" href="#182">182</a><span class="c">--       boilerplate notice, with the fields enclosed by brackets &quot;[]&quot;</span>
<a class="l" name="183" href="#183">183</a><span class="c">--       replaced with your own identifying information. (Don&apos;t include</span>
<a class="l" name="184" href="#184">184</a><span class="c">--       the brackets!)  The text should be enclosed in the appropriate</span>
<a class="l" name="185" href="#185">185</a><span class="c">--       comment syntax for the file format. We also recommend that a</span>
<a class="l" name="186" href="#186">186</a><span class="c">--       file or class name and description of purpose be included on the</span>
<a class="l" name="187" href="#187">187</a><span class="c">--       same &quot;printed page&quot; as the copyright notice for easier</span>
<a class="l" name="188" href="#188">188</a><span class="c">--       identification within third-party archives.</span>
<a class="l" name="189" href="#189">189</a><span class="c">--</span>
<a class="hl" name="190" href="#190">190</a><span class="c">--    Copyright 2016-2017 Kong Inc.</span>
<a class="l" name="191" href="#191">191</a><span class="c">--</span>
<a class="l" name="192" href="#192">192</a><span class="c">--    Licensed under the Apache License, Version 2.0 (the &quot;License&quot;);</span>
<a class="l" name="193" href="#193">193</a><span class="c">--    you may not use this file except in compliance with the License.</span>
<a class="l" name="194" href="#194">194</a><span class="c">--    You may obtain a copy of the License at</span>
<a class="l" name="195" href="#195">195</a><span class="c">--</span>
<a class="l" name="196" href="#196">196</a><span class="c">--        <a href="http://www.apache.org/licenses/LICENSE-2.0">http://www.apache.org/licenses/LICENSE-2.0</a></span>
<a class="l" name="197" href="#197">197</a><span class="c">--</span>
<a class="l" name="198" href="#198">198</a><span class="c">--    Unless required by applicable law or agreed to in writing, software</span>
<a class="l" name="199" href="#199">199</a><span class="c">--    distributed under the License is distributed on an &quot;AS IS&quot; BASIS,</span>
<a class="hl" name="200" href="#200">200</a><span class="c">--    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.</span>
<a class="l" name="201" href="#201">201</a><span class="c">--    See the License for the specific language governing permissions and</span>
<a class="l" name="202" href="#202">202</a><span class="c">--    limitations under the License.</span>
<a class="l" name="203" href="#203">203</a>
<a class="l" name="204" href="#204">204</a><b>local</b> <a href="/source/s?defs=pcall&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pcall</a> = <a href="/source/s?defs=pcall&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pcall</a>
<a class="l" name="205" href="#205">205</a><b>local</b> <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a> = <a href="/source/s?defs=ngx&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx</a>.<a href="/source/s?defs=log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">log</a>
<a class="l" name="206" href="#206">206</a><b>local</b> <a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a> = <a href="/source/s?defs=ngx&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx</a>.<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>
<a class="l" name="207" href="#207">207</a>
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a><b>local</b> <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a> = {}
<a class="hl" name="210" href="#210">210</a>
<a class="l" name="211" href="#211">211</a>
<a class="l" name="212" href="#212">212</a><b>do</b>
<a class="l" name="213" href="#213">213</a>  <b>local</b> <a href="/source/s?defs=multipart&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">multipart</a> = <a href="/source/s?defs=require&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">require</a> <span class="s">&quot;multipart&quot;</span>
<a class="l" name="214" href="#214">214</a>  <b>local</b> <a href="/source/s?defs=cjson&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cjson</a>     = <a href="/source/s?defs=require&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">require</a> <span class="s">&quot;cjson.safe&quot;</span>
<a class="l" name="215" href="#215">215</a>
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>  <b>local</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>              = <a href="/source/s?defs=string&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">string</a>.<a href="/source/s?defs=find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">find</a>
<a class="l" name="218" href="#218">218</a>  <b>local</b> <a href="/source/s?defs=str_format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_format</a>            = <a href="/source/s?defs=string&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">string</a>.<a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>
<a class="l" name="219" href="#219">219</a>  <b>local</b> <a href="/source/s?defs=ngx_req_get_post_args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_post_args</a> = <a href="/source/s?defs=ngx&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx</a>.<a href="/source/s?defs=req&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req</a>.<a href="/source/s?defs=get_post_args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">get_post_args</a>
<a class="hl" name="220" href="#220">220</a>  <b>local</b> <a href="/source/s?defs=ngx_req_get_body_data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_body_data</a> = <a href="/source/s?defs=ngx&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx</a>.<a href="/source/s?defs=req&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req</a>.<a href="/source/s?defs=get_body_data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">get_body_data</a>
<a class="l" name="221" href="#221">221</a>
<a class="l" name="222" href="#222">222</a>
<a class="l" name="223" href="#223">223</a>  <b>local</b> <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a> = {
<a class="l" name="224" href="#224">224</a>    <a href="/source/s?defs=form_url_encoded&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">form_url_encoded</a> = <span class="n">1</span>,
<a class="l" name="225" href="#225">225</a>    <a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>             = <span class="n">2</span>,
<a class="l" name="226" href="#226">226</a>    <a href="/source/s?defs=xml&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">xml</a>              = <span class="n">3</span>,
<a class="l" name="227" href="#227">227</a>    <a href="/source/s?defs=multipart&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">multipart</a>        = <span class="n">4</span>,
<a class="l" name="228" href="#228">228</a>    <a href="/source/s?defs=text&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">text</a>             = <span class="n">5</span>,
<a class="l" name="229" href="#229">229</a>    <a href="/source/s?defs=html&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">html</a>             = <span class="n">6</span>,
<a class="hl" name="230" href="#230">230</a>  }
<a class="l" name="231" href="#231">231</a>
<a class="l" name="232" href="#232">232</a>
<a class="l" name="233" href="#233">233</a>  <b>local</b> <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>     = {
<a class="l" name="234" href="#234">234</a>    <a href="/source/s?defs=no_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">no_ct</a>          = <span class="n">1</span> + <span class="n">0xFFFF</span> - <span class="n">0XFFFF</span>,
<a class="l" name="235" href="#235">235</a>    [<span class="n">1</span>]            = <span class="s">&quot;don&apos;t know how to parse request body (no Content-Type)&quot;</span>,
<a class="l" name="236" href="#236">236</a>    <a href="/source/s?defs=unknown_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unknown_ct</a>     = <span class="n">2</span>,
<a class="l" name="237" href="#237">237</a>    [<span class="n">2</span>]            = <span class="s">&quot;don&apos;t know how to parse request body (&quot;</span> ..
<a class="l" name="238" href="#238">238</a>                     <span class="s">&quot;unknown Content-Type &apos;%s&apos;)&quot;</span>,
<a class="l" name="239" href="#239">239</a>    <a href="/source/s?defs=unsupported_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unsupported_ct</a> = <span class="n">3</span>,
<a class="hl" name="240" href="#240">240</a>    [<span class="n">3</span>]            = <span class="s">&quot;don&apos;t know how to parse request body (&quot;</span> ..
<a class="l" name="241" href="#241">241</a>                     <span class="s">&quot;can&apos;t decode Content-Type &apos;%s&apos;)&quot;</span>,
<a class="l" name="242" href="#242">242</a>  }
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>
<a class="l" name="245" href="#245">245</a>  <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a>.<a href="/source/s?defs=req_mime_types&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime_types</a>  = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>
<a class="l" name="246" href="#246">246</a>  <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a>.<a href="/source/s?defs=req_body_errors&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_body_errors</a> = <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>
<a class="l" name="247" href="#247">247</a>
<a class="l" name="248" href="#248">248</a>
<a class="l" name="249" href="#249">249</a>  <b>local</b> <a href="/source/s?defs=MIME_DECODERS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_DECODERS</a> = {
<a class="hl" name="250" href="#250">250</a>    [<a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=multipart&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">multipart</a>] = <b>function</b>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>)
<a class="l" name="251" href="#251">251</a>      <b>local</b> <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a> = <a href="/source/s?defs=ngx_req_get_body_data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_body_data</a>()
<a class="l" name="252" href="#252">252</a>      <b>local</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>     = <a href="/source/s?defs=multipart&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">multipart</a>(<a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>, <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>):<a href="/source/s?defs=get_all&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">get_all</a>()
<a class="l" name="253" href="#253">253</a>
<a class="l" name="254" href="#254">254</a>      <b>return</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>
<a class="l" name="255" href="#255">255</a>    <b>end</b>,
<a class="l" name="256" href="#256">256</a>
<a class="l" name="257" href="#257">257</a>    [<a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>] = <b>function</b>()
<a class="l" name="258" href="#258">258</a>      <b>local</b> <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>  = <a href="/source/s?defs=ngx_req_get_body_data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_body_data</a>()
<a class="l" name="259" href="#259">259</a>      <b>local</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a> = <a href="/source/s?defs=cjson&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cjson</a>.<a href="/source/s?defs=decode&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">decode</a>(<a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>)
<a class="hl" name="260" href="#260">260</a>      <b>if</b> <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a> <b>then</b>
<a class="l" name="261" href="#261">261</a>        <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a>(<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>, <span class="s">&quot;could not decode JSON body args: &quot;</span>, <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a>)
<a class="l" name="262" href="#262">262</a>        <b>return</b> {}, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>
<a class="l" name="263" href="#263">263</a>      <b>end</b>
<a class="l" name="264" href="#264">264</a>
<a class="l" name="265" href="#265">265</a>      <b>return</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>
<a class="l" name="266" href="#266">266</a>    <b>end</b>,
<a class="l" name="267" href="#267">267</a>
<a class="l" name="268" href="#268">268</a>    [<a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=form_url_encoded&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">form_url_encoded</a>] = <b>function</b>()
<a class="l" name="269" href="#269">269</a>      <b>local</b> <a href="/source/s?defs=ok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ok</a>, <a href="/source/s?defs=res&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">res</a>, <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a> = <a href="/source/s?defs=pcall&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pcall</a>(<a href="/source/s?defs=ngx_req_get_post_args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_post_args</a>)
<a class="hl" name="270" href="#270">270</a>      <b>if</b> <b>not</b> <a href="/source/s?defs=ok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ok</a> <b>or</b> <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a> <b>then</b>
<a class="l" name="271" href="#271">271</a>        <b>local</b> <a href="/source/s?defs=msg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">msg</a> = <a href="/source/s?defs=res&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">res</a> <b>and</b> <a href="/source/s?defs=res&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">res</a> <b>or</b> <a href="/source/s?defs=err&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err</a>
<a class="l" name="272" href="#272">272</a>        <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a>(<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>, <span class="s">&quot;could not get body args: &quot;</span>, <a href="/source/s?defs=msg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">msg</a>)
<a class="l" name="273" href="#273">273</a>        <b>return</b> {}
<a class="l" name="274" href="#274">274</a>      <b>end</b>
<a class="l" name="275" href="#275">275</a>
<a class="l" name="276" href="#276">276</a>      <span class="c">--[=[ don&apos;t read raw_body if not necessary ]]</span>
<a class="l" name="277" href="#277">277</a><span class="c">      -- if we called get_body_args(), we only want the parsed body ]=]</span>
<a class="l" name="278" href="#278">278</a>      <b>return</b> <a href="/source/s?defs=res&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">res</a>
<a class="l" name="279" href="#279">279</a>    <b>end</b>,
<a class="hl" name="280" href="#280">280</a>  }
<a class="l" name="281" href="#281">281</a>
<a class="l" name="282" href="#282">282</a>
<a class="l" name="283" href="#283">283</a>  <b>local</b> <b>function</b> <a class="xf" name="get_body_info"/><a href="/source/s?refs=get_body_info&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">get_body_info</a>()
<a class="l" name="284" href="#284">284</a>    <b>local</b> <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a> = <a href="/source/s?defs=ngx&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx</a>.<a href="/source/s?defs=var&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">var</a>.<a href="/source/s?defs=http_content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">http_content_type</a>
<a class="l" name="285" href="#285">285</a>
<a class="l" name="286" href="#286">286</a>    <b>if</b> <b>not</b> <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a> <b>or</b> <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a> == <span class="s">&quot;&quot;</span> <b>then</b>
<a class="l" name="287" href="#287">287</a>      <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a>(<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>, <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>[<a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=no_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">no_ct</a>])
<a class="l" name="288" href="#288">288</a>
<a class="l" name="289" href="#289">289</a>      <b>return</b> {}, <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=no_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">no_ct</a>
<a class="hl" name="290" href="#290">290</a>    <b>end</b>
<a class="l" name="291" href="#291">291</a>
<a class="l" name="292" href="#292">292</a>    <b>local</b> <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>
<a class="l" name="293" href="#293">293</a>
<a class="l" name="294" href="#294">294</a>    <b>if</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=multipart/&amp;project=OpenGrok">multipart</a>/<a href="/source/s?path=multipart/form-data&amp;project=OpenGrok">form-data</a>&quot;</span>, <b>nil</b>, <b>true</b>) <b>then</b>
<a class="l" name="295" href="#295">295</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=multipart&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">multipart</a>
<a class="l" name="296" href="#296">296</a>
<a class="l" name="297" href="#297">297</a>    <b>elseif</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/json&amp;project=OpenGrok">json</a>&quot;</span>, <b>nil</b>, <b>true</b>) <b>then</b>
<a class="l" name="298" href="#298">298</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>
<a class="l" name="299" href="#299">299</a>
<a class="hl" name="300" href="#300">300</a>    <b>elseif</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/www-form-urlencoded&amp;project=OpenGrok">www-form-urlencoded</a>&quot;</span>, <b>nil</b>, <b>true</b>) <b>or</b>
<a class="l" name="301" href="#301">301</a>           <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/x-www-form-urlencoded&amp;project=OpenGrok">x-www-form-urlencoded</a>&quot;</span>, <b>nil</b>, <b>true</b>)
<a class="l" name="302" href="#302">302</a>    <b>then</b>
<a class="l" name="303" href="#303">303</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=form_url_encoded&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">form_url_encoded</a>
<a class="l" name="304" href="#304">304</a>
<a class="l" name="305" href="#305">305</a>    <b>elseif</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">[=[<a href="/source/s?path=text/&amp;project=OpenGrok">text</a>/<a href="/source/s?path=text/plain&amp;project=OpenGrok">plain</a>]=]</span>, <b>nil</b>, <b>true</b>) <b>then</b>
<a class="l" name="306" href="#306">306</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=text&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">text</a>
<a class="l" name="307" href="#307">307</a>
<a class="l" name="308" href="#308">308</a>    <b>elseif</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=text/&amp;project=OpenGrok">text</a>/<a href="/source/s?path=text/html&amp;project=OpenGrok">html</a>&quot;</span>, <b>nil</b>, <b>true</b>) <b>then</b>
<a class="l" name="309" href="#309">309</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=html&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">html</a>
<a class="hl" name="310" href="#310">310</a>
<a class="l" name="311" href="#311">311</a>    <b>elseif</b> <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/xml&amp;project=OpenGrok">xml</a>&quot;</span>, <b>nil</b>, <b>true</b>) <b>or</b>
<a class="l" name="312" href="#312">312</a>           <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=text/&amp;project=OpenGrok">text</a>/<a href="/source/s?path=text/xml&amp;project=OpenGrok">xml</a>&quot;</span>, <b>nil</b>, <b>true</b>)        <b>or</b>
<a class="l" name="313" href="#313">313</a>           <a href="/source/s?defs=str_find&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_find</a>(<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>, <span class="s">&quot;<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/soap&amp;project=OpenGrok">soap</a>+xml&quot;</span>, <b>nil</b>, <b>true</b>)
<a class="l" name="314" href="#314">314</a>    <b>then</b>
<a class="l" name="315" href="#315">315</a>      <span class="c">-- considering SOAP 1.1 (<a href="/source/s?path=text/&amp;project=OpenGrok">text</a>/<a href="/source/s?path=text/xml&amp;project=OpenGrok">xml</a>) and SOAP 1.2 (<a href="/source/s?path=application/&amp;project=OpenGrok">application</a>/<a href="/source/s?path=application/soap&amp;project=OpenGrok">soap</a>+xml)</span>
<a class="l" name="316" href="#316">316</a>      <span class="c">-- as XML only for now.</span>
<a class="l" name="317" href="#317">317</a>      <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> = <a href="/source/s?defs=MIME_TYPES&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_TYPES</a>.<a href="/source/s?defs=xml&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">xml</a>
<a class="l" name="318" href="#318">318</a>    <b>end</b>
<a class="l" name="319" href="#319">319</a>
<a class="hl" name="320" href="#320">320</a>    <b>if</b> <b>not</b> <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a> <b>then</b>
<a class="l" name="321" href="#321">321</a>      <span class="c">-- unknown Content-Type</span>
<a class="l" name="322" href="#322">322</a>      <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a>(<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>, <a href="/source/s?defs=str_format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_format</a>(<a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>[<a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=unsupported_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unsupported_ct</a>], <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>))
<a class="l" name="323" href="#323">323</a>
<a class="l" name="324" href="#324">324</a>      <b>return</b> {}, <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=unknown_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unknown_ct</a>
<a class="l" name="325" href="#325">325</a>    <b>end</b>
<a class="l" name="326" href="#326">326</a>
<a class="l" name="327" href="#327">327</a>    <b>if</b> <b>not</b> <a href="/source/s?defs=MIME_DECODERS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_DECODERS</a>[<a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>] <b>then</b>
<a class="l" name="328" href="#328">328</a>      <span class="c">-- known Content-Type, but cannot decode</span>
<a class="l" name="329" href="#329">329</a>      <a href="/source/s?defs=ngx_log&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_log</a>(<a href="/source/s?defs=ERR&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERR</a>, <a href="/source/s?defs=str_format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str_format</a>(<a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>[<a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=unsupported_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unsupported_ct</a>], <a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>))
<a class="hl" name="330" href="#330">330</a>
<a class="l" name="331" href="#331">331</a>      <b>return</b> {}, <a href="/source/s?defs=ERRORS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ERRORS</a>.<a href="/source/s?defs=unsupported_ct&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unsupported_ct</a>, <b>nil</b>, <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>
<a class="l" name="332" href="#332">332</a>    <b>end</b>
<a class="l" name="333" href="#333">333</a>
<a class="l" name="334" href="#334">334</a>    <span class="c">-- decoded Content-Type</span>
<a class="l" name="335" href="#335">335</a>    <b>local</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a> = <a href="/source/s?defs=MIME_DECODERS&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">MIME_DECODERS</a>[<a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>](<a href="/source/s?defs=content_type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">content_type</a>)
<a class="l" name="336" href="#336">336</a>
<a class="l" name="337" href="#337">337</a>    <b>return</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <b>nil</b>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>, <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>
<a class="l" name="338" href="#338">338</a>  <b>end</b>
<a class="l" name="339" href="#339">339</a>
<a class="hl" name="340" href="#340">340</a>
<a class="l" name="341" href="#341">341</a>  <b>function</b> <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a>.<a href="/source/s?defs=get_body_args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">get_body_args</a>()
<a class="l" name="342" href="#342">342</a>    <span class="c">-- only return args</span>
<a class="l" name="343" href="#343">343</a>    <b>return</b> (<a class="d intelliWindow-symbol" href="#get_body_info" data-definition-place="defined-in-file">get_body_info</a>())
<a class="l" name="344" href="#344">344</a>  <b>end</b>
<a class="l" name="345" href="#345">345</a>
<a class="l" name="346" href="#346">346</a>
<a class="l" name="347" href="#347">347</a>  <b>function</b> <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a>.<a class="d intelliWindow-symbol" href="#get_body_info" data-definition-place="defined-in-file">get_body_info</a>()
<a class="l" name="348" href="#348">348</a>    <b>local</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=err_code&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err_code</a>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>, <a href="/source/s?defs=req_mime0&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime0</a> = <a class="d intelliWindow-symbol" href="#get_body_info" data-definition-place="defined-in-file">get_body_info</a>()
<a class="l" name="349" href="#349">349</a>    <b>if</b> <b>not</b> <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a> <b>then</b>
<a class="hl" name="350" href="#350">350</a>      <span class="c">-- if our body was form-urlencoded and read via ngx.req.get_post_args()</span>
<a class="l" name="351" href="#351">351</a>      <span class="c">-- we need to retrieve the raw body because it was not retrieved by the</span>
<a class="l" name="352" href="#352">352</a>      <span class="c">-- decoder</span>
<a class="l" name="353" href="#353">353</a>      <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a> = <a href="/source/s?defs=ngx_req_get_body_data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ngx_req_get_body_data</a>()
<a class="l" name="354" href="#354">354</a>    <b>end</b>
<a class="l" name="355" href="#355">355</a>
<a class="l" name="356" href="#356">356</a>    <b>return</b> <a href="/source/s?defs=args&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">args</a>, <a href="/source/s?defs=err_code&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">err_code</a>, <a href="/source/s?defs=raw_body&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raw_body</a>, <a href="/source/s?defs=req_mime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">req_mime</a>
<a class="l" name="357" href="#357">357</a>  <b>end</b>
<a class="l" name="358" href="#358">358</a><b>end</b>
<a class="l" name="359" href="#359">359</a>
<a class="hl" name="360" href="#360">360</a>
<a class="l" name="361" href="#361">361</a><b>return</b> <a href="/source/s?defs=_M&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">_M</a>
<a class="l" name="362" href="#362">362</a><b>return</b> <span class="s">&apos;<a href="http://example.com?a=">http://example.com?a=</a>&apos;</span>
<a class="l" name="363" href="#363">363</a><b>return</b> <span class="s">[=[<a href="http://example.com?a=">http://example.com?a=</a>]=]</span>
<a class="l" name="364" href="#364">364</a><b>return</b> <span class="s">&quot;<a href="http://example.com?a=">http://example.com?a=</a>&quot;</span>
<a class="l" name="365" href="#365">365</a><b>return</b> <span class="s">&apos;<a href="http://example.com?a=">http://example.com?a=</a>\&apos;b\&apos;&apos;</span>
<a class="l" name="366" href="#366">366</a>