<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Namespace","xn",[["koans.23-meta",195]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">; Eclipse Public License, Version 1.0 (EPL-1.0) (plain text) THE ACCOMPANYING</span>
<a class="l" name="2" href="#2">2</a><span class="c">; PROGRAM IS PROVIDED UNDER THE TERMS OF THIS ECLIPSE PUBLIC LICENSE</span>
<a class="l" name="3" href="#3">3</a><span class="c">; (&quot;AGREEMENT&quot;). ANY USE, REPRODUCTION OR DISTRIBUTION OF THE PROGRAM</span>
<a class="l" name="4" href="#4">4</a><span class="c">; CONSTITUTES RECIPIENT&apos;S ACCEPTANCE OF THIS AGREEMENT.</span>
<a class="l" name="5" href="#5">5</a><span class="c">;</span>
<a class="l" name="6" href="#6">6</a><span class="c">; 1. DEFINITIONS</span>
<a class="l" name="7" href="#7">7</a><span class="c">;</span>
<a class="l" name="8" href="#8">8</a><span class="c">; &quot;Contribution&quot; means:</span>
<a class="l" name="9" href="#9">9</a><span class="c">;</span>
<a class="hl" name="10" href="#10">10</a><span class="c">; a) in the case of the initial Contributor, the initial code and</span>
<a class="l" name="11" href="#11">11</a><span class="c">; documentation distributed under this Agreement, and b) in the case of each</span>
<a class="l" name="12" href="#12">12</a><span class="c">; subsequent Contributor: i) changes to the Program, and ii) additions to the</span>
<a class="l" name="13" href="#13">13</a><span class="c">; Program; where such changes <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> additions to the Program originate from</span>
<a class="l" name="14" href="#14">14</a><span class="c">; and are distributed by that particular Contributor. A Contribution</span>
<a class="l" name="15" href="#15">15</a><span class="c">; &apos;originates&apos; from a Contributor if it was added to the Program by such</span>
<a class="l" name="16" href="#16">16</a><span class="c">; Contributor itself or anyone acting on such Contributor&apos;s behalf.</span>
<a class="l" name="17" href="#17">17</a><span class="c">; Contributions do not include additions to the Program which: (i) are</span>
<a class="l" name="18" href="#18">18</a><span class="c">; separate modules of software distributed in conjunction with the Program</span>
<a class="l" name="19" href="#19">19</a><span class="c">; under their own license agreement, and (ii) are not derivative works of the</span>
<a class="hl" name="20" href="#20">20</a><span class="c">; Program. &quot;Contributor&quot; means any person or entity that distributes the</span>
<a class="l" name="21" href="#21">21</a><span class="c">; Program.</span>
<a class="l" name="22" href="#22">22</a><span class="c">;</span>
<a class="l" name="23" href="#23">23</a><span class="c">; &quot;Licensed Patents &quot; mean patent claims licensable by a Contributor which are</span>
<a class="l" name="24" href="#24">24</a><span class="c">; necessarily infringed by the use or sale of its Contribution alone or when</span>
<a class="l" name="25" href="#25">25</a><span class="c">; combined with the Program.</span>
<a class="l" name="26" href="#26">26</a><span class="c">;</span>
<a class="l" name="27" href="#27">27</a><span class="c">; &quot;Program&quot; means the Contributions distributed in accordance with this</span>
<a class="l" name="28" href="#28">28</a><span class="c">; Agreement.</span>
<a class="l" name="29" href="#29">29</a><span class="c">;</span>
<a class="hl" name="30" href="#30">30</a><span class="c">; &quot;Recipient&quot; means anyone who receives the Program under this Agreement,</span>
<a class="l" name="31" href="#31">31</a><span class="c">; including all Contributors.</span>
<a class="l" name="32" href="#32">32</a><span class="c">;</span>
<a class="l" name="33" href="#33">33</a><span class="c">; 2. GRANT OF RIGHTS</span>
<a class="l" name="34" href="#34">34</a><span class="c">;</span>
<a class="l" name="35" href="#35">35</a><span class="c">; a) Subject to the terms of this Agreement, each Contributor hereby grants</span>
<a class="l" name="36" href="#36">36</a><span class="c">; Recipient a non-exclusive, worldwide, royalty-free copyright license to</span>
<a class="l" name="37" href="#37">37</a><span class="c">; reproduce, prepare derivative works of, publicly display, publicly perform,</span>
<a class="l" name="38" href="#38">38</a><span class="c">; distribute and sublicense the Contribution of such Contributor, if any, and</span>
<a class="l" name="39" href="#39">39</a><span class="c">; such derivative works, in source code and object code form. b) Subject to</span>
<a class="hl" name="40" href="#40">40</a><span class="c">; the terms of this Agreement, each Contributor hereby grants Recipient a</span>
<a class="l" name="41" href="#41">41</a><span class="c">; non-exclusive, worldwide, royalty-free patent license under Licensed Patents</span>
<a class="l" name="42" href="#42">42</a><span class="c">; to make, use, sell, offer to sell, import and otherwise transfer the</span>
<a class="l" name="43" href="#43">43</a><span class="c">; Contribution of such Contributor, if any, in source code and object code</span>
<a class="l" name="44" href="#44">44</a><span class="c">; form. This patent license shall apply to the combination of the Contribution</span>
<a class="l" name="45" href="#45">45</a><span class="c">; and the Program if, at the time the Contribution is added by the</span>
<a class="l" name="46" href="#46">46</a><span class="c">; Contributor, such addition of the Contribution causes such combination to be</span>
<a class="l" name="47" href="#47">47</a><span class="c">; covered by the Licensed Patents. The patent license shall not apply to any</span>
<a class="l" name="48" href="#48">48</a><span class="c">; other combinations which include the Contribution. No hardware per se is</span>
<a class="l" name="49" href="#49">49</a><span class="c">; licensed hereunder. c) Recipient understands that although each Contributor</span>
<a class="hl" name="50" href="#50">50</a><span class="c">; grants the licenses to its Contributions set forth herein, no assurances are</span>
<a class="l" name="51" href="#51">51</a><span class="c">; provided by any Contributor that the Program does not infringe the patent or</span>
<a class="l" name="52" href="#52">52</a><span class="c">; other intellectual property rights of any other entity. Each Contributor</span>
<a class="l" name="53" href="#53">53</a><span class="c">; disclaims any liability to Recipient for claims brought by any other entity</span>
<a class="l" name="54" href="#54">54</a><span class="c">; based on infringement of intellectual property rights or otherwise. As a</span>
<a class="l" name="55" href="#55">55</a><span class="c">; condition to exercising the rights and licenses granted hereunder, each</span>
<a class="l" name="56" href="#56">56</a><span class="c">; Recipient hereby assumes sole responsibility to secure any other</span>
<a class="l" name="57" href="#57">57</a><span class="c">; intellectual property rights needed, if any. For example, if a third party</span>
<a class="l" name="58" href="#58">58</a><span class="c">; patent license is required to allow Recipient to distribute the Program, it</span>
<a class="l" name="59" href="#59">59</a><span class="c">; is Recipient&apos;s responsibility to acquire that license before distributing</span>
<a class="hl" name="60" href="#60">60</a><span class="c">; the Program. d) Each Contributor represents that to its knowledge it has</span>
<a class="l" name="61" href="#61">61</a><span class="c">; sufficient copyright rights in its Contribution, if any, to grant the</span>
<a class="l" name="62" href="#62">62</a><span class="c">; copyright license set forth in this Agreement.</span>
<a class="l" name="63" href="#63">63</a><span class="c">;</span>
<a class="l" name="64" href="#64">64</a><span class="c">; 3. REQUIREMENTS</span>
<a class="l" name="65" href="#65">65</a><span class="c">;</span>
<a class="l" name="66" href="#66">66</a><span class="c">; A Contributor may choose to distribute the Program in object code form under</span>
<a class="l" name="67" href="#67">67</a><span class="c">; its own license agreement, provided that:</span>
<a class="l" name="68" href="#68">68</a><span class="c">;</span>
<a class="l" name="69" href="#69">69</a><span class="c">; a) it complies with the terms and conditions of this Agreement; and b) its</span>
<a class="hl" name="70" href="#70">70</a><span class="c">; license agreement: i) effectively disclaims on behalf of all Contributors</span>
<a class="l" name="71" href="#71">71</a><span class="c">; all warranties and conditions, express and implied, including warranties or</span>
<a class="l" name="72" href="#72">72</a><span class="c">; conditions of title and non-infringement, and implied warranties or</span>
<a class="l" name="73" href="#73">73</a><span class="c">; conditions of merchantability and fitness for a particular purpose; ii)</span>
<a class="l" name="74" href="#74">74</a><span class="c">; effectively excludes on behalf of all Contributors all liability for</span>
<a class="l" name="75" href="#75">75</a><span class="c">; damages, including direct, indirect, special, incidental and consequential</span>
<a class="l" name="76" href="#76">76</a><span class="c">; damages, such as lost profits; iii) states that any provisions which differ</span>
<a class="l" name="77" href="#77">77</a><span class="c">; from this Agreement are offered by that Contributor alone and not by any</span>
<a class="l" name="78" href="#78">78</a><span class="c">; other party; and iv) states that source code for the Program is available</span>
<a class="l" name="79" href="#79">79</a><span class="c">; from such Contributor, and informs licensees how to obtain it in a</span>
<a class="hl" name="80" href="#80">80</a><span class="c">; reasonable manner on or through a medium customarily used for software</span>
<a class="l" name="81" href="#81">81</a><span class="c">; exchange. When the Program is made available in source code form:</span>
<a class="l" name="82" href="#82">82</a><span class="c">;</span>
<a class="l" name="83" href="#83">83</a><span class="c">; a) it must be made available under this Agreement; and b) a copy of this</span>
<a class="l" name="84" href="#84">84</a><span class="c">; Agreement must be included with each copy of the Program. Contributors may</span>
<a class="l" name="85" href="#85">85</a><span class="c">; not remove or alter any copyright notices contained within the Program. Each</span>
<a class="l" name="86" href="#86">86</a><span class="c">; Contributor must identify itself as the originator of its Contribution, if</span>
<a class="l" name="87" href="#87">87</a><span class="c">; any, in a manner that reasonably allows subsequent Recipients to identify</span>
<a class="l" name="88" href="#88">88</a><span class="c">; the originator of the Contribution.</span>
<a class="l" name="89" href="#89">89</a><span class="c">;</span>
<a class="hl" name="90" href="#90">90</a><span class="c">; 4. COMMERCIAL DISTRIBUTION</span>
<a class="l" name="91" href="#91">91</a><span class="c">;</span>
<a class="l" name="92" href="#92">92</a><span class="c">; Commercial distributors of software may accept certain responsibilities with</span>
<a class="l" name="93" href="#93">93</a><span class="c">; respect to end users, business partners and the like. While this license is</span>
<a class="l" name="94" href="#94">94</a><span class="c">; intended to facilitate the commercial use of the Program, the Contributor</span>
<a class="l" name="95" href="#95">95</a><span class="c">; who includes the Program in a commercial product offering should do so in a</span>
<a class="l" name="96" href="#96">96</a><span class="c">; manner which does not create potential liability for other Contributors.</span>
<a class="l" name="97" href="#97">97</a><span class="c">; Therefore, if a Contributor includes the Program in a commercial product</span>
<a class="l" name="98" href="#98">98</a><span class="c">; offering, such Contributor (&quot;Commercial Contributor&quot;) hereby agrees to</span>
<a class="l" name="99" href="#99">99</a><span class="c">; defend and indemnify every other Contributor (&quot;Indemnified Contributor&quot;)</span>
<a class="hl" name="100" href="#100">100</a><span class="c">; against any losses, damages and costs (collectively &quot;Losses&quot;) arising from</span>
<a class="l" name="101" href="#101">101</a><span class="c">; claims, lawsuits and other legal actions brought by a third party against</span>
<a class="l" name="102" href="#102">102</a><span class="c">; the Indemnified Contributor to the extent caused by the acts or omissions of</span>
<a class="l" name="103" href="#103">103</a><span class="c">; such Commercial Contributor in connection with its distribution of the</span>
<a class="l" name="104" href="#104">104</a><span class="c">; Program in a commercial product offering. The obligations in this section do</span>
<a class="l" name="105" href="#105">105</a><span class="c">; not apply to any claims or Losses relating to any actual or alleged</span>
<a class="l" name="106" href="#106">106</a><span class="c">; intellectual property infringement. In order to qualify, an Indemnified</span>
<a class="l" name="107" href="#107">107</a><span class="c">; Contributor must: a) promptly notify the Commercial Contributor in writing</span>
<a class="l" name="108" href="#108">108</a><span class="c">; of such claim, and b) allow the Commercial Contributor to control, and</span>
<a class="l" name="109" href="#109">109</a><span class="c">; cooperate with the Commercial Contributor in, the defense and any related</span>
<a class="hl" name="110" href="#110">110</a><span class="c">; settlement negotiations. The Indemnified Contributor may participate in any</span>
<a class="l" name="111" href="#111">111</a><span class="c">; such claim at its own expense.</span>
<a class="l" name="112" href="#112">112</a><span class="c">;</span>
<a class="l" name="113" href="#113">113</a><span class="c">; For example, a Contributor might include the Program in a commercial product</span>
<a class="l" name="114" href="#114">114</a><span class="c">; offering, Product X. That Contributor is then a Commercial Contributor. If</span>
<a class="l" name="115" href="#115">115</a><span class="c">; that Commercial Contributor then makes performance claims, or offers</span>
<a class="l" name="116" href="#116">116</a><span class="c">; warranties related to Product X, those performance claims and warranties are</span>
<a class="l" name="117" href="#117">117</a><span class="c">; such Commercial Contributor&apos;s responsibility alone. Under this section, the</span>
<a class="l" name="118" href="#118">118</a><span class="c">; Commercial Contributor would have to defend claims against the other</span>
<a class="l" name="119" href="#119">119</a><span class="c">; Contributors related to those performance claims and warranties, and if a</span>
<a class="hl" name="120" href="#120">120</a><span class="c">; court requires any other Contributor to pay any damages as a result, the</span>
<a class="l" name="121" href="#121">121</a><span class="c">; Commercial Contributor must pay those damages.</span>
<a class="l" name="122" href="#122">122</a><span class="c">;</span>
<a class="l" name="123" href="#123">123</a><span class="c">; 5. NO WARRANTY</span>
<a class="l" name="124" href="#124">124</a><span class="c">;</span>
<a class="l" name="125" href="#125">125</a><span class="c">; EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, THE PROGRAM IS PROVIDED ON</span>
<a class="l" name="126" href="#126">126</a><span class="c">; AN &quot;AS IS&quot; BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, EITHER</span>
<a class="l" name="127" href="#127">127</a><span class="c">; EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR</span>
<a class="l" name="128" href="#128">128</a><span class="c">; CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A</span>
<a class="l" name="129" href="#129">129</a><span class="c">; PARTICULAR PURPOSE. Each Recipient is solely responsible for determining the</span>
<a class="hl" name="130" href="#130">130</a><span class="c">; appropriateness of using and distributing the Program and assumes all risks</span>
<a class="l" name="131" href="#131">131</a><span class="c">; associated with its exercise of rights under this Agreement , including but</span>
<a class="l" name="132" href="#132">132</a><span class="c">; not limited to the risks and costs of program errors, compliance with</span>
<a class="l" name="133" href="#133">133</a><span class="c">; applicable laws, damage to or loss of data, programs or equipment, and</span>
<a class="l" name="134" href="#134">134</a><span class="c">; unavailability or interruption of operations.</span>
<a class="l" name="135" href="#135">135</a><span class="c">;</span>
<a class="l" name="136" href="#136">136</a><span class="c">; 6. DISCLAIMER OF LIABILITY</span>
<a class="l" name="137" href="#137">137</a><span class="c">;</span>
<a class="l" name="138" href="#138">138</a><span class="c">; EXCEPT AS EXPRESSLY SET FORTH IN THIS AGREEMENT, NEITHER RECIPIENT NOR ANY</span>
<a class="l" name="139" href="#139">139</a><span class="c">; CONTRIBUTORS SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL,</span>
<a class="hl" name="140" href="#140">140</a><span class="c">; SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING WITHOUT LIMITATION</span>
<a class="l" name="141" href="#141">141</a><span class="c">; LOST PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN</span>
<a class="l" name="142" href="#142">142</a><span class="c">; CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)</span>
<a class="l" name="143" href="#143">143</a><span class="c">; ARISING IN ANY WAY OUT OF THE USE OR DISTRIBUTION OF THE PROGRAM OR THE</span>
<a class="l" name="144" href="#144">144</a><span class="c">; EXERCISE OF ANY RIGHTS GRANTED HEREUNDER, EVEN IF ADVISED OF THE POSSIBILITY</span>
<a class="l" name="145" href="#145">145</a><span class="c">; OF SUCH DAMAGES.</span>
<a class="l" name="146" href="#146">146</a><span class="c">;</span>
<a class="l" name="147" href="#147">147</a><span class="c">; 7. GENERAL</span>
<a class="l" name="148" href="#148">148</a><span class="c">;</span>
<a class="l" name="149" href="#149">149</a><span class="c">; If any provision of this Agreement is invalid or unenforceable under</span>
<a class="hl" name="150" href="#150">150</a><span class="c">; applicable law, it shall not affect the validity or enforceability of the</span>
<a class="l" name="151" href="#151">151</a><span class="c">; remainder of the terms of this Agreement, and without further action by the</span>
<a class="l" name="152" href="#152">152</a><span class="c">; parties hereto, such provision shall be reformed to the minimum extent</span>
<a class="l" name="153" href="#153">153</a><span class="c">; necessary to make such provision valid and enforceable.</span>
<a class="l" name="154" href="#154">154</a><span class="c">;</span>
<a class="l" name="155" href="#155">155</a><span class="c">; If Recipient institutes patent litigation against any entity (including a</span>
<a class="l" name="156" href="#156">156</a><span class="c">; cross-claim or counterclaim in a lawsuit) alleging that the Program itself</span>
<a class="l" name="157" href="#157">157</a><span class="c">; (excluding combinations of the Program with other software or hardware)</span>
<a class="l" name="158" href="#158">158</a><span class="c">; infringes such Recipient&apos;s patent(s), then such Recipient&apos;s rights granted</span>
<a class="l" name="159" href="#159">159</a><span class="c">; under Section 2(b) shall terminate as of the date such litigation is filed.</span>
<a class="hl" name="160" href="#160">160</a><span class="c">;</span>
<a class="l" name="161" href="#161">161</a><span class="c">; All Recipient&apos;s rights under this Agreement shall terminate if it fails to</span>
<a class="l" name="162" href="#162">162</a><span class="c">; comply with any of the material terms or conditions of this Agreement and</span>
<a class="l" name="163" href="#163">163</a><span class="c">; does not cure such failure in a reasonable period of time after becoming</span>
<a class="l" name="164" href="#164">164</a><span class="c">; aware of such noncompliance. If all Recipient&apos;s rights under this Agreement</span>
<a class="l" name="165" href="#165">165</a><span class="c">; terminate, Recipient agrees to cease use and distribution of the Program as</span>
<a class="l" name="166" href="#166">166</a><span class="c">; soon as reasonably practicable. However, Recipient&apos;s obligations under this</span>
<a class="l" name="167" href="#167">167</a><span class="c">; Agreement and any licenses granted by Recipient relating to the Program</span>
<a class="l" name="168" href="#168">168</a><span class="c">; shall continue and survive.</span>
<a class="l" name="169" href="#169">169</a><span class="c">;</span>
<a class="hl" name="170" href="#170">170</a><span class="c">; Everyone is permitted to copy and distribute copies of this Agreement, but</span>
<a class="l" name="171" href="#171">171</a><span class="c">; in order to avoid inconsistency the Agreement is copyrighted and may only be</span>
<a class="l" name="172" href="#172">172</a><span class="c">; modified in the following manner. The Agreement Steward reserves the right</span>
<a class="l" name="173" href="#173">173</a><span class="c">; to publish new versions (including revisions) of this Agreement from time to</span>
<a class="l" name="174" href="#174">174</a><span class="c">; time. No one other than the Agreement Steward has the right to modify this</span>
<a class="l" name="175" href="#175">175</a><span class="c">; Agreement. The Eclipse Foundation is the initial Agreement Steward. The</span>
<a class="l" name="176" href="#176">176</a><span class="c">; Eclipse Foundation may assign the responsibility to serve as the Agreement</span>
<a class="l" name="177" href="#177">177</a><span class="c">; Steward to a suitable separate entity. Each new version of the Agreement</span>
<a class="l" name="178" href="#178">178</a><span class="c">; will be given a distinguishing version number. The Program (including</span>
<a class="l" name="179" href="#179">179</a><span class="c">; Contributions) may always be distributed subject to the version of the</span>
<a class="hl" name="180" href="#180">180</a><span class="c">; Agreement under which it was received. In addition, after a new version of</span>
<a class="l" name="181" href="#181">181</a><span class="c">; the Agreement is published, Contributor may elect to distribute the Program</span>
<a class="l" name="182" href="#182">182</a><span class="c">; (including its Contributions) under the new version. Except as expressly</span>
<a class="l" name="183" href="#183">183</a><span class="c">; stated in Sections 2(a) and 2(b) above, Recipient receives no rights or</span>
<a class="l" name="184" href="#184">184</a><span class="c">; licenses to the intellectual property of any Contributor under this</span>
<a class="l" name="185" href="#185">185</a><span class="c">; Agreement, whether expressly, by implication, estoppel or otherwise. All</span>
<a class="l" name="186" href="#186">186</a><span class="c">; rights in the Program not expressly granted under this Agreement are</span>
<a class="l" name="187" href="#187">187</a><span class="c">; reserved.</span>
<a class="l" name="188" href="#188">188</a><span class="c">;</span>
<a class="l" name="189" href="#189">189</a><span class="c">; This Agreement is governed by the laws of the State of New York and the</span>
<a class="hl" name="190" href="#190">190</a><span class="c">; intellectual property laws of the United States of America. No party to this</span>
<a class="l" name="191" href="#191">191</a><span class="c">; Agreement will bring a legal action under this Agreement more than one year</span>
<a class="l" name="192" href="#192">192</a><span class="c">; after the cause of action arose. Each party waives its rights to a jury</span>
<a class="l" name="193" href="#193">193</a><span class="c">; trial in any resulting litigation.</span>
<a class="l" name="194" href="#194">194</a>
<a class="l" name="195" href="#195">195</a>(<b>ns</b> <a class="xn" name="koans.23-meta"/><a href="/source/s?refs=koans.23%5C-meta&amp;project=OpenGrok" class="xn intelliWindow-symbol" data-definition-place="def">koans.23-meta</a>
<a class="l" name="196" href="#196">196</a>  (<a href="/source/s?defs=%5C%3Arequire&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:require</a> [<a href="/source/s?defs=koan%5C-engine.core&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">koan-engine.core</a> <a href="/source/s?defs=%5C%3Arefer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:refer</a> <a href="/source/s?defs=%5C%3Aall&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:all</a>]))
<a class="l" name="197" href="#197">197</a>
<a class="l" name="198" href="#198">198</a>(<b>def</b> <a class="d" name="giants"/><a href="/source/s?refs=giants&amp;project=OpenGrok" class="d intelliWindow-symbol" data-definition-place="def">giants</a>
<a class="l" name="199" href="#199">199</a>  (<b>with-meta</b> &apos;<a href="/source/s?defs=Giants&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Giants</a>
<a class="hl" name="200" href="#200">200</a>    {<a href="/source/s?defs=%5C%3Aleague&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:league</a> <span class="s">&quot;National League&quot;</span>}))
<a class="l" name="201" href="#201">201</a>
<a class="l" name="202" href="#202">202</a>(<a href="/source/s?defs=meditations&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">meditations</a>
<a class="l" name="203" href="#203">203</a>  <span class="s">&quot;Some objects can be tagged using the with-meta function&quot;</span>
<a class="l" name="204" href="#204">204</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a>))
<a class="l" name="205" href="#205">205</a>
<a class="l" name="206" href="#206">206</a>  <span class="s">&quot;Or more succinctly with a reader macro&quot;</span>
<a class="l" name="207" href="#207">207</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>meta</b> &apos;^{<a href="/source/s?defs=%5C%3Adivision&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:division</a> <span class="s">&quot;West&quot;</span>} <a href="/source/s?defs=Giants&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Giants</a>))
<a class="l" name="208" href="#208">208</a>
<a class="l" name="209" href="#209">209</a>  <span class="s">&quot;While others can&apos;t&quot;</span>
<a class="hl" name="210" href="#210">210</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>try</b>
<a class="l" name="211" href="#211">211</a>          (<b>with-meta</b>
<a class="l" name="212" href="#212">212</a>            <span class="n">2</span>
<a class="l" name="213" href="#213">213</a>            {<a href="/source/s?defs=%5C%3Aprime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:prime</a> <b>true</b>})
<a class="l" name="214" href="#214">214</a>          (<a href="/source/s?defs=catch&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">catch</a> <a href="/source/s?defs=ClassCastException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ClassCastException</a> <a href="/source/s?defs=e&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">e</a>
<a class="l" name="215" href="#215">215</a>            <span class="s">&quot;This doesn&apos;t implement the IObj interface&quot;</span>)))
<a class="l" name="216" href="#216">216</a>
<a class="l" name="217" href="#217">217</a>  <span class="s">&quot;Notice when metadata carries over&quot;</span>
<a class="l" name="218" href="#218">218</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>meta</b> (<b>merge</b> &apos;^{<a href="/source/s?defs=%5C%3Afoo&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:foo</a> <a href="/source/s?defs=%5C%3Abar&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:bar</a>} {<a href="/source/s?defs=%5C%3Aa&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:a</a> <span class="n">1</span> <a href="/source/s?defs=%5C%3Ab&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:b</a> <span class="n">2</span>}
<a class="l" name="219" href="#219">219</a>                     {<a href="/source/s?defs=%5C%3Ab&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:b</a> <span class="n">3</span> <a href="/source/s?defs=%5C%3Ac&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:c</a> <span class="n">4</span>})))
<a class="hl" name="220" href="#220">220</a>
<a class="l" name="221" href="#221">221</a>  <span class="s">&quot;And when it doesn&apos;t&quot;</span>
<a class="l" name="222" href="#222">222</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>meta</b> (<b>merge</b> {<a href="/source/s?defs=%5C%3Aa&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:a</a> <span class="n">1</span> <a href="/source/s?defs=%5C%3Ab&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:b</a> <span class="n">2</span>}
<a class="l" name="223" href="#223">223</a>                     &apos;^{<a href="/source/s?defs=%5C%3Afoo&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:foo</a> <a href="/source/s?defs=%5C%3Abar&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:bar</a>} {<a href="/source/s?defs=%5C%3Ab&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:b</a> <span class="n">3</span> <a href="/source/s?defs=%5C%3Ac&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:c</a> <span class="n">36rCRAZY</span>})))
<a class="l" name="224" href="#224">224</a>
<a class="l" name="225" href="#225">225</a>  <span class="s">&quot;Metadata can be used as a type hint to avoid reflection during runtime&quot;</span>
<a class="l" name="226" href="#226">226</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (#(.<a href="/source/s?defs=charAt&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">charAt</a> ^<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> % <span class="n">0</span>) <span class="s">&quot;Cast me&quot;</span>))
<a class="l" name="227" href="#227">227</a>
<a class="l" name="228" href="#228">228</a>  <span class="s">&quot;You can directly update an object&apos;s metadata&quot;</span>
<a class="l" name="229" href="#229">229</a>  (= <span class="n">0xFF</span> (<b>let</b> [<a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a>
<a class="hl" name="230" href="#230">230</a>             (<b>with-meta</b>
<a class="l" name="231" href="#231">231</a>               &apos;<a href="/source/s?defs=Giants&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Giants</a>
<a class="l" name="232" href="#232">232</a>               {<a href="/source/s?defs=%5C%3Aworld%5C-series%5C-titles&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:world-series-titles</a> (<b>atom</b> <span class="n">7</span>)})]
<a class="l" name="233" href="#233">233</a>         (<b>swap!</b> (<a href="/source/s?defs=%5C%3Aworld%5C-series%5C-titles&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:world-series-titles</a> (<b>meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a>)) <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a>)
<a class="l" name="234" href="#234">234</a>         @(<a href="/source/s?defs=%5C%3Aworld%5C-series%5C-titles&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:world-series-titles</a> (<b>meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a>))))
<a class="l" name="235" href="#235">235</a>
<a class="l" name="236" href="#236">236</a>  <span class="s">&quot;You can also create a new object from another object with metadata&quot;</span>
<a class="l" name="237" href="#237">237</a>  (= {<a href="/source/s?defs=%5C%3Aleague&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:league</a> <span class="s">&quot;National League&quot;</span> <a href="/source/s?defs=%5C%3Apark&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:park</a> <span class="s">&quot;AT&amp;T Park&quot;</span>}
<a class="l" name="238" href="#238">238</a>     (<b>meta</b> (<b>vary-meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a>
<a class="l" name="239" href="#239">239</a>                      <b>assoc</b> <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a>)))
<a class="hl" name="240" href="#240">240</a>
<a class="l" name="241" href="#241">241</a>  <span class="s">&quot;But it won&apos;t affect behavior like equality&quot;</span>
<a class="l" name="242" href="#242">242</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>vary-meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a> <b>dissoc</b> <a href="/source/s?defs=%5C%3Aleague&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:league</a>))
<a class="l" name="243" href="#243">243</a>
<a class="l" name="244" href="#244">244</a>  <span class="s">&quot;Or the object&apos;s printed representation&quot;</span>
<a class="l" name="245" href="#245">245</a>  (= <a href="/source/s?defs=__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__</a> (<b>pr-str</b> (<b>vary-meta</b> <a class="d intelliWindow-symbol" href="#giants" data-definition-place="defined-in-file">giants</a> <b>dissoc</b> <a href="/source/s?defs=%5C%3Aleague&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">:league</a>))))
<a class="l" name="246" href="#246">246</a>