<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/usr/&amp;project=OpenGrok">usr</a>/<a href="/source/s?path=/usr/bin/&amp;project=OpenGrok">bin</a>/<a href="/source/s?path=/usr/bin/perl&amp;project=OpenGrok">perl</a></span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">#</span>
<a class="l" name="4" href="#4">4</a><span class="c"># CDDL HEADER START</span>
<a class="l" name="5" href="#5">5</a><span class="c">#</span>
<a class="l" name="6" href="#6">6</a><span class="c"># The contents of this file are subject to the terms of the</span>
<a class="l" name="7" href="#7">7</a><span class="c"># Common Development and Distribution License (the &quot;License&quot;).</span>
<a class="l" name="8" href="#8">8</a><span class="c"># You may not use this file except in compliance with the License.</span>
<a class="l" name="9" href="#9">9</a><span class="c">#</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific</span>
<a class="l" name="11" href="#11">11</a><span class="c"># language governing permissions and limitations under the License.</span>
<a class="l" name="12" href="#12">12</a><span class="c">#</span>
<a class="l" name="13" href="#13">13</a><span class="c"># When distributing Covered Code, include this CDDL HEADER in each</span>
<a class="l" name="14" href="#14">14</a><span class="c"># file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.</span>
<a class="l" name="15" href="#15">15</a><span class="c"># If applicable, add the following below this CDDL HEADER, with the</span>
<a class="l" name="16" href="#16">16</a><span class="c"># fields enclosed by brackets &quot;[]&quot; replaced with your own identifying</span>
<a class="l" name="17" href="#17">17</a><span class="c"># information: Portions Copyright [yyyy] [name of copyright owner]</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a><span class="c"># CDDL HEADER END</span>
<a class="hl" name="20" href="#20">20</a><span class="c">#</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">#</span>
<a class="l" name="23" href="#23">23</a><span class="c"># Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.</span>
<a class="l" name="24" href="#24">24</a><span class="c">#</span>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>print</b> <span class="s">&quot;Testing 1-2-3 oops this file is truncated in a string</span>