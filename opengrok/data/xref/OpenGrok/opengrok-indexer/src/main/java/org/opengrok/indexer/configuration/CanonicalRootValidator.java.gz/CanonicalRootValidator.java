<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["CanonicalRootValidator",31]]],["Package","xp",[["org.opengrok.indexer.configuration",24]]],["Method","xmt",[["CanonicalRootValidator",63],["validate",38]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2019, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=configuration&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">configuration</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=File&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">File</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> * Represents a validator of a --canonicalRoot value.
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="CanonicalRootValidator"/><a href="/source/s?refs=CanonicalRootValidator&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">CanonicalRootValidator</a> &#123;
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>     * Validates the specified setting, returning an error message if validation
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>     * fails.
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> a defined instance if not valid or {<strong>@code</strong> null} otherwise
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_1d73557c' class='scope-head'><span class='scope-signature'>validate(String setting, String elementDescription)</span><a class="l" name="38" href="#38">38</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_1d73557c_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>static</b> <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xmt" name="validate"/><a href="/source/s?refs=validate&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">validate</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="setting"/><a href="/source/s?refs=setting&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">setting</a>, <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="elementDescription"/><a href="/source/s?refs=elementDescription&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">elementDescription</a>) &#123;</span>
<span id='scope_id_1d73557c_fold' class='scope-body'><a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>        <span class="c">// Test that the value ends with the system separator.</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>        <b>if</b> (!<a class="d intelliWindow-symbol" href="#setting" data-definition-place="defined-in-file">setting</a>.<a href="/source/s?defs=endsWith&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">endsWith</a>(<a href="/source/s?defs=File&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">File</a>.<a href="/source/s?defs=separator&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">separator</a>)) &#123;
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>            <b>return</b> <a class="d intelliWindow-symbol" href="#elementDescription" data-definition-place="defined-in-file">elementDescription</a> + <span class="s">&quot; must end with a separator&quot;</span>&#59;
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>        &#125;
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>        <span class="c">// Test that the value is not like a Windows root (e.g. C:\ or Z:/).</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>        <b>if</b> (<a class="d intelliWindow-symbol" href="#setting" data-definition-place="defined-in-file">setting</a>.<a href="/source/s?defs=matches&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">matches</a>(<span class="s">&quot;\\w:(?:[/\\\\]*)&quot;</span>)) &#123;
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>            <b>return</b> <a class="d intelliWindow-symbol" href="#elementDescription" data-definition-place="defined-in-file">elementDescription</a> + <span class="s">&quot; cannot be a root directory&quot;</span>&#59;
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>        &#125;
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>        <span class="c">// Test that some character other than separators is in the value.</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>        <b>if</b> (!<a class="d intelliWindow-symbol" href="#setting" data-definition-place="defined-in-file">setting</a>.<a href="/source/s?defs=matches&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">matches</a>(<span class="s">&quot;.*[^/\\\\].*&quot;</span>)) &#123;
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>            <b>return</b> <a class="d intelliWindow-symbol" href="#elementDescription" data-definition-place="defined-in-file">elementDescription</a> + <span class="s">&quot; cannot be the root directory&quot;</span>&#59;
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>        &#125;
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>        <span class="c">/*
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>         * There is no need to validate that the caller has not specified e.g.
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>         * &quot;/./&quot; (i.e. an alias to the root &quot;/&quot;) because --canonicalRoot values
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>         * are matched via string comparison against true canonical values got
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>         * via File.getCanonicalPath(). An alias like &quot;/./&quot; is therefore a
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>         * never-matching value and hence inactive.
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>         */</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>        <b>return</b> <a href="/source/s?defs=null&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">null</a>&#59;
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>    <span class="c">/** Private to enforce static. */</span>
<span id='scope_id_60dfb9da' class='scope-head'><span class='scope-signature'>CanonicalRootValidator()</span><a class="l" name="63" href="#63">63</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_60dfb9da_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>private</b> <a class="xmt" name="CanonicalRootValidator"/><a href="/source/s?refs=CanonicalRootValidator&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">CanonicalRootValidator</a>() &#123;</span>
<span id='scope_id_60dfb9da_fold' class='scope-body'><a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>