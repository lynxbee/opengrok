<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",24]]],["Interface","xi",[["JFlexLexer",33]]],["Method","xmt",[["yybegin",81],["yycharat",55],["yyclose",62],["yylength",46],["yylex",104],["yypushback",93],["yyreset",69],["yystate",75],["yytext",39]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=Reader&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Reader</a>&#59;
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> * Represents an API for lexers created by JFlex for {<strong>@code</strong> %type int}.
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * &lt;p&gt;<a href="http://jflex.de">http://jflex.de</a>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="JFlexLexer"/><a href="/source/s?refs=JFlexLexer&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">JFlexLexer</a> &#123;
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * Gets the matched input text as documented by JFlex.
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> &quot;the matched input text region&quot;
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_93d82a74' class='scope-head'><span class='scope-signature'>yytext()</span><a class="l" name="39" href="#39">39</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_93d82a74_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xmt" name="yytext"/><a href="/source/s?refs=yytext&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yytext</a>()&#59;
</span><a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>     * Gets the matched input text length as documented by JFlex.
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> &quot;the length of the matched input text region (does not require a
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * String object to be created)&quot;
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_f6cd5989' class='scope-head'><span class='scope-signature'>yylength()</span><a class="l" name="46" href="#46">46</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_f6cd5989_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="yylength"/><a href="/source/s?refs=yylength&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yylength</a>()&#59;
</span><a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>     * Gets a character from the matched input text as documented by JFlex.
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>pos</em> &quot;a value from 0 to {<strong>@link</strong> #yylength()}-1&quot;
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> &quot;the character at position {<strong>@code</strong> pos} from the matched text. It
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>     * is equivalent to {<strong>@link</strong> #yytext()} then {<strong>@link</strong> String#charAt(int)} --
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>     * but faster.&quot;
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_b83dd865' class='scope-head'><span class='scope-signature'>yycharat(int pos)</span><a class="l" name="55" href="#55">55</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_b83dd865_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>char</b> <a class="xmt" name="yycharat"/><a href="/source/s?refs=yycharat&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yycharat</a>(<b>int</b> <a class="xa" name="pos"/><a href="/source/s?refs=pos&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">pos</a>)&#59;
</span><a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>     * Closes the input stream [as documented by JFlex]. All subsequent calls
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>     * to the scanning method will return the end of file value.
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs while closing
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_8002be9d' class='scope-head'><span class='scope-signature'>yyclose()</span><a class="l" name="62" href="#62">62</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_8002be9d_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yyclose"/><a href="/source/s?refs=yyclose&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yyclose</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>     * Closes the current input stream [as documented by JFlex], and resets
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>     * the scanner to read from a new Reader.
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>reader</em> the new reader
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_c78e425' class='scope-head'><span class='scope-signature'>yyreset(Reader reader)</span><a class="l" name="69" href="#69">69</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_c78e425_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yyreset"/><a href="/source/s?refs=yyreset&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yyreset</a>(<a href="/source/s?defs=Reader&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Reader</a> <a class="xa" name="reader"/><a href="/source/s?refs=reader&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">reader</a>)&#59;
</span><a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>     * Gets the current lexical state as documented by JFlex.
<a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> &quot;the current lexical state of the scanner.&quot;
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_4d096914' class='scope-head'><span class='scope-signature'>yystate()</span><a class="l" name="75" href="#75">75</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_4d096914_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="yystate"/><a href="/source/s?refs=yystate&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yystate</a>()&#59;
</span><a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span>     * Enters the lexical state {<strong>@code</strong> lexicalState} [as documented by JFlex].
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>lexicalState</em> the new state
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_51dd6713' class='scope-head'><span class='scope-signature'>yybegin(int lexicalState)</span><a class="l" name="81" href="#81">81</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_51dd6713_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yybegin"/><a href="/source/s?refs=yybegin&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yybegin</a>(<b>int</b> <a class="xa" name="lexicalState"/><a href="/source/s?refs=lexicalState&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">lexicalState</a>)&#59;
</span><a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span>     * &quot;Pushes {<strong>@code</strong> number} characters of the matched text back into the
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span>     * input stream [as documented by JFlex].
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;[The characters] will be read again in the next call of the scanning
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>     * method.
<a class="l" name="88" href="#88">88</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;The number of characters to be read again must not be greater than
<a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>     * the length of the matched text. The pushed back characters will not be
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span>     * included in {<strong>@link</strong> #yylength()} and {<strong>@link</strong> #yytext()}.&quot;
<a class="l" name="91" href="#91">91</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>number</em> the [constrained] number of characters
<a class="l" name="92" href="#92">92</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_367dede2' class='scope-head'><span class='scope-signature'>yypushback(int number)</span><a class="l" name="93" href="#93">93</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_367dede2_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yypushback"/><a href="/source/s?refs=yypushback&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yypushback</a>(<b>int</b> <a class="xa" name="number"/><a href="/source/s?refs=number&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">number</a>)&#59;
</span><a class="l" name="94" href="#94">94</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="95" href="#95">95</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="96" href="#96">96</a><span class='fold-space'>&nbsp;</span>     * &quot;Runs the scanner [as documented by JFlex].
<a class="l" name="97" href="#97">97</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;[The method] can be used to get the next token from the input.&quot;
<a class="l" name="98" href="#98">98</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;&quot;Consume[s] input until one of the expressions in the specification
<a class="l" name="99" href="#99">99</a><span class='fold-space'>&nbsp;</span>     * is matched or an error occurs.&quot;
<a class="hl" name="100" href="#100">100</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> a value returned by the lexer specification if defined or the
<a class="l" name="101" href="#101">101</a><span class='fold-space'>&nbsp;</span>     * {<strong>@code</strong> EOF} value upon reading end-of-file
<a class="l" name="102" href="#102">102</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs reading the input
<a class="l" name="103" href="#103">103</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_7e0e94ab' class='scope-head'><span class='scope-signature'>yylex()</span><a class="l" name="104" href="#104">104</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_7e0e94ab_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="yylex"/><a href="/source/s?refs=yylex&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yylex</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="105" href="#105">105</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="106" href="#106">106</a><span class='fold-space'>&nbsp;</span>