<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["NullWriter",35]]],["Package","xp",[["org.opengrok.indexer.util",24]]],["Method","xmt",[["close",46],["flush",42],["write",38]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, 2018 Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=Writer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Writer</a>&#59;
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> * Implementation of Writer that doesn&apos;t produce any ouput. Serves as a dummy
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * class where Writer is needed but the output is not relevant.
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> * <strong>@author</strong> tkotal
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="NullWriter"/><a href="/source/s?refs=NullWriter&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">NullWriter</a> <b>extends</b> <a href="/source/s?defs=Writer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Writer</a>  &#123;
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>    @<a href="/source/s?defs=Override&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Override</a>
<span id='scope_id_81d38c5b' class='scope-head'><span class='scope-signature'>write(char[] chars, int i, int i1)</span><a class="l" name="38" href="#38">38</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_81d38c5b_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="write"/><a href="/source/s?refs=write&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">write</a>(<b>char</b>[] <a class="xa" name="chars"/><a href="/source/s?refs=chars&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">chars</a>, <b>int</b> <a class="xa" name="i"/><a href="/source/s?refs=i&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">i</a>, <b>int</b> <a class="xa" name="i1"/><a href="/source/s?refs=i1&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">i1</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a> &#123;</span>
<span id='scope_id_81d38c5b_fold' class='scope-body'><a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>    @<a href="/source/s?defs=Override&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Override</a>
<span id='scope_id_3a8edec7' class='scope-head'><span class='scope-signature'>flush()</span><a class="l" name="42" href="#42">42</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_3a8edec7_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="flush"/><a href="/source/s?refs=flush&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">flush</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a> &#123;</span>
<span id='scope_id_3a8edec7_fold' class='scope-body'><a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>    @<a href="/source/s?defs=Override&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Override</a>
<span id='scope_id_3b0c4837' class='scope-head'><span class='scope-signature'>close()</span><a class="l" name="46" href="#46">46</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_3b0c4837_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="close"/><a href="/source/s?refs=close&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">close</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a> &#123;</span>
<span id='scope_id_3b0c4837_fold' class='scope-body'><a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>