<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",26]]],["Interface","xi",[["JFlexStackingLexer",34]]],["Method","xmt",[["emptyStack",70],["getLineNumber",63],["getYYCHAR",53],["getYYEOF",58],["yypop",48],["yypush",41]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2009, 2018, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> * Portions Copyright 2011 Jens Elkner.
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span> * Portions Copyright (c) 2017, 2019, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * Represents an API for an extension of {<strong>@link</strong> JFlexLexer} that needs to track
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> * a state stack.
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="JFlexStackingLexer"/><a href="/source/s?refs=JFlexStackingLexer&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">JFlexStackingLexer</a> <b>extends</b> <a href="/source/s?defs=JFlexLexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">JFlexLexer</a> &#123;
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     * Saves current {<strong>@link</strong> #yystate()} to stack, and enters the specified
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     * {<strong>@code</strong> newState} with {<strong>@link</strong> #yybegin(int)}.
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>newState</em> state id
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_6a96b016' class='scope-head'><span class='scope-signature'>yypush(int newState)</span><a class="l" name="41" href="#41">41</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_6a96b016_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yypush"/><a href="/source/s?refs=yypush&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yypush</a>(<b>int</b> <a class="xa" name="newState"/><a href="/source/s?refs=newState&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">newState</a>)&#59;
</span><a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * Pops the last state from the stack, and enters the state with
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * {<strong>@link</strong> #yybegin(int)}.
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if any error occurs while effecting the pop
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_acd328ee' class='scope-head'><span class='scope-signature'>yypop()</span><a class="l" name="48" href="#48">48</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_acd328ee_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="yypop"/><a href="/source/s?refs=yypop&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yypop</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     * Gets the yychar value.
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_594169ef' class='scope-head'><span class='scope-signature'>getYYCHAR()</span><a class="l" name="53" href="#53">53</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_594169ef_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="getYYCHAR"/><a href="/source/s?refs=getYYCHAR&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getYYCHAR</a>()&#59;
</span><a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>     * Gets the YYEOF value.
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_43e2e8a' class='scope-head'><span class='scope-signature'>getYYEOF()</span><a class="l" name="58" href="#58">58</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_43e2e8a_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="getYYEOF"/><a href="/source/s?refs=getYYEOF&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getYYEOF</a>()&#59;
</span><a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>     * Gets the yyline value.
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_af8dac37' class='scope-head'><span class='scope-signature'>getLineNumber()</span><a class="l" name="63" href="#63">63</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_af8dac37_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="getLineNumber"/><a href="/source/s?refs=getLineNumber&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getLineNumber</a>()&#59;
</span><a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>     * Tests if the instance&apos;s state stack is empty.
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> {<strong>@code</strong> true} if the stack contains no items; {<strong>@code</strong> false}
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>     * otherwise.
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_c85cc0d5' class='scope-head'><span class='scope-signature'>emptyStack()</span><a class="hl" name="70" href="#70">70</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_c85cc0d5_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>boolean</b> <a class="xmt" name="emptyStack"/><a href="/source/s?refs=emptyStack&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">emptyStack</a>()&#59;
</span><a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>