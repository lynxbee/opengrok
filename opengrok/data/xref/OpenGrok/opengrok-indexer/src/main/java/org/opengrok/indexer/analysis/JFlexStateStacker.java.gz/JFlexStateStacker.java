<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["JFlexStateStacker",35]]],["Package","xp",[["org.opengrok.indexer.analysis",26]]],["Method","xmt",[["clearStack",108],["emptyStack",95],["getLineNumber",88],["getYYEOF",82],["reset",44],["setLineNumber",103],["yyjump",73],["yypop",64],["yypush",54]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2009, 2018, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> * Portions Copyright 2011 Jens Elkner.
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span> * Portions Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=Stack&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Stack</a>&#59;
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> * Represents an abstract base class for resettable lexers that need to track
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> * a state stack.
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>abstract</b> <b>class</b> <a class="xc" name="JFlexStateStacker"/><a href="/source/s?refs=JFlexStateStacker&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">JFlexStateStacker</a> <b>implements</b> <a href="/source/s?defs=Resettable&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Resettable</a>,
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>    <a href="/source/s?defs=JFlexStackingLexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">JFlexStackingLexer</a> &#123;
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>    <b>protected</b> <b>final</b> <a href="/source/s?defs=Stack&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Stack</a>&lt;<a href="/source/s?defs=Integer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Integer</a>&gt; <a class="xfld" name="stack"/><a href="/source/s?refs=stack&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">stack</a> = <b>new</b> <a href="/source/s?defs=Stack&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Stack</a>&lt;&gt;()&#59;
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>     * Resets the instance using {<strong>@link</strong> #clearStack()}, and sets line number to
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>     * one.
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_7907b410' class='scope-head'><span class='scope-signature'>reset()</span><a class="l" name="44" href="#44">44</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_7907b410_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">reset</a>() &#123;</span>
<span id='scope_id_7907b410_fold' class='scope-body'><a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#clearStack" data-definition-place="defined-in-file">clearStack</a>()&#59;
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#setLineNumber" data-definition-place="defined-in-file">setLineNumber</a>(<span class="n">1</span>)&#59;
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     * Saves current {<strong>@link</strong> #yystate()} to stack, and enters the specified
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     * {<strong>@code</strong> newState} with {<strong>@link</strong> #yybegin(int)}.
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>newState</em> state id
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_16e74b38' class='scope-head'><span class='scope-signature'>yypush(int newState)</span><a class="l" name="54" href="#54">54</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_16e74b38_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="yypush"/><a href="/source/s?refs=yypush&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yypush</a>(<b>int</b> <a class="xa" name="newState"/><a href="/source/s?refs=newState&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">newState</a>) &#123;</span>
<span id='scope_id_16e74b38_fold' class='scope-body'><a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>        <b>this</b>.<a class="d intelliWindow-symbol" href="#stack" data-definition-place="defined-in-file">stack</a>.<a href="/source/s?defs=push&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">push</a>(<a href="/source/s?defs=yystate&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yystate</a>())&#59;
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>        <a href="/source/s?defs=yybegin&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yybegin</a>(<a href="/source/s?defs=newState&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">newState</a>)&#59;
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>     * Pops the last state from the stack, and enters the state with
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>     * {<strong>@link</strong> #yybegin(int)}.
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if any error occurs while effecting the pop
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_35d75374' class='scope-head'><span class='scope-signature'>yypop()</span><a class="l" name="64" href="#64">64</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_35d75374_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="yypop"/><a href="/source/s?refs=yypop&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yypop</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a> &#123;</span>
<span id='scope_id_35d75374_fold' class='scope-body'><a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>        <a href="/source/s?defs=yybegin&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yybegin</a>(<b>this</b>.<a class="d intelliWindow-symbol" href="#stack" data-definition-place="defined-in-file">stack</a>.<a href="/source/s?defs=pop&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pop</a>())&#59;
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>     * Calls {<strong>@link</strong> #clearStack()}, and enters the specified {<strong>@code</strong> newState}
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>     * with {<strong>@link</strong> #yybegin(int)}.
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>newState</em> state id
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_15e9d09' class='scope-head'><span class='scope-signature'>yyjump(int newState)</span><a class="l" name="73" href="#73">73</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_15e9d09_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>void</b> <a class="xmt" name="yyjump"/><a href="/source/s?refs=yyjump&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">yyjump</a>(<b>int</b> <a class="xa" name="newState"/><a href="/source/s?refs=newState&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">newState</a>) &#123;</span>
<span id='scope_id_15e9d09_fold' class='scope-body'><a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#clearStack" data-definition-place="defined-in-file">clearStack</a>()&#59;
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span>        <a href="/source/s?defs=yybegin&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yybegin</a>(<a href="/source/s?defs=newState&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">newState</a>)&#59;
<a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span>     * Gets the YYEOF value.
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> YYEOF
<a class="l" name="81" href="#81">81</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_9df6ee21' class='scope-head'><span class='scope-signature'>getYYEOF()</span><a class="l" name="82" href="#82">82</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_9df6ee21_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>abstract</b> <b>int</b> <a class="xmt" name="getYYEOF"/><a href="/source/s?refs=getYYEOF&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getYYEOF</a>()&#59;
</span><a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span>     * Gets the yyline value.
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> yyline
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_b8babd94' class='scope-head'><span class='scope-signature'>getLineNumber()</span><a class="l" name="88" href="#88">88</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_b8babd94_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>abstract</b> <b>int</b> <a class="xmt" name="getLineNumber"/><a href="/source/s?refs=getLineNumber&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getLineNumber</a>()&#59;
</span><a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="91" href="#91">91</a><span class='fold-space'>&nbsp;</span>     * Tests if the instance&apos;s state stack is empty.
<a class="l" name="92" href="#92">92</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> {<strong>@code</strong> true} if the stack contains no items; {<strong>@code</strong> false}
<a class="l" name="93" href="#93">93</a><span class='fold-space'>&nbsp;</span>     * otherwise.
<a class="l" name="94" href="#94">94</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_34a77498' class='scope-head'><span class='scope-signature'>emptyStack()</span><a class="l" name="95" href="#95">95</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_34a77498_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>boolean</b> <a class="xmt" name="emptyStack"/><a href="/source/s?refs=emptyStack&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">emptyStack</a>() &#123;</span>
<span id='scope_id_34a77498_fold' class='scope-body'><a class="l" name="96" href="#96">96</a><span class='fold-space'>&nbsp;</span>        <b>return</b> <a class="d intelliWindow-symbol" href="#stack" data-definition-place="defined-in-file">stack</a>.<a href="/source/s?defs=empty&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">empty</a>()&#59;
<a class="l" name="97" href="#97">97</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="98" href="#98">98</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="99" href="#99">99</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="hl" name="100" href="#100">100</a><span class='fold-space'>&nbsp;</span>     * Sets the yyline value.
<a class="l" name="101" href="#101">101</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>value</em> the new line number
<a class="l" name="102" href="#102">102</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_55d36a86' class='scope-head'><span class='scope-signature'>setLineNumber(int value)</span><a class="l" name="103" href="#103">103</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_55d36a86_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>protected</b> <b>abstract</b> <b>void</b> <a class="xmt" name="setLineNumber"/><a href="/source/s?refs=setLineNumber&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">setLineNumber</a>(<b>int</b> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">value</a>)&#59;
</span><a class="l" name="104" href="#104">104</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="105" href="#105">105</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="106" href="#106">106</a><span class='fold-space'>&nbsp;</span>     * Clears the instance stack.
<a class="l" name="107" href="#107">107</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_46b776f5' class='scope-head'><span class='scope-signature'>clearStack()</span><a class="l" name="108" href="#108">108</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_46b776f5_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>protected</b> <b>void</b> <a class="xmt" name="clearStack"/><a href="/source/s?refs=clearStack&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">clearStack</a>() &#123;</span>
<span id='scope_id_46b776f5_fold' class='scope-body'><a class="l" name="109" href="#109">109</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#stack" data-definition-place="defined-in-file">stack</a>.<a href="/source/s?defs=clear&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">clear</a>()&#59;
<a class="hl" name="110" href="#110">110</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="111" href="#111">111</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="112" href="#112">112</a><span class='fold-space'>&nbsp;</span>