<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",23]]],["Interface","xi",[["Resettable",29]]],["Method","xmt",[["reset",30]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span> * Represents an API for objects that can reset to an initial state without
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span> * any exceptions.
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="Resettable"/><a href="/source/s?refs=Resettable&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">Resettable</a> &#123;
<span id='scope_id_453e9193' class='scope-head'><span class='scope-signature'>reset()</span><a class="hl" name="30" href="#30">30</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_453e9193_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="reset"/><a href="/source/s?refs=reset&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">reset</a>()&#59;
</span><a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>