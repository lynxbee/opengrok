<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",24]]],["Interface","xi",[["NonSymbolMatchedListener",30]]],["Method","xmt",[["disjointSpanChanged",54],["endOfLineMatched",48],["keywordMatched",42],["linkageMatched",60],["nonSymbolMatched",36],["pathlikeMatched",66],["scopeChanged",72]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span> * Represents an API for a listener for non-symbolic or non-indexed symbol
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span> * matching events.
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="NonSymbolMatchedListener"/><a href="/source/s?refs=NonSymbolMatchedListener&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">NonSymbolMatchedListener</a> &#123;
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_65b8993d' class='scope-head'><span class='scope-signature'>nonSymbolMatched(TextMatchedEvent evt)</span><a class="l" name="36" href="#36">36</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_65b8993d_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="nonSymbolMatched"/><a href="/source/s?refs=nonSymbolMatched&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">nonSymbolMatched</a>(<a href="/source/s?defs=TextMatchedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TextMatchedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_d58df7f4' class='scope-head'><span class='scope-signature'>keywordMatched(TextMatchedEvent evt)</span><a class="l" name="42" href="#42">42</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_d58df7f4_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="keywordMatched"/><a href="/source/s?refs=keywordMatched&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">keywordMatched</a>(<a href="/source/s?defs=TextMatchedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TextMatchedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_86f36bdd' class='scope-head'><span class='scope-signature'>endOfLineMatched(TextMatchedEvent evt)</span><a class="l" name="48" href="#48">48</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_86f36bdd_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="endOfLineMatched"/><a href="/source/s?refs=endOfLineMatched&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">endOfLineMatched</a>(<a href="/source/s?defs=TextMatchedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TextMatchedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_37f0f1e1' class='scope-head'><span class='scope-signature'>disjointSpanChanged(DisjointSpanChangedEvent evt)</span><a class="l" name="54" href="#54">54</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_37f0f1e1_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="disjointSpanChanged"/><a href="/source/s?refs=disjointSpanChanged&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">disjointSpanChanged</a>(<a href="/source/s?defs=DisjointSpanChangedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">DisjointSpanChangedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_e5466afa' class='scope-head'><span class='scope-signature'>linkageMatched(LinkageMatchedEvent evt)</span><a class="hl" name="60" href="#60">60</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_e5466afa_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="linkageMatched"/><a href="/source/s?refs=linkageMatched&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">linkageMatched</a>(<a href="/source/s?defs=LinkageMatchedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">LinkageMatchedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_44c49f14' class='scope-head'><span class='scope-signature'>pathlikeMatched(PathlikeMatchedEvent evt)</span><a class="l" name="66" href="#66">66</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_44c49f14_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="pathlikeMatched"/><a href="/source/s?refs=pathlikeMatched&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">pathlikeMatched</a>(<a href="/source/s?defs=PathlikeMatchedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">PathlikeMatchedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>     * Receives an event instance.
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>evt</em> the event
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_11270619' class='scope-head'><span class='scope-signature'>scopeChanged(ScopeChangedEvent evt)</span><a class="l" name="72" href="#72">72</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_11270619_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="scopeChanged"/><a href="/source/s?refs=scopeChanged&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">scopeChanged</a>(<a href="/source/s?defs=ScopeChangedEvent&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ScopeChangedEvent</a> <a class="xa" name="evt"/><a href="/source/s?refs=evt&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">evt</a>)&#59;
</span><a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>