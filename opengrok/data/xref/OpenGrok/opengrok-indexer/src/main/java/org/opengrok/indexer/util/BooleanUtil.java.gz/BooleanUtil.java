<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["BooleanUtil",30]]],["Package","xp",[["org.opengrok.indexer.util",23]]],["Method","xmt",[["BooleanUtil",32],["isBoolean",52],["toInteger",68]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2018, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>&#59;
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span> * Boolean utility functions.
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span> * <strong>@author</strong> Krystof Tulinger
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="BooleanUtil"/><a href="/source/s?refs=BooleanUtil&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">BooleanUtil</a> &#123;
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span>
<span id='scope_id_a3da52ac' class='scope-head'><span class='scope-signature'>BooleanUtil()</span><a class="l" name="32" href="#32">32</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_a3da52ac_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>private</b> <a class="xmt" name="BooleanUtil"/><a href="/source/s?refs=BooleanUtil&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">BooleanUtil</a>() &#123;</span>
<span id='scope_id_a3da52ac_fold' class='scope-body'><a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * Validate the string if it contains a boolean value.
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     *
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     * Boolean values are (case insensitive):
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>     * &lt;ul&gt;
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;false&lt;/li&gt;
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;off&lt;/li&gt;
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;0&lt;/li&gt;
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;true&lt;/li&gt;
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;on&lt;/li&gt;
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     * &lt;li&gt;1&lt;/li&gt;
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>     * &lt;/ul&gt;
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>     *
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>value</em> the string value
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> if the value is boolean or not
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_ab973060' class='scope-head'><span class='scope-signature'>isBoolean(String value)</span><a class="l" name="52" href="#52">52</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_ab973060_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>static</b> <b>boolean</b> <a class="xmt" name="isBoolean"/><a href="/source/s?refs=isBoolean&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">isBoolean</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">value</a>) &#123;</span>
<span id='scope_id_ab973060_fold' class='scope-body'><a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>        <b>return</b> <span class="s">&quot;false&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>                || <span class="s">&quot;off&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>                || <span class="s">&quot;0&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>                || <span class="s">&quot;true&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>                || <span class="s">&quot;on&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>                || <span class="s">&quot;1&quot;</span>.<a href="/source/s?defs=equalsIgnoreCase&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">equalsIgnoreCase</a>(<a class="d intelliWindow-symbol" href="#value" data-definition-place="defined-in-file">value</a>)&#59;
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>     * Cast a boolean value to integer.
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>     *
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>b</em> boolean value
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> 0 for false and 1 for true
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_2a55f4c6' class='scope-head'><span class='scope-signature'>toInteger(boolean b)</span><a class="l" name="68" href="#68">68</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_2a55f4c6_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>static</b> <b>int</b> <a class="xmt" name="toInteger"/><a href="/source/s?refs=toInteger&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">toInteger</a>(<b>boolean</b> <a class="xa" name="b"/><a href="/source/s?refs=b&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">b</a>) &#123;</span>
<span id='scope_id_2a55f4c6_fold' class='scope-body'><a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>        <b>return</b> <a class="d intelliWindow-symbol" href="#b" data-definition-place="defined-in-file">b</a> ? <span class="n">1</span> : <span class="n">0</span>&#59;
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>