<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.util",10]]],["Interface","xi",[["ObjectFactory",18]]],["Method","xmt",[["createNew",24]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * The contents of this file are Copyright (c) 2012, Swaranga Sarma, DZone MVB
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> * made available under free license,
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * <a href="http://javawithswaranga.blogspot.com/2011/10/generic-and-concurrent-object-pool.html">http://javawithswaranga.blogspot.com/2011/10/generic-and-concurrent-object-pool.html</a>
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * <a href="https://dzone.com/articles/generic-and-concurrent-object">https://dzone.com/articles/generic-and-concurrent-object</a> : &quot;Feel free to use
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * it, change it, add more implementations. Happy coding!&quot;
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>&#59;
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * Represents an API for the mechanism to create
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * new objects to be used in an object pool.
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * <strong>@author</strong> Swaranga
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> * <strong>@param</strong> <em>&lt;T&gt;</em> the type of object to create.
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="ObjectFactory"/><a href="/source/s?refs=ObjectFactory&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">ObjectFactory</a>&lt;<a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a>&gt; &#123;
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span>     * Returns a new instance of an object of type T.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> T an new instance of the object of type T
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_74b4f83' class='scope-head'><span class='scope-signature'>createNew()</span><a class="l" name="24" href="#24">24</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_74b4f83_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=T&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">T</a> <a class="xmt" name="createNew"/><a href="/source/s?refs=createNew&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">createNew</a>()&#59;
</span><a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span>