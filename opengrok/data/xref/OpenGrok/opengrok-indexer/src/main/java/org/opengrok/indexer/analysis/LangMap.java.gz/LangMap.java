<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",24]]],["Interface","xi",[["LangMap",35]]],["Method","xmt",[["add",51],["clear",40],["exclude",58],["getAdditions",83],["getCtagsArgs",63],["getExclusions",88],["mergeSecondary",73],["unmodifiable",78]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2019, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=List&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">List</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=Map&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Map</a>&#59;
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=Set&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Set</a>&#59;
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * Represents an API for mapping file specifications versus languages and
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> * getting the ctags options representation (--langmap-&amp;lt;LANG&amp;gt; or
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span> * --map-&amp;lt;LANG&amp;gt;) thereof.
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="LangMap"/><a href="/source/s?refs=LangMap&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">LangMap</a> &#123;
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     * Removes all settings from this map.
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_cb305212' class='scope-head'><span class='scope-signature'>clear()</span><a class="hl" name="40" href="#40">40</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_cb305212_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="clear"/><a href="/source/s?refs=clear&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">clear</a>()&#59;
</span><a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     * Adds the specified mapping of a file specification to a language. Any
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * matching exclusion via {<strong>@link</strong> #exclude(String)} is undone.
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>fileSpec</em> a value starting with a period ({<strong>@code</strong> &apos;.&apos;}) to specify
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     *                 a file extension; otherwise specifying a prefix.
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IllegalArgumentException</em> if {<strong>@code</strong> fileSpec} is {<strong>@code</strong> null} or
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>     * is an extension (i.e. starting with a period) but contains any other
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>     * periods, as that is not ctags-compatible
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_12ee0217' class='scope-head'><span class='scope-signature'>add(String fileSpec, String ctagsLang)</span><a class="l" name="51" href="#51">51</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_12ee0217_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="add"/><a href="/source/s?refs=add&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">add</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="fileSpec"/><a href="/source/s?refs=fileSpec&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">fileSpec</a>, <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="ctagsLang"/><a href="/source/s?refs=ctagsLang&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">ctagsLang</a>)&#59;
</span><a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>     * Exclude the specified mapping of a file specification to any language.
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>     * Any matching addition via {<strong>@link</strong> #add(String, String)} is undone.
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IllegalArgumentException</em> if {<strong>@code</strong> fileSpec} is {<strong>@code</strong> null}
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_e4e8ddb4' class='scope-head'><span class='scope-signature'>exclude(String fileSpec)</span><a class="l" name="58" href="#58">58</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_e4e8ddb4_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="exclude"/><a href="/source/s?refs=exclude&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">exclude</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="fileSpec"/><a href="/source/s?refs=fileSpec&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">fileSpec</a>)&#59;
</span><a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>     * Gets the transformation of the instance&apos;s mappings to ctags arguments.
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_cd5f5b81' class='scope-head'><span class='scope-signature'>getCtagsArgs()</span><a class="l" name="63" href="#63">63</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_cd5f5b81_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=List&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">List</a>&lt;<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>&gt; <a class="xmt" name="getCtagsArgs"/><a href="/source/s?refs=getCtagsArgs&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getCtagsArgs</a>()&#59;
</span><a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>     * Creates a new instance, merging the settings from the current instance
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>     * overlaying a specified {<strong>@code</strong> other}. Additions from the current instance
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>     * take precedence, and exclusions from the {<strong>@code</strong> other} only take effect
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>     * if the current instance has no matching addition.
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>other</em> a defined instance
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> a defined instance
<a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_27fc383b' class='scope-head'><span class='scope-signature'>mergeSecondary(LangMap other)</span><a class="l" name="73" href="#73">73</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_27fc383b_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a class="d intelliWindow-symbol" href="#LangMap" data-definition-place="defined-in-file">LangMap</a> <a class="xmt" name="mergeSecondary"/><a href="/source/s?refs=mergeSecondary&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">mergeSecondary</a>(<a class="d intelliWindow-symbol" href="#LangMap" data-definition-place="defined-in-file">LangMap</a> <a class="xa" name="other"/><a href="/source/s?refs=other&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">other</a>)&#59;
</span><a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span>     * Gets an unmodifiable view of the current instance.
<a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_a8d2573f' class='scope-head'><span class='scope-signature'>unmodifiable()</span><a class="l" name="78" href="#78">78</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_a8d2573f_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a class="d intelliWindow-symbol" href="#LangMap" data-definition-place="defined-in-file">LangMap</a> <a class="xmt" name="unmodifiable"/><a href="/source/s?refs=unmodifiable&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">unmodifiable</a>()&#59;
</span><a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="81" href="#81">81</a><span class='fold-space'>&nbsp;</span>     * Gets an unmodifiable view of the current additions.
<a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_27b342bd' class='scope-head'><span class='scope-signature'>getAdditions()</span><a class="l" name="83" href="#83">83</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_27b342bd_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=Map&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Map</a>&lt;<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>, <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>&gt; <a class="xmt" name="getAdditions"/><a href="/source/s?refs=getAdditions&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getAdditions</a>()&#59;
</span><a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>     * Gets an unmodifiable view of the current exclusions.
<a class="l" name="87" href="#87">87</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_2e66279c' class='scope-head'><span class='scope-signature'>getExclusions()</span><a class="l" name="88" href="#88">88</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_2e66279c_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=Set&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Set</a>&lt;<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>&gt; <a class="xmt" name="getExclusions"/><a href="/source/s?refs=getExclusions&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getExclusions</a>()&#59;
</span><a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="hl" name="90" href="#90">90</a><span class='fold-space'>&nbsp;</span>