<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["Consts",31]]],["Package","xp",[["org.opengrok.indexer.analysis.json",23]]],["Method","xmt",[["Consts",70]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span> <span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, 2018 Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>.<a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>&#59;
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=HashSet&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">HashSet</a>&#59;
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=Set&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Set</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> * Holds static hash set containing the Json (schema) keywords.
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="Consts"/><a href="/source/s?refs=Consts&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">Consts</a> &#123;
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>    <b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Set&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Set</a>&lt;<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>&gt; <a class="xfld" name="kwd"/><a href="/source/s?refs=kwd&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">kwd</a> = <b>new</b> <a href="/source/s?defs=HashSet&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">HashSet</a>&lt;&gt;()&#59;
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>    <b>static</b> &#123;
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#kwd" data-definition-place="defined-in-file">kwd</a>.<a href="/source/s?defs=add&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">add</a>(<span class="s">&quot;true&quot;</span>)&#59;
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#kwd" data-definition-place="defined-in-file">kwd</a>.<a href="/source/s?defs=add&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">add</a>(<span class="s">&quot;false&quot;</span>)&#59;
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>        <a class="d intelliWindow-symbol" href="#kwd" data-definition-place="defined-in-file">kwd</a>.<a href="/source/s?defs=add&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">add</a>(<span class="s">&quot;null&quot;</span>)&#59;
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span><span class="c">//TODO below applies ONLY for schema - detect this is a schema and use keywords, not otherwise</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>    <span class="c">//json as such has no keywords</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>        kwd.add(&quot;title&quot;);
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>        kwd.add(&quot;description&quot;);
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>        kwd.add(&quot;default&quot;);
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>        kwd.add(&quot;enum&quot;);
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>        kwd.add(&quot;Boolean&quot;);
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>        string
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>        pattern
<a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>        format
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>        date-time email
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>        hostname ipv4
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>        ipv6 uri
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>        integer number
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>        multipleOf minimum, maximum, exclusiveMinimum and exclusiveMaximum
<a class="l" name="58" href="#58">58</a><span class='fold-space'>&nbsp;</span>        object properties
<a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>        additionalProperties required
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>        minProperties maxProperties
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>        dependencies
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>        ...
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>    array...
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>    boolean...
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>        null...
<a class="l" name="66" href="#66">66</a><span class='fold-space'>&nbsp;</span>*/</span>
<a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>    &#125;
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>
<span id='scope_id_2a9ea06a' class='scope-head'><span class='scope-signature'>Consts()</span><a class="hl" name="70" href="#70">70</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_2a9ea06a_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>private</b> <a class="xmt" name="Consts"/><a href="/source/s?refs=Consts&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">Consts</a>() &#123;</span>
<span id='scope_id_2a9ea06a_fold' class='scope-body'><a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="72" href="#72">72</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>