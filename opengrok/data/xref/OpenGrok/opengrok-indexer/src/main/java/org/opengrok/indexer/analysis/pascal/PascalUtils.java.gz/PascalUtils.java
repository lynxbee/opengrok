<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["PascalUtils",31]]],["Package","xp",[["org.opengrok.indexer.analysis.pascal",24]]],["Method","xmt",[["PascalUtils",50]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2018, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>.<a href="/source/s?defs=pascal&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pascal</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=util&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">util</a>.<a href="/source/s?defs=regex&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">regex</a>.<a href="/source/s?defs=Pattern&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Pattern</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> * Represents a container for Pascal-related utility methods.
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="PascalUtils"/><a href="/source/s?refs=PascalUtils&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">PascalUtils</a> &#123;
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>     * Matches an apostrophe that is not&#185; part of a Pascal apostrophe escape sequence.
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>     * &lt;p&gt;
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * &#185;Correctness in a long sequence of apostrophes is limited because Java
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     * look-behind is not variable length but instead must have a definite
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     * upper bound in the regex definition.
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     * &lt;/p&gt;
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>     */</span>
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>    <b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Pattern&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Pattern</a> <a class="xfld" name="CHARLITERAL_APOS_DELIMITER"/><a href="/source/s?refs=CHARLITERAL_APOS_DELIMITER&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">CHARLITERAL_APOS_DELIMITER</a> =
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>        <a href="/source/s?defs=Pattern&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Pattern</a>.<a href="/source/s?defs=compile&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">compile</a>(<span class="s">&quot;\\&apos;((?&lt;=^.(?!\\&apos;))|(?&lt;=[^\\&apos;].(?!\\&apos;))|(?&lt;=^(\\&apos;\\&apos;){1,3}.(?!\\&apos;))|(?&lt;=[^\\&apos;](\\&apos;\\&apos;){1,3}.(?!\\&apos;)))&quot;</span>)&#59;
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * Matches the close of an old-style Pascal comment.
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     */</span>
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>    <b>public</b> <b>static</b> <b>final</b> <a href="/source/s?defs=Pattern&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Pattern</a> <a class="xfld" name="END_OLD_PASCAL_COMMENT"/><a href="/source/s?refs=END_OLD_PASCAL_COMMENT&amp;project=OpenGrok" class="xfld intelliWindow-symbol" data-definition-place="def">END_OLD_PASCAL_COMMENT</a> = <a href="/source/s?defs=Pattern&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Pattern</a>.<a href="/source/s?defs=compile&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">compile</a>(<span class="s">&quot;\\*\\)&quot;</span>)&#59;
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>    <span class="c">/** Private to enforce static. */</span>
<span id='scope_id_1fb2cd0b' class='scope-head'><span class='scope-signature'>PascalUtils()</span><a class="hl" name="50" href="#50">50</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_1fb2cd0b_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>private</b> <a class="xmt" name="PascalUtils"/><a href="/source/s?refs=PascalUtils&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">PascalUtils</a>() &#123;</span>
<span id='scope_id_1fb2cd0b_fold' class='scope-body'><a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>