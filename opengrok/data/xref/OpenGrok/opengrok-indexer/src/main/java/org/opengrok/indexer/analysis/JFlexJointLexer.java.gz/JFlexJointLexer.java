<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.indexer.analysis",24]]],["Interface","xi",[["JFlexJointLexer",33]]],["Method","xmt",[["disjointSpan",81],["offer",40],["offerKeyword",66],["offerSymbol",51],["phLOC",87],["skipSymbol",58],["startNewLine",72]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2017, Chris Fraire &lt;cfraire@me.com&gt;.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=indexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">indexer</a>.<a href="/source/s?defs=analysis&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">analysis</a>&#59;
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span> * Represents an API for JFlex lexers that produce multiple types of derived
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span> * OpenGrok documents (e.g., cross-reference documents [xrefs] or Lucene search
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * documents [tokenizers]) from the same JFlex productions.
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="JFlexJointLexer"/><a href="/source/s?refs=JFlexJointLexer&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">JFlexJointLexer</a> <b>extends</b> <a href="/source/s?defs=JFlexStackingLexer&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">JFlexStackingLexer</a> &#123;
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * Passes non-symbolic fragment for processing.
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>value</em> the excised fragment
<a class="l" name="38" href="#38">38</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs while accepting
<a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_2aa129df' class='scope-head'><span class='scope-signature'>offer(String value)</span><a class="hl" name="40" href="#40">40</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_2aa129df_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="offer"/><a href="/source/s?refs=offer&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">offer</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">value</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     * Passes a text fragment that is syntactically a symbol for processing.
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>value</em> the excised symbol
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>captureOffset</em> the offset from yychar where {<strong>@code</strong> value} began
<a class="l" name="46" href="#46">46</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>ignoreKwd</em> a value indicating whether keywords should be ignored
<a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> true if the {<strong>@code</strong> value} was not in keywords or if the
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>     * {<strong>@code</strong> ignoreKwd} was true
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs while accepting
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_f83b9df1' class='scope-head'><span class='scope-signature'>offerSymbol(String value, int captureOffset, boolean ignoreKwd)</span><a class="l" name="51" href="#51">51</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_f83b9df1_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>boolean</b> <a class="xmt" name="offerSymbol"/><a href="/source/s?refs=offerSymbol&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">offerSymbol</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">value</a>, <b>int</b> <a class="xa" name="captureOffset"/><a href="/source/s?refs=captureOffset&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">captureOffset</a>, <b>boolean</b> <a class="xa" name="ignoreKwd"/><a href="/source/s?refs=ignoreKwd&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">ignoreKwd</a>)</span>
<span id='scope_id_f83b9df1_fold' class='scope-body'><a class="l" name="52" href="#52">52</a><span class='fold-space'>&nbsp;</span>        <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>     * Indicates that something unusual happened where normally a symbol would
<a class="l" name="56" href="#56">56</a><span class='fold-space'>&nbsp;</span>     * have been offered.
<a class="l" name="57" href="#57">57</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_1e74f95b' class='scope-head'><span class='scope-signature'>skipSymbol()</span><a class="l" name="58" href="#58">58</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_1e74f95b_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="skipSymbol"/><a href="/source/s?refs=skipSymbol&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">skipSymbol</a>()&#59;
</span><a class="l" name="59" href="#59">59</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="60" href="#60">60</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="61" href="#61">61</a><span class='fold-space'>&nbsp;</span>     * Passes a text fragment that is syntactically a keyword symbol for
<a class="l" name="62" href="#62">62</a><span class='fold-space'>&nbsp;</span>     * processing.
<a class="l" name="63" href="#63">63</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>value</em> the excised symbol
<a class="l" name="64" href="#64">64</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs while accepting
<a class="l" name="65" href="#65">65</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_a902006c' class='scope-head'><span class='scope-signature'>offerKeyword(String value)</span><a class="l" name="66" href="#66">66</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_a902006c_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="offerKeyword"/><a href="/source/s?refs=offerKeyword&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">offerKeyword</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="value"/><a href="/source/s?refs=value&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">value</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="67" href="#67">67</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="68" href="#68">68</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="69" href="#69">69</a><span class='fold-space'>&nbsp;</span>     * Indicates that the current line is ended.
<a class="hl" name="70" href="#70">70</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurs when handling the EOL
<a class="l" name="71" href="#71">71</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_be01fb0e' class='scope-head'><span class='scope-signature'>startNewLine()</span><a class="l" name="72" href="#72">72</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_be01fb0e_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="startNewLine"/><a href="/source/s?refs=startNewLine&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">startNewLine</a>() <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="73" href="#73">73</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="74" href="#74">74</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="75" href="#75">75</a><span class='fold-space'>&nbsp;</span>     * Indicates the closing of an open tag and the opening -- if
<a class="l" name="76" href="#76">76</a><span class='fold-space'>&nbsp;</span>     * {<strong>@code</strong> className} is non-null -- of a new one.
<a class="l" name="77" href="#77">77</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>className</em> the class name for the new tag or {<strong>@code</strong> null} just to
<a class="l" name="78" href="#78">78</a><span class='fold-space'>&nbsp;</span>     * close an open tag.
<a class="l" name="79" href="#79">79</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an output error occurs
<a class="hl" name="80" href="#80">80</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_f484da6c' class='scope-head'><span class='scope-signature'>disjointSpan(String className)</span><a class="l" name="81" href="#81">81</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_f484da6c_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="disjointSpan"/><a href="/source/s?refs=disjointSpan&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">disjointSpan</a>(<a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xa" name="className"/><a href="/source/s?refs=className&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">className</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="82" href="#82">82</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="83" href="#83">83</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="84" href="#84">84</a><span class='fold-space'>&nbsp;</span>     * Indicates that eligible source code was encountered for physical
<a class="l" name="85" href="#85">85</a><span class='fold-space'>&nbsp;</span>     * lines-of-code count (physical LOC).
<a class="l" name="86" href="#86">86</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_9adebd4a' class='scope-head'><span class='scope-signature'>phLOC()</span><a class="l" name="87" href="#87">87</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_9adebd4a_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>void</b> <a class="xmt" name="phLOC"/><a href="/source/s?refs=phLOC&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">phLOC</a>()&#59;
</span><a class="l" name="88" href="#88">88</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="89" href="#89">89</a><span class='fold-space'>&nbsp;</span>