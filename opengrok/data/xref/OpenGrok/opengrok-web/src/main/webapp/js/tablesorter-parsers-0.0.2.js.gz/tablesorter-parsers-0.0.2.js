<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["AnonymousFunction7a5dddc30100",25],["AnonymousFunction7a5dddc30200",29],["AnonymousFunction7a5dddc30300",44],["AnonymousFunction7a5dddc30400",48]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">/*
<a class="l" name="2" href="#2">2</a> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a> *
<a class="l" name="4" href="#4">4</a> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a> *
<a class="l" name="8" href="#8">8</a> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a> *
<a class="l" name="11" href="#11">11</a> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a> *
<a class="l" name="17" href="#17">17</a> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a> */</span>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><span class="c">/*
<a class="l" name="21" href="#21">21</a> * Copyright (c) 2016, 2019 Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a> */</span>
<a class="l" name="23" href="#23">23</a><a href="/source/s?defs=%24&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$</a>.<a href="/source/s?defs=tablesorter&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tablesorter</a>.<a href="/source/s?defs=addParser&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">addParser</a>({
<a class="l" name="24" href="#24">24</a>    <a href="/source/s?defs=id&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">id</a>: <span class="s">&apos;dates&apos;</span>,
<a class="l" name="25" href="#25">25</a>    <a href="/source/s?defs=is&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">is</a>: <b>function</b> (<a class="xa" name="s"/><a href="/source/s?refs=s&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">s</a>) {
<a class="l" name="26" href="#26">26</a>        <span class="c">// return false so this parser is not auto detected</span>
<a class="l" name="27" href="#27">27</a>        <b>return</b> <b>false</b>;
<a class="l" name="28" href="#28">28</a>    },
<a class="l" name="29" href="#29">29</a>    <a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>: <b>function</b> (<a class="xa" name="s"/><a href="/source/s?refs=s&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">s</a>) {
<a class="hl" name="30" href="#30">30</a>        <b>var</b> <a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a> = <a href="/source/s?defs=s&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">s</a>.<a href="/source/s?defs=match&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>(<span class="s">/^(\d{2})\-(\w{3})\-(\d{4})$/</span>);
<a class="l" name="31" href="#31">31</a>        <b>if</b> (!<a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a>) {
<a class="l" name="32" href="#32">32</a>            <b>return</b> <b>new</b> <b>Date</b>().<a href="/source/s?defs=getTime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getTime</a>();
<a class="l" name="33" href="#33">33</a>        }
<a class="l" name="34" href="#34">34</a>        <b>var</b> <a href="/source/s?defs=d&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">d</a> = <a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a>[<span class="n">1</span>];
<a class="l" name="35" href="#35">35</a>        <b>var</b> <a href="/source/s?defs=m&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">m</a> = <a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a>[<span class="n">2</span>];
<a class="l" name="36" href="#36">36</a>        <b>var</b> <a href="/source/s?defs=y&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">y</a> = <a href="/source/s?defs=date&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">date</a>[<span class="n">3</span>];
<a class="l" name="37" href="#37">37</a>        <b>return</b> <b>new</b> <b>Date</b>(<a href="/source/s?defs=m&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">m</a> + <span class="s">&apos; &apos;</span> + <a href="/source/s?defs=d&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">d</a> + <span class="s">&apos; &apos;</span> + <a href="/source/s?defs=y&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">y</a>).<a href="/source/s?defs=getTime&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">getTime</a>();
<a class="l" name="38" href="#38">38</a>    },
<a class="l" name="39" href="#39">39</a>    <a href="/source/s?defs=type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">type</a>: <span class="s">&apos;numeric&apos;</span>
<a class="hl" name="40" href="#40">40</a>});
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a><a href="/source/s?defs=%24&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">$</a>.<a href="/source/s?defs=tablesorter&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tablesorter</a>.<a href="/source/s?defs=addParser&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">addParser</a>({
<a class="l" name="43" href="#43">43</a>    <a href="/source/s?defs=id&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">id</a>: <span class="s">&apos;groksizes&apos;</span>,
<a class="l" name="44" href="#44">44</a>    <a href="/source/s?defs=is&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">is</a>: <b>function</b> (<a class="xa" name="s"/><a href="/source/s?refs=s&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">s</a>) {
<a class="l" name="45" href="#45">45</a>        <span class="c">// return false so this parser is not auto detected</span>
<a class="l" name="46" href="#46">46</a>        <b>return</b> <b>false</b>;
<a class="l" name="47" href="#47">47</a>    },
<a class="l" name="48" href="#48">48</a>    <a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>: <b>function</b> (<a class="xa" name="s"/><a href="/source/s?refs=s&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">s</a>) {
<a class="l" name="49" href="#49">49</a>        <span class="c">/*
<a class="hl" name="50" href="#50">50</a>         * This correctly handles thousand separator
<a class="l" name="51" href="#51">51</a>         * in a big number (either &apos;,&apos; or &apos; &apos; or none)
<a class="l" name="52" href="#52">52</a>         *
<a class="l" name="53" href="#53">53</a>         * In our case there is a little gap between 1000 and 1023 which
<a class="l" name="54" href="#54">54</a>         * is still smaller than the next order unit. This should accept all
<a class="l" name="55" href="#55">55</a>         * values like:
<a class="l" name="56" href="#56">56</a>         * 1,000 or 1 000 or 1,023
<a class="l" name="57" href="#57">57</a>         *
<a class="l" name="58" href="#58">58</a>         * However it is more generic just in case. It should not have trouble
<a class="l" name="59" href="#59">59</a>         * with:
<a class="hl" name="60" href="#60">60</a>         * 1,000,123,133.235
<a class="l" name="61" href="#61">61</a>         * 1 000.4564
<a class="l" name="62" href="#62">62</a>         * and with even misspelled numbers:
<a class="l" name="63" href="#63">63</a>         * 1,00,345,0.123 (wrong number of digits between the separator)
<a class="l" name="64" href="#64">64</a>         * 13,456 13 45.1234 (mixed separators)
<a class="l" name="65" href="#65">65</a>         * 1000,123 (wrong number of digits between the separator)
<a class="l" name="66" href="#66">66</a>         * 1,123534435,134547435.165165165 (again)
<a class="l" name="67" href="#67">67</a>         */</span>
<a class="l" name="68" href="#68">68</a>        <b>var</b> <a href="/source/s?defs=parts&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parts</a> = <a href="/source/s?defs=s&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">s</a>.<a href="/source/s?defs=match&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">match</a>(<span class="s">/^(\d{1,3}(?:[, ]?\d{1,3})*(?:\.\d+)?|\.\d+) ?(\w*)$/</span>);
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>        <b>if</b> (<a href="/source/s?defs=parts&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parts</a> === <b>null</b> || <a href="/source/s?defs=parts&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parts</a>.<a href="/source/s?defs=length&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">length</a> &lt; <span class="n">3</span>) {
<a class="l" name="71" href="#71">71</a>            <b>return</b> <span class="n">0</span>;
<a class="l" name="72" href="#72">72</a>        }
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>        <b>var</b> <a href="/source/s?defs=num&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">num</a> = <a href="/source/s?defs=parts&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parts</a>[<span class="n">1</span>].<a href="/source/s?defs=replace&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">replace</a>(<span class="s">/[, ]/</span>g, <span class="s">&quot;&quot;</span>);
<a class="l" name="75" href="#75">75</a>        <b>var</b> <a href="/source/s?defs=unit&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unit</a> = <a href="/source/s?defs=parts&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parts</a>[<span class="n">2</span>];
<a class="l" name="76" href="#76">76</a>
<a class="l" name="77" href="#77">77</a>        <span class="c">// convert to bytes</span>
<a class="l" name="78" href="#78">78</a>        <b>if</b> (<a href="/source/s?defs=unit&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unit</a> == <span class="s">&quot;KiB&quot;</span>) {
<a class="l" name="79" href="#79">79</a>            <b>return</b> (<a href="/source/s?defs=num&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">num</a> * <span class="n">1024</span>);
<a class="hl" name="80" href="#80">80</a>        } <b>else</b> <b>if</b> (<a href="/source/s?defs=unit&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unit</a> == <span class="s">&quot;MiB&quot;</span>) {
<a class="l" name="81" href="#81">81</a>            <b>return</b> (<a href="/source/s?defs=num&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">num</a> * <span class="n">1024</span> * <span class="n">1024</span>);
<a class="l" name="82" href="#82">82</a>        } <b>else</b> <b>if</b> (<a href="/source/s?defs=unit&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">unit</a> == <span class="s">&quot;GiB&quot;</span>) {
<a class="l" name="83" href="#83">83</a>            <b>return</b> (<a href="/source/s?defs=num&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">num</a> * <span class="n">1024</span> * <span class="n">1024</span> * <span class="n">1024</span>);
<a class="l" name="84" href="#84">84</a>        } <b>else</b> {
<a class="l" name="85" href="#85">85</a>            <b>return</b> (<a href="/source/s?defs=num&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">num</a>);
<a class="l" name="86" href="#86">86</a>        }
<a class="l" name="87" href="#87">87</a>    },
<a class="l" name="88" href="#88">88</a>    <a href="/source/s?defs=type&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">type</a>: <span class="s">&apos;numeric&apos;</span>
<a class="l" name="89" href="#89">89</a>});
<a class="hl" name="90" href="#90">90</a>