<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["SCRIPT_DIR",6]]],["Function","xf",[["readme",9]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><b>import</b> <a href="/source/s?defs=os&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>
<a class="l" name="2" href="#2">2</a><b>from</b> <a href="/source/s?defs=setuptools&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">setuptools</a> <b>import</b> <a href="/source/s?defs=setup&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">setup</a>
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a><b>from</b> <a href="/source/s?defs=src&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">src</a>.<a href="/source/s?defs=main&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">main</a>.<a href="/source/s?defs=python&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">python</a>.<a href="/source/s?defs=opengrok_tools&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok_tools</a>.<a class="d" name="version"/><a href="/source/s?refs=version&amp;project=OpenGrok" class="d intelliWindow-symbol" data-definition-place="def">version</a> <b>import</b> <a href="/source/s?defs=__version__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__version__</a> <b>as</b> <a class="d intelliWindow-symbol" href="#version" data-definition-place="defined-in-file">version</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><a class="xv" name="SCRIPT_DIR"/><a href="/source/s?refs=SCRIPT_DIR&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">SCRIPT_DIR</a> = <a href="/source/s?defs=os&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>.<a href="/source/s?defs=path&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/source/s?defs=dirname&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">dirname</a>(<a href="/source/s?defs=os&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>.<a href="/source/s?defs=path&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/source/s?defs=realpath&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">realpath</a>(<a href="/source/s?defs=__file__&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">__file__</a>))
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a><b>def</b> <a class="xf" name="readme"/><a href="/source/s?refs=readme&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">readme</a>():
<a class="hl" name="10" href="#10">10</a>    <b>with</b> <a href="/source/s?defs=open&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a href="/source/s?defs=os&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">os</a>.<a href="/source/s?defs=path&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">path</a>.<a href="/source/s?defs=join&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">join</a>(<a class="d intelliWindow-symbol" href="#SCRIPT_DIR" data-definition-place="defined-in-file">SCRIPT_DIR</a>, <span class="s">&apos;<a href="/source/s?path=README-dist.txt&amp;project=OpenGrok">README-dist.txt</a>&apos;</span>), <span class="s">&apos;r&apos;</span>) <b>as</b> <a class="d intelliWindow-symbol" href="#readme" data-definition-place="defined-in-file">readme</a>:
<a class="l" name="11" href="#11">11</a>        <b>return</b> <a class="d intelliWindow-symbol" href="#readme" data-definition-place="defined-in-file">readme</a>.<a href="/source/s?defs=read&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">read</a>()
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a><a href="/source/s?defs=setup&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">setup</a>(
<a class="l" name="15" href="#15">15</a>    <a href="/source/s?defs=name&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">name</a>=<span class="s">&apos;opengrok-tools&apos;</span>,
<a class="l" name="16" href="#16">16</a>    <a class="d intelliWindow-symbol" href="#version" data-definition-place="defined-in-file">version</a>=<a class="d intelliWindow-symbol" href="#version" data-definition-place="defined-in-file">version</a>,
<a class="l" name="17" href="#17">17</a>    <a href="/source/s?defs=packages&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">packages</a>=[
<a class="l" name="18" href="#18">18</a>        <span class="s">&apos;opengrok_tools&apos;</span>,
<a class="l" name="19" href="#19">19</a>        <span class="s">&apos;opengrok_tools.utils&apos;</span>,
<a class="hl" name="20" href="#20">20</a>        <span class="s">&apos;opengrok_tools.scm&apos;</span>,
<a class="l" name="21" href="#21">21</a>    ],
<a class="l" name="22" href="#22">22</a>    <a href="/source/s?defs=package_dir&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">package_dir</a>={
<a class="l" name="23" href="#23">23</a>        <span class="s">&apos;opengrok_tools&apos;</span>: <span class="s">&apos;<a href="/source/s?path=src/&amp;project=OpenGrok">src</a>/<a href="/source/s?path=src/main/&amp;project=OpenGrok">main</a>/<a href="/source/s?path=src/main/python/&amp;project=OpenGrok">python</a>/<a href="/source/s?path=src/main/python/opengrok_tools&amp;project=OpenGrok">opengrok_tools</a>&apos;</span>,
<a class="l" name="24" href="#24">24</a>        <span class="s">&apos;opengrok_tools.scm&apos;</span>: <span class="s">&apos;<a href="/source/s?path=src/&amp;project=OpenGrok">src</a>/<a href="/source/s?path=src/main/&amp;project=OpenGrok">main</a>/<a href="/source/s?path=src/main/python/&amp;project=OpenGrok">python</a>/<a href="/source/s?path=src/main/python/opengrok_tools/&amp;project=OpenGrok">opengrok_tools</a>/<a href="/source/s?path=src/main/python/opengrok_tools/scm&amp;project=OpenGrok">scm</a>&apos;</span>,
<a class="l" name="25" href="#25">25</a>        <span class="s">&apos;opengrok_tools.utils&apos;</span>: <span class="s">&apos;<a href="/source/s?path=src/&amp;project=OpenGrok">src</a>/<a href="/source/s?path=src/main/&amp;project=OpenGrok">main</a>/<a href="/source/s?path=src/main/python/&amp;project=OpenGrok">python</a>/<a href="/source/s?path=src/main/python/opengrok_tools/&amp;project=OpenGrok">opengrok_tools</a>/<a href="/source/s?path=src/main/python/opengrok_tools/utils&amp;project=OpenGrok">utils</a>&apos;</span>,
<a class="l" name="26" href="#26">26</a>    },
<a class="l" name="27" href="#27">27</a>    <a href="/source/s?defs=url&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">url</a>=<span class="s">&apos;<a href="https://github.com/OpenGrok/OpenGrok">https://github.com/OpenGrok/OpenGrok</a>&apos;</span>,
<a class="l" name="28" href="#28">28</a>    <a href="/source/s?defs=license&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">license</a>=<span class="s">&apos;CDDL&apos;</span>,
<a class="l" name="29" href="#29">29</a>    <a href="/source/s?defs=author&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">author</a>=<span class="s">&apos;Oracle&apos;</span>,
<a class="hl" name="30" href="#30">30</a>    <a href="/source/s?defs=author_email&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">author_email</a>=<span class="s">&apos;opengrok-dev@yahoogroups.com&apos;</span>,
<a class="l" name="31" href="#31">31</a>    <a href="/source/s?defs=description&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">description</a>=<span class="s">&apos;Tools for managing OpenGrok instance&apos;</span>,
<a class="l" name="32" href="#32">32</a>    <a href="/source/s?defs=long_description&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">long_description</a>=<a class="d intelliWindow-symbol" href="#readme" data-definition-place="defined-in-file">readme</a>(),
<a class="l" name="33" href="#33">33</a>    <a href="/source/s?defs=python_requires&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">python_requires</a>=<span class="s">&apos;&gt;=3.4, &lt;4&apos;</span>,
<a class="l" name="34" href="#34">34</a>    <a href="/source/s?defs=install_requires&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">install_requires</a>=[
<a class="l" name="35" href="#35">35</a>        <span class="s">&apos;jsonschema==2.6.0&apos;</span>,
<a class="l" name="36" href="#36">36</a>        <span class="s">&apos;pyyaml&apos;</span>,
<a class="l" name="37" href="#37">37</a>        <span class="s">&apos;requests&gt;=2.20.0&apos;</span>,
<a class="l" name="38" href="#38">38</a>        <span class="s">&apos;resource&apos;</span>,
<a class="l" name="39" href="#39">39</a>        <span class="s">&apos;filelock&apos;</span>,
<a class="hl" name="40" href="#40">40</a>        <span class="s">&apos;setuptools&gt;=36.7.2&apos;</span>,
<a class="l" name="41" href="#41">41</a>    ],
<a class="l" name="42" href="#42">42</a>    <a href="/source/s?defs=setup_requires&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">setup_requires</a>=[
<a class="l" name="43" href="#43">43</a>        <span class="s">&apos;pytest-runner&apos;</span>,
<a class="l" name="44" href="#44">44</a>        <span class="s">&apos;setuptools&gt;=36.7.2&apos;</span>,
<a class="l" name="45" href="#45">45</a>    ],
<a class="l" name="46" href="#46">46</a>    <a href="/source/s?defs=tests_require&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">tests_require</a>=[
<a class="l" name="47" href="#47">47</a>        <span class="s">&apos;pytest&apos;</span>,
<a class="l" name="48" href="#48">48</a>        <span class="s">&apos;GitPython&apos;</span>,
<a class="l" name="49" href="#49">49</a>        <span class="s">&apos;pytest-xdist&apos;</span>,
<a class="hl" name="50" href="#50">50</a>        <span class="s">&apos;mockito&apos;</span>,
<a class="l" name="51" href="#51">51</a>        <span class="s">&apos;pytest-mockito&apos;</span>,
<a class="l" name="52" href="#52">52</a>    ],
<a class="l" name="53" href="#53">53</a>    <a href="/source/s?defs=entry_points&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">entry_points</a>={
<a class="l" name="54" href="#54">54</a>        <span class="s">&apos;console_scripts&apos;</span>: [
<a class="l" name="55" href="#55">55</a>            <span class="s">&apos;opengrok-config-merge=<a href="/source/s?path=opengrok_tools.conf&amp;project=OpenGrok">opengrok_tools.conf</a>ig_merge:main&apos;</span>,
<a class="l" name="56" href="#56">56</a>            <span class="s">&apos;opengrok-deploy=opengrok_tools.deploy:main&apos;</span>,
<a class="l" name="57" href="#57">57</a>            <span class="s">&apos;opengrok-groups=opengrok_tools.groups:main&apos;</span>,
<a class="l" name="58" href="#58">58</a>            <span class="s">&apos;opengrok=opengrok_tools.indexer:main&apos;</span>,
<a class="l" name="59" href="#59">59</a>            <span class="s">&apos;opengrok-indexer=opengrok_tools.indexer:main&apos;</span>,
<a class="hl" name="60" href="#60">60</a>            <span class="s">&apos;opengrok-java=opengrok_tools.java:main&apos;</span>,
<a class="l" name="61" href="#61">61</a>            <span class="s">&apos;opengrok-mirror=opengrok_tools.mirror:main&apos;</span>,
<a class="l" name="62" href="#62">62</a>            <span class="s">&apos;opengrok-projadm=opengrok_tools.projadm:main&apos;</span>,
<a class="l" name="63" href="#63">63</a>            <span class="s">&apos;opengrok-reindex-project=opengrok_tools.reindex_project:main&apos;</span>,
<a class="l" name="64" href="#64">64</a>            <span class="s">&apos;opengrok-sync=opengrok_tools.sync:main&apos;</span>,
<a class="l" name="65" href="#65">65</a>        ]
<a class="l" name="66" href="#66">66</a>    },
<a class="l" name="67" href="#67">67</a>)
<a class="l" name="68" href="#68">68</a>