<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["__version__",17]]],["Function","xf",[["get_version",6]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c"># The package version is taken from maven.</span>
<a class="l" name="2" href="#2">2</a><span class="c"># this &quot;variable&quot; is replaced by maven on the fly so don&apos;t change it here</span>
<a class="l" name="3" href="#3">3</a><span class="c"># see <a href="/source/s?path=pom.xml&amp;project=OpenGrok">pom.xml</a> for this module</span>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a><b>def</b> <a class="xf" name="get_version"/><a href="/source/s?refs=get_version&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">get_version</a>(<a class="xa" name="version"/><a href="/source/s?refs=version&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">version</a>):
<a class="l" name="7" href="#7">7</a>    <span class="s">&quot;&quot;&quot;
<a class="l" name="8" href="#8">8</a>    Detect the mvn build versus the local python <a href="/source/s?path=setup.py&amp;project=OpenGrok">setup.py</a> install run.
<a class="l" name="9" href="#9">9</a>    :param version: the new version string to be applied
<a class="hl" name="10" href="#10">10</a>    :return: the mvn version, or local version number
<a class="l" name="11" href="#11">11</a>    &quot;&quot;&quot;</span>
<a class="l" name="12" href="#12">12</a>    <b>if</b> <span class="s">&apos;<a href="/source/s?path=project.py&amp;project=OpenGrok">project.py</a>thon.package.version&apos;</span> <b>in</b> <a class="d intelliWindow-symbol" href="#version" data-definition-place="defined-in-file">version</a>:
<a class="l" name="13" href="#13">13</a>        <b>return</b> <span class="s">&apos;0.0.1&apos;</span>
<a class="l" name="14" href="#14">14</a>    <b>return</b> <a class="d intelliWindow-symbol" href="#version" data-definition-place="defined-in-file">version</a>
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a><a class="xv" name="__version__"/><a href="/source/s?refs=__version__&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">__version__</a> = <a class="d intelliWindow-symbol" href="#get_version" data-definition-place="defined-in-file">get_version</a>(<span class="s">&apos;${<a href="/source/s?path=project.py&amp;project=OpenGrok">project.py</a>thon.package.version}&apos;</span>)
<a class="l" name="18" href="#18">18</a>