<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["__metaclass__",40]]],["Class","xc",[["Repository",35],["RepositoryException",28]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#</span>
<a class="l" name="2" href="#2">2</a><span class="c"># CDDL HEADER START</span>
<a class="l" name="3" href="#3">3</a><span class="c">#</span>
<a class="l" name="4" href="#4">4</a><span class="c"># The contents of this file are subject to the terms of the</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Common Development and Distribution License (the &quot;License&quot;).</span>
<a class="l" name="6" href="#6">6</a><span class="c"># You may not use this file except in compliance with the License.</span>
<a class="l" name="7" href="#7">7</a><span class="c">#</span>
<a class="l" name="8" href="#8">8</a><span class="c"># See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific</span>
<a class="l" name="9" href="#9">9</a><span class="c"># language governing permissions and limitations under the License.</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#</span>
<a class="l" name="11" href="#11">11</a><span class="c"># When distributing Covered Code, include this CDDL HEADER in each</span>
<a class="l" name="12" href="#12">12</a><span class="c"># file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.</span>
<a class="l" name="13" href="#13">13</a><span class="c"># If applicable, add the following below this CDDL HEADER, with the</span>
<a class="l" name="14" href="#14">14</a><span class="c"># fields enclosed by brackets &quot;[]&quot; replaced with your own identifying</span>
<a class="l" name="15" href="#15">15</a><span class="c"># information: Portions Copyright [yyyy] [name of copyright owner]</span>
<a class="l" name="16" href="#16">16</a><span class="c">#</span>
<a class="l" name="17" href="#17">17</a><span class="c"># CDDL HEADER END</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><span class="c">#</span>
<a class="l" name="21" href="#21">21</a><span class="c"># Copyright (c) 2018, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.</span>
<a class="l" name="22" href="#22">22</a><span class="c">#</span>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=abc&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">abc</a>
<a class="l" name="25" href="#25">25</a><b>from</b> ..<a href="/source/s?defs=utils&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">utils</a>.<a class="d intelliWindow-symbol" href="#command" data-definition-place="defined-in-file">command</a> <b>import</b> <a href="/source/s?defs=Command&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Command</a>
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a><b>class</b> <a class="xc" name="RepositoryException"/><a href="/source/s?refs=RepositoryException&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">RepositoryException</a>(<a href="/source/s?defs=Exception&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Exception</a>):
<a class="l" name="29" href="#29">29</a>    <span class="s">&quot;&quot;&quot;
<a class="hl" name="30" href="#30">30</a>    Exception returned when repository operation failed.
<a class="l" name="31" href="#31">31</a>    &quot;&quot;&quot;</span>
<a class="l" name="32" href="#32">32</a>    <b>pass</b>
<a class="l" name="33" href="#33">33</a>
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a><b>class</b> <a class="xc" name="Repository"/><a href="/source/s?refs=Repository&amp;project=OpenGrok" class="xc intelliWindow-symbol" data-definition-place="def">Repository</a>:
<a class="l" name="36" href="#36">36</a>    <span class="s">&quot;&quot;&quot;
<a class="l" name="37" href="#37">37</a>    abstract class wrapper for Source Code Management repository
<a class="l" name="38" href="#38">38</a>    &quot;&quot;&quot;</span>
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>    <a class="xv" name="__metaclass__"/><a href="/source/s?refs=__metaclass__&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">__metaclass__</a> = <a href="/source/s?defs=abc&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">abc</a>.<a href="/source/s?defs=ABCMeta&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ABCMeta</a>
<a class="l" name="41" href="#41">41</a>
<a class="l" name="42" href="#42">42</a>    <b>def</b> <a class="xmb" name="__init__"/><a href="/source/s?refs=__init__&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">__init__</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>, <a class="xa" name="logger"/><a href="/source/s?refs=logger&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">logger</a>, <a class="xa" name="path"/><a href="/source/s?refs=path&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">path</a>, <a class="xa" name="project"/><a href="/source/s?refs=project&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">project</a>, <a class="xa" name="command"/><a href="/source/s?refs=command&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">command</a>, <a class="xa" name="env"/><a href="/source/s?refs=env&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">env</a>, <a class="xa" name="hooks"/><a href="/source/s?refs=hooks&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">hooks</a>,
<a class="l" name="43" href="#43">43</a>                 <a class="xa" name="timeout"/><a href="/source/s?refs=timeout&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">timeout</a>):
<a class="l" name="44" href="#44">44</a>        <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a> = <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>
<a class="l" name="45" href="#45">45</a>        <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#path" data-definition-place="defined-in-file">path</a> = <a class="d intelliWindow-symbol" href="#path" data-definition-place="defined-in-file">path</a>
<a class="l" name="46" href="#46">46</a>        <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#project" data-definition-place="defined-in-file">project</a> = <a class="d intelliWindow-symbol" href="#project" data-definition-place="defined-in-file">project</a>
<a class="l" name="47" href="#47">47</a>        <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#timeout" data-definition-place="defined-in-file">timeout</a> = <a class="d intelliWindow-symbol" href="#timeout" data-definition-place="defined-in-file">timeout</a>
<a class="l" name="48" href="#48">48</a>        <b>if</b> <a class="d intelliWindow-symbol" href="#env" data-definition-place="defined-in-file">env</a>:
<a class="l" name="49" href="#49">49</a>            <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#env" data-definition-place="defined-in-file">env</a> = <a class="d intelliWindow-symbol" href="#env" data-definition-place="defined-in-file">env</a>
<a class="hl" name="50" href="#50">50</a>        <b>else</b>:
<a class="l" name="51" href="#51">51</a>            <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#env" data-definition-place="defined-in-file">env</a> = {}
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>    <b>def</b> <a class="xmb" name="__str__"/><a href="/source/s?refs=__str__&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">__str__</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>):
<a class="l" name="54" href="#54">54</a>        <b>return</b> <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#path" data-definition-place="defined-in-file">path</a>
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>    <b>def</b> <a class="xmb" name="getCommand"/><a href="/source/s?refs=getCommand&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">getCommand</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>, <a class="xa" name="cmd"/><a href="/source/s?refs=cmd&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">cmd</a>, **<a class="xa" name="kwargs"/><a href="/source/s?refs=kwargs&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">kwargs</a>):
<a class="l" name="57" href="#57">57</a>        <a class="d intelliWindow-symbol" href="#kwargs" data-definition-place="defined-in-file">kwargs</a>[<span class="s">&apos;timeout&apos;</span>] = <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#timeout" data-definition-place="defined-in-file">timeout</a>
<a class="l" name="58" href="#58">58</a>        <b>return</b> <a href="/source/s?defs=Command&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Command</a>(<a class="d intelliWindow-symbol" href="#cmd" data-definition-place="defined-in-file">cmd</a>, **<a class="d intelliWindow-symbol" href="#kwargs" data-definition-place="defined-in-file">kwargs</a>)
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>    <b>def</b> <a class="xmb" name="sync"/><a href="/source/s?refs=sync&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">sync</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>):
<a class="l" name="61" href="#61">61</a>        <span class="c"># Eventually, there might be per-repository hooks added here.</span>
<a class="l" name="62" href="#62">62</a>        <b>return</b> <a href="/source/s?defs=self&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">self</a>.<a class="d intelliWindow-symbol" href="#reposync" data-definition-place="defined-in-file">reposync</a>()
<a class="l" name="63" href="#63">63</a>
<a class="l" name="64" href="#64">64</a>    @<a href="/source/s?defs=abc&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">abc</a>.<a href="/source/s?defs=abstractmethod&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">abstractmethod</a>
<a class="l" name="65" href="#65">65</a>    <b>def</b> <a class="xmb" name="reposync"/><a href="/source/s?refs=reposync&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">reposync</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>):
<a class="l" name="66" href="#66">66</a>        <span class="s">&quot;&quot;&quot;
<a class="l" name="67" href="#67">67</a>        Synchronize the repository by running sync command specific for
<a class="l" name="68" href="#68">68</a>        given repository type.
<a class="l" name="69" href="#69">69</a>
<a class="hl" name="70" href="#70">70</a>        Return 1 on failure, 0 on success.
<a class="l" name="71" href="#71">71</a>        &quot;&quot;&quot;</span>
<a class="l" name="72" href="#72">72</a>        <b>raise</b> <a href="/source/s?defs=NotImplementedError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">NotImplementedError</a>()
<a class="l" name="73" href="#73">73</a>
<a class="l" name="74" href="#74">74</a>    <b>def</b> <a class="xmb" name="incoming"/><a href="/source/s?refs=incoming&amp;project=OpenGrok" class="xmb intelliWindow-symbol" data-definition-place="def">incoming</a>(<a class="xa" name="self"/><a href="/source/s?refs=self&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">self</a>):
<a class="l" name="75" href="#75">75</a>        <span class="s">&quot;&quot;&quot;
<a class="l" name="76" href="#76">76</a>        Check if there are any incoming changes.
<a class="l" name="77" href="#77">77</a>
<a class="l" name="78" href="#78">78</a>        Return True if so, False otherwise.
<a class="l" name="79" href="#79">79</a>        &quot;&quot;&quot;</span>
<a class="hl" name="80" href="#80">80</a>        <b>return</b> <a href="/source/s?defs=True&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">True</a>
<a class="l" name="81" href="#81">81</a>