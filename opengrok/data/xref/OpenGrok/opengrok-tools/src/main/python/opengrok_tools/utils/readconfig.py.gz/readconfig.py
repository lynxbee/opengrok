<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Variable","xv",[["JSONDecodeError",33]]],["Function","xf",[["read_config",36]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#</span>
<a class="l" name="2" href="#2">2</a><span class="c"># CDDL HEADER START</span>
<a class="l" name="3" href="#3">3</a><span class="c">#</span>
<a class="l" name="4" href="#4">4</a><span class="c"># The contents of this file are subject to the terms of the</span>
<a class="l" name="5" href="#5">5</a><span class="c"># Common Development and Distribution License (the &quot;License&quot;).</span>
<a class="l" name="6" href="#6">6</a><span class="c"># You may not use this file except in compliance with the License.</span>
<a class="l" name="7" href="#7">7</a><span class="c">#</span>
<a class="l" name="8" href="#8">8</a><span class="c"># See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific</span>
<a class="l" name="9" href="#9">9</a><span class="c"># language governing permissions and limitations under the License.</span>
<a class="hl" name="10" href="#10">10</a><span class="c">#</span>
<a class="l" name="11" href="#11">11</a><span class="c"># When distributing Covered Code, include this CDDL HEADER in each</span>
<a class="l" name="12" href="#12">12</a><span class="c"># file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.</span>
<a class="l" name="13" href="#13">13</a><span class="c"># If applicable, add the following below this CDDL HEADER, with the</span>
<a class="l" name="14" href="#14">14</a><span class="c"># fields enclosed by brackets &quot;[]&quot; replaced with your own identifying</span>
<a class="l" name="15" href="#15">15</a><span class="c"># information: Portions Copyright [yyyy] [name of copyright owner]</span>
<a class="l" name="16" href="#16">16</a><span class="c">#</span>
<a class="l" name="17" href="#17">17</a><span class="c"># CDDL HEADER END</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a>
<a class="hl" name="20" href="#20">20</a><span class="c">#</span>
<a class="l" name="21" href="#21">21</a><span class="c"># Copyright (c) 2018, 2019, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.</span>
<a class="l" name="22" href="#22">22</a><span class="c">#</span>
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a><b>import</b> <a href="/source/s?defs=logging&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">logging</a>
<a class="l" name="25" href="#25">25</a><b>import</b> <a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=yaml&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yaml</a>
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=sys&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sys</a>
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a><span class="c"># The following is to make the JSON parsing work on Python 3.4.</span>
<a class="hl" name="30" href="#30">30</a><b>try</b>:
<a class="l" name="31" href="#31">31</a>    <b>from</b> <a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>.<a href="/source/s?defs=decoder&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">decoder</a> <b>import</b> <a class="d intelliWindow-symbol" href="#JSONDecodeError" data-definition-place="defined-in-file">JSONDecodeError</a>
<a class="l" name="32" href="#32">32</a><b>except</b> <a href="/source/s?defs=ImportError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ImportError</a>:
<a class="l" name="33" href="#33">33</a>    <a class="xv" name="JSONDecodeError"/><a href="/source/s?refs=JSONDecodeError&amp;project=OpenGrok" class="xv intelliWindow-symbol" data-definition-place="def">JSONDecodeError</a> = <a href="/source/s?defs=ValueError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ValueError</a>
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><b>def</b> <a class="xf" name="read_config"/><a href="/source/s?refs=read_config&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">read_config</a>(<a class="xa" name="logger"/><a href="/source/s?refs=logger&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">logger</a>, <a class="xa" name="inputfile"/><a href="/source/s?refs=inputfile&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">inputfile</a>):
<a class="l" name="37" href="#37">37</a>    <span class="s">&quot;&quot;&quot;
<a class="l" name="38" href="#38">38</a>    Try to interpret inputfile as either JSON or YAML file,
<a class="l" name="39" href="#39">39</a>    parse it and return an object representing its contents.
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>    If neither is valid, return None.
<a class="l" name="42" href="#42">42</a>    &quot;&quot;&quot;</span>
<a class="l" name="43" href="#43">43</a>    <a href="/source/s?defs=logging&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">logging</a>.<a href="/source/s?defs=debug&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">debug</a>(<span class="s">&quot;reading in {}&quot;</span>.<a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>(<a class="d intelliWindow-symbol" href="#inputfile" data-definition-place="defined-in-file">inputfile</a>))
<a class="l" name="44" href="#44">44</a>    <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a> = <b>None</b>
<a class="l" name="45" href="#45">45</a>    <b>try</b>:
<a class="l" name="46" href="#46">46</a>        <b>with</b> <a href="/source/s?defs=open&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">open</a>(<a class="d intelliWindow-symbol" href="#inputfile" data-definition-place="defined-in-file">inputfile</a>) <b>as</b> <a href="/source/s?defs=data_file&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data_file</a>:
<a class="l" name="47" href="#47">47</a>            <a href="/source/s?defs=data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a> = <a href="/source/s?defs=data_file&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data_file</a>.<a href="/source/s?defs=read&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">read</a>()
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>            <b>try</b>:
<a class="hl" name="50" href="#50">50</a>                <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>.<a href="/source/s?defs=debug&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">debug</a>(<span class="s">&quot;trying JSON&quot;</span>)
<a class="l" name="51" href="#51">51</a>                <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a> = <a href="/source/s?defs=json&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">json</a>.<a href="/source/s?defs=loads&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">loads</a>(<a href="/source/s?defs=data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>)
<a class="l" name="52" href="#52">52</a>            <b>except</b> <a class="d intelliWindow-symbol" href="#JSONDecodeError" data-definition-place="defined-in-file">JSONDecodeError</a>:
<a class="l" name="53" href="#53">53</a>                <span class="c"># Not a valid JSON file.</span>
<a class="l" name="54" href="#54">54</a>                <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>.<a href="/source/s?defs=debug&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">debug</a>(<span class="s">&quot;got exception {}&quot;</span>.<a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>(<a href="/source/s?defs=sys&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sys</a>.<a href="/source/s?defs=exc_info&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exc_info</a>()[<span class="n">0</span>]))
<a class="l" name="55" href="#55">55</a>            <b>else</b>:
<a class="l" name="56" href="#56">56</a>                <b>return</b> <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a>
<a class="l" name="57" href="#57">57</a>
<a class="l" name="58" href="#58">58</a>            <b>try</b>:
<a class="l" name="59" href="#59">59</a>                <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>.<a href="/source/s?defs=debug&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">debug</a>(<span class="s">&quot;trying YAML&quot;</span>)
<a class="hl" name="60" href="#60">60</a>                <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a> = <a href="/source/s?defs=yaml&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">yaml</a>.<a href="/source/s?defs=safe_load&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">safe_load</a>(<a href="/source/s?defs=data&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">data</a>)
<a class="l" name="61" href="#61">61</a>            <b>except</b> <a href="/source/s?defs=AttributeError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">AttributeError</a>:
<a class="l" name="62" href="#62">62</a>                <span class="c"># Not a valid YAML file.</span>
<a class="l" name="63" href="#63">63</a>                <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>.<a href="/source/s?defs=debug&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">debug</a>(<span class="s">&quot;got exception {}&quot;</span>.<a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>(<a href="/source/s?defs=sys&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">sys</a>.<a href="/source/s?defs=exc_info&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">exc_info</a>()[<span class="n">0</span>]))
<a class="l" name="64" href="#64">64</a>            <b>else</b>:
<a class="l" name="65" href="#65">65</a>                <b>return</b> <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a>
<a class="l" name="66" href="#66">66</a>    <b>except</b> <a href="/source/s?defs=IOError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOError</a> <b>as</b> <a href="/source/s?defs=e&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">e</a>:
<a class="l" name="67" href="#67">67</a>        <a class="d intelliWindow-symbol" href="#logger" data-definition-place="defined-in-file">logger</a>.<a href="/source/s?defs=error&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">error</a>(<span class="s">&quot;cannot open &apos;{}&apos;: {}&quot;</span>.<a href="/source/s?defs=format&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">format</a>(<a class="d intelliWindow-symbol" href="#inputfile" data-definition-place="defined-in-file">inputfile</a>, <a href="/source/s?defs=e&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">e</a>.<a href="/source/s?defs=strerror&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">strerror</a>))
<a class="l" name="68" href="#68">68</a>
<a class="l" name="69" href="#69">69</a>    <b>return</b> <a href="/source/s?defs=cfg&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">cfg</a>
<a class="hl" name="70" href="#70">70</a>