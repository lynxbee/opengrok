<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Function","xf",[["test_str2bool",46],["test_str2bool_bool",41],["test_str2bool_exception",31],["test_str2bool_exception_empty_str",36]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class="c">#!/<a href="/source/s?path=/usr/&amp;project=OpenGrok">usr</a>/<a href="/source/s?path=/usr/bin/&amp;project=OpenGrok">bin</a>/<a href="/source/s?path=/usr/bin/env&amp;project=OpenGrok">env</a> python3</span>
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a><span class="c">#</span>
<a class="l" name="4" href="#4">4</a><span class="c"># CDDL HEADER START</span>
<a class="l" name="5" href="#5">5</a><span class="c">#</span>
<a class="l" name="6" href="#6">6</a><span class="c"># The contents of this file are subject to the terms of the</span>
<a class="l" name="7" href="#7">7</a><span class="c"># Common Development and Distribution License (the &quot;License&quot;).</span>
<a class="l" name="8" href="#8">8</a><span class="c"># You may not use this file except in compliance with the License.</span>
<a class="l" name="9" href="#9">9</a><span class="c">#</span>
<a class="hl" name="10" href="#10">10</a><span class="c"># See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific</span>
<a class="l" name="11" href="#11">11</a><span class="c"># language governing permissions and limitations under the License.</span>
<a class="l" name="12" href="#12">12</a><span class="c">#</span>
<a class="l" name="13" href="#13">13</a><span class="c"># When distributing Covered Code, include this CDDL HEADER in each</span>
<a class="l" name="14" href="#14">14</a><span class="c"># file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.</span>
<a class="l" name="15" href="#15">15</a><span class="c"># If applicable, add the following below this CDDL HEADER, with the</span>
<a class="l" name="16" href="#16">16</a><span class="c"># fields enclosed by brackets &quot;[]&quot; replaced with your own identifying</span>
<a class="l" name="17" href="#17">17</a><span class="c"># information: Portions Copyright [yyyy] [name of copyright owner]</span>
<a class="l" name="18" href="#18">18</a><span class="c">#</span>
<a class="l" name="19" href="#19">19</a><span class="c"># CDDL HEADER END</span>
<a class="hl" name="20" href="#20">20</a><span class="c">#</span>
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a><span class="c">#</span>
<a class="l" name="23" href="#23">23</a><span class="c"># Copyright (c) 2019, Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.</span>
<a class="l" name="24" href="#24">24</a><span class="c">#</span>
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a><b>import</b> <a href="/source/s?defs=argparse&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argparse</a>
<a class="l" name="27" href="#27">27</a><b>import</b> <a href="/source/s?defs=pytest&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pytest</a>
<a class="l" name="28" href="#28">28</a><b>from</b> <a href="/source/s?defs=opengrok_tools&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok_tools</a>.<a href="/source/s?defs=utils&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">utils</a>.<a href="/source/s?defs=parsers&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">parsers</a> <b>import</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a><b>def</b> <a class="xf" name="test_str2bool_exception"/><a href="/source/s?refs=test_str2bool_exception&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">test_str2bool_exception</a>():
<a class="l" name="32" href="#32">32</a>    <b>with</b> <a href="/source/s?defs=pytest&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pytest</a>.<a href="/source/s?defs=raises&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raises</a>(<a href="/source/s?defs=argparse&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argparse</a>.<a href="/source/s?defs=ArgumentTypeError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ArgumentTypeError</a>):
<a class="l" name="33" href="#33">33</a>        <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<span class="s">&apos;foo&apos;</span>)
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a><b>def</b> <a class="xf" name="test_str2bool_exception_empty_str"/><a href="/source/s?refs=test_str2bool_exception_empty_str&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">test_str2bool_exception_empty_str</a>():
<a class="l" name="37" href="#37">37</a>    <b>with</b> <a href="/source/s?defs=pytest&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">pytest</a>.<a href="/source/s?defs=raises&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">raises</a>(<a href="/source/s?defs=argparse&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">argparse</a>.<a href="/source/s?defs=ArgumentTypeError&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">ArgumentTypeError</a>):
<a class="l" name="38" href="#38">38</a>        <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<span class="s">&apos;&apos;</span>)
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a><b>def</b> <a class="xf" name="test_str2bool_bool"/><a href="/source/s?refs=test_str2bool_bool&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">test_str2bool_bool</a>():
<a class="l" name="42" href="#42">42</a>    <b>assert</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=True&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">True</a>)
<a class="l" name="43" href="#43">43</a>    <b>assert</b> <b>not</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=False&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">False</a>)
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a><b>def</b> <a class="xf" name="test_str2bool"/><a href="/source/s?refs=test_str2bool&amp;project=OpenGrok" class="xf intelliWindow-symbol" data-definition-place="def">test_str2bool</a>():
<a class="l" name="47" href="#47">47</a>    <b>for</b> <a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a> <b>in</b> [<span class="s">&apos;true&apos;</span>, <span class="s">&apos;y&apos;</span>, <span class="s">&apos;yes&apos;</span>]:
<a class="l" name="48" href="#48">48</a>        <b>assert</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a>)
<a class="l" name="49" href="#49">49</a>        <b>assert</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a>.<a href="/source/s?defs=upper&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">upper</a>())
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>    <b>for</b> <a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a> <b>in</b> [<span class="s">&apos;false&apos;</span>, <span class="s">&apos;n&apos;</span>, <span class="s">&apos;no&apos;</span>]:
<a class="l" name="52" href="#52">52</a>        <b>assert</b> <b>not</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a>)
<a class="l" name="53" href="#53">53</a>        <b>assert</b> <b>not</b> <a href="/source/s?defs=str2bool&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">str2bool</a>(<a href="/source/s?defs=val&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">val</a>.<a href="/source/s?defs=upper&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">upper</a>())
<a class="l" name="54" href="#54">54</a>