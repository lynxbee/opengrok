<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>
<a class="l" name="2" href="#2">2</a>This directory contains set of scripts to facilitate project synchronization and
<a class="l" name="3" href="#3">3</a>mirroring in a Python package.
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>The scripts require Python 3 and they rely on a <a href="/source/s?path=binary/symlink&amp;project=OpenGrok">binary/symlink</a> python3 to be
<a class="l" name="6" href="#6">6</a>present that points to the latest Python <a href="/source/s?path=3.x&amp;project=OpenGrok">3.x</a> version present on the system.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>All the scripts in the package are installed with the &apos;opengrok-&apos; prefix.
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>See <a href="https://github.com/oracle/opengrok/wiki/Repository-synchronization">https://github.com/oracle/opengrok/wiki/Repository-synchronization</a> for more
<a class="l" name="11" href="#11">11</a>details.
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>The instructions below are pretty much standard way how to deal with Python
<a class="l" name="14" href="#14">14</a>packages however may come handy if you never encountered Python package before.
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>Install
<a class="l" name="17" href="#17">17</a>-------
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>* Installation on the target system so that the package is globally available:
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>Use the distribution tarball and run pip:
<a class="l" name="22" href="#22">22</a>
<a class="l" name="23" href="#23">23</a>  python3 -m pip install <a href="/source/s?path=opengrok_tools.tar.gz&amp;project=OpenGrok">opengrok_tools.tar.gz</a>
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>This will download all dependencies and install the package to your local
<a class="l" name="26" href="#26">26</a>python3 modules.
<a class="l" name="27" href="#27">27</a>
<a class="l" name="28" href="#28">28</a>* Installing to a specified directory:
<a class="l" name="29" href="#29">29</a>
<a class="hl" name="30" href="#30">30</a>You can also install the tools to a specified directory, we suggest you to use
<a class="l" name="31" href="#31">31</a>the python virtual environment for it:
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>  cd <a href="/source/s?path=/opt/opengrok&amp;project=OpenGrok">/opt/opengrok</a>
<a class="l" name="34" href="#34">34</a>  python3 -m venv opengrok-tools
<a class="l" name="35" href="#35">35</a>  <a href="/source/s?path=opengrok-tools/bin/python&amp;project=OpenGrok">opengrok-tools/bin/python</a> -m pip install <a href="/source/s?path=opengrok_tools.tar.gz&amp;project=OpenGrok">opengrok_tools.tar.gz</a>
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>This will install the package and all the dependencies under the
<a class="l" name="38" href="#38">38</a><a href="/source/s?path=/opt/opengrok/opengrok-tools&amp;project=OpenGrok">/opt/opengrok/opengrok-tools</a> directory. You can then call the scripts with
<a class="l" name="39" href="#39">39</a>
<a class="hl" name="40" href="#40">40</a><a href="/source/s?path=/opt/opengrok/opengrok-tools/bin/opengrok-indexer&amp;project=OpenGrok">/opt/opengrok/opengrok-tools/bin/opengrok-indexer</a>
<a class="l" name="41" href="#41">41</a><a href="/source/s?path=/opt/opengrok/opengrok-tools/bin/opengrok-groups&amp;project=OpenGrok">/opt/opengrok/opengrok-tools/bin/opengrok-groups</a>
<a class="l" name="42" href="#42">42</a>...
<a class="l" name="43" href="#43">43</a>
<a class="l" name="44" href="#44">44</a>Uninstall
<a class="l" name="45" href="#45">45</a>---------
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>* from system level package or from venv:
<a class="l" name="48" href="#48">48</a>  (assuming the venv is activated or you are running python3 from the venv
<a class="l" name="49" href="#49">49</a>  binary directory)
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>  python3 -m pip uninstall opengrok_tools
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>