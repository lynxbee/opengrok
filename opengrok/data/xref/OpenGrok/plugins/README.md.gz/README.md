<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Authorization plugins
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>This directory contains various authorization plugins:
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>  - FalsePlugin - denies everything
<a class="l" name="6" href="#6">6</a>  - TruePlugin - allows everything
<a class="l" name="7" href="#7">7</a>  - HttpBasicAuthorizationPlugin - sample plugin to utilize HTTP Basic auth
<a class="l" name="8" href="#8">8</a>  - LdapPlugin - set of plugins to perform authorization based on LDAP
<a class="l" name="9" href="#9">9</a>  - UserPlugin - extract user information from HTTP headers
<a class="hl" name="10" href="#10">10</a>    - this plugin can have multiple header decoders, the default is for Oracle SSO
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>## Debugging
<a class="l" name="13" href="#13">13</a>
<a class="l" name="14" href="#14">14</a>In general, it should be possible to increase log level in Tomcat&apos;s
<a class="l" name="15" href="#15">15</a>`<a href="/source/s?path=logging.properties&amp;project=OpenGrok">logging.properties</a>` file to get more verbose logging.
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>### UserPlugin
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>Has a special property called &quot;fake&quot; that allows to insert custom headers
<a class="hl" name="20" href="#20">20</a>with the &quot;fake-&quot; prefix that would be evaluated instead of the usual SSO headers.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>Header insertion can be done <a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> using the Modify headers Firefox plugin.
<a class="l" name="23" href="#23">23</a>
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>```xml
<a class="l" name="26" href="#26">26</a>        &lt;!-- get user cred from HTTP headers --&gt;
<a class="l" name="27" href="#27">27</a>        &lt;void method=&quot;add&quot;&gt;
<a class="l" name="28" href="#28">28</a>            &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationPlugin&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationPlugin</a>&quot;&gt;
<a class="l" name="29" href="#29">29</a>                &lt;void property=&quot;name&quot;&gt;
<a class="hl" name="30" href="#30">30</a>                    &lt;string&gt;<a href="/source/s?path=opengrok.auth.plugin.UserPlugin&amp;project=OpenGrok">opengrok.auth.plugin.UserPlugin</a>&lt;/string&gt;
<a class="l" name="31" href="#31">31</a>                &lt;/void&gt;
<a class="l" name="32" href="#32">32</a>                &lt;void property=&quot;flag&quot;&gt;
<a class="l" name="33" href="#33">33</a>                    &lt;string&gt;REQUISITE&lt;/string&gt;
<a class="l" name="34" href="#34">34</a>                &lt;/void&gt;
<a class="l" name="35" href="#35">35</a>
<a class="l" name="36" href="#36">36</a>                &lt;!-- set fake parameter to true to allow insertion of custom headers --&gt;
<a class="l" name="37" href="#37">37</a>                &lt;void property=&quot;setup&quot;&gt;
<a class="l" name="38" href="#38">38</a>                        &lt;void method=&quot;put&quot;&gt;
<a class="l" name="39" href="#39">39</a>                                &lt;string&gt;fake&lt;/string&gt;
<a class="hl" name="40" href="#40">40</a>                                &lt;boolean&gt;true&lt;/boolean&gt;
<a class="l" name="41" href="#41">41</a>                        &lt;/void&gt;
<a class="l" name="42" href="#42">42</a>                &lt;/void&gt;
<a class="l" name="43" href="#43">43</a>            &lt;/object&gt;
<a class="l" name="44" href="#44">44</a>        &lt;/void&gt;
<a class="l" name="45" href="#45">45</a>
<a class="l" name="46" href="#46">46</a>```
<a class="l" name="47" href="#47">47</a>
<a class="l" name="48" href="#48">48</a>## Example configuration
<a class="l" name="49" href="#49">49</a>
<a class="hl" name="50" href="#50">50</a>The following snippet configures global authorization stack with 2 REQUISITE
<a class="l" name="51" href="#51">51</a>plugins and a sub-stack with 1 SUFFICIENT and 1 REQUIRED plugin.
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>There is a config file `<a href="/source/s?path=ldap-plugin-config.xml&amp;project=OpenGrok">ldap-plugin-config.xml</a>` specified globally that will be
<a class="l" name="54" href="#54">54</a>used by LdapPlugin. See LdapPlugin directory for sample of this config file.
<a class="l" name="55" href="#55">55</a>
<a class="l" name="56" href="#56">56</a>This snippet can be put info read-only configuration that is passed to the
<a class="l" name="57" href="#57">57</a>indexer via the -R option.
<a class="l" name="58" href="#58">58</a>
<a class="l" name="59" href="#59">59</a>
<a class="hl" name="60" href="#60">60</a>```xml
<a class="l" name="61" href="#61">61</a>   &lt;!-- Authorization config begin --&gt;
<a class="l" name="62" href="#62">62</a>
<a class="l" name="63" href="#63">63</a>   &lt;void property=&quot;pluginStack&quot;&gt;
<a class="l" name="64" href="#64">64</a>        &lt;!-- The setup will be inherited to all sub-stacks --&gt;
<a class="l" name="65" href="#65">65</a>        &lt;void property=&quot;setup&quot;&gt;
<a class="l" name="66" href="#66">66</a>            &lt;void method=&quot;put&quot;&gt;
<a class="l" name="67" href="#67">67</a>                &lt;string&gt;configuration&lt;/string&gt;
<a class="l" name="68" href="#68">68</a>                &lt;string&gt;<a href="/source/s?path=/opengrok/auth/config/ldap-plugin-config.xml&amp;project=OpenGrok">/opengrok/auth/config/ldap-plugin-config.xml</a>&lt;/string&gt;
<a class="l" name="69" href="#69">69</a>            &lt;/void&gt;
<a class="hl" name="70" href="#70">70</a>        &lt;/void&gt;
<a class="l" name="71" href="#71">71</a>
<a class="l" name="72" href="#72">72</a>        &lt;void property=&quot;stack&quot;&gt;
<a class="l" name="73" href="#73">73</a>            &lt;!-- get user cred from HTTP headers --&gt;
<a class="l" name="74" href="#74">74</a>            &lt;void method=&quot;add&quot;&gt;
<a class="l" name="75" href="#75">75</a>                &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationPlugin&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationPlugin</a>&quot;&gt;
<a class="l" name="76" href="#76">76</a>                    &lt;void property=&quot;name&quot;&gt;
<a class="l" name="77" href="#77">77</a>                        &lt;string&gt;<a href="/source/s?path=opengrok.auth.plugin.UserPlugin&amp;project=OpenGrok">opengrok.auth.plugin.UserPlugin</a>&lt;/string&gt;
<a class="l" name="78" href="#78">78</a>                    &lt;/void&gt;
<a class="l" name="79" href="#79">79</a>                    &lt;void property=&quot;flag&quot;&gt;
<a class="hl" name="80" href="#80">80</a>                        &lt;string&gt;REQUISITE&lt;/string&gt;
<a class="l" name="81" href="#81">81</a>                    &lt;/void&gt;
<a class="l" name="82" href="#82">82</a>                &lt;/object&gt;
<a class="l" name="83" href="#83">83</a>            &lt;/void&gt;
<a class="l" name="84" href="#84">84</a>
<a class="l" name="85" href="#85">85</a>            &lt;!-- get email, ou and uid --&gt;
<a class="l" name="86" href="#86">86</a>            &lt;void method=&quot;add&quot;&gt;
<a class="l" name="87" href="#87">87</a>                &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationPlugin&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationPlugin</a>&quot;&gt;
<a class="l" name="88" href="#88">88</a>                    &lt;void property=&quot;name&quot;&gt;
<a class="l" name="89" href="#89">89</a>                        &lt;string&gt;<a href="/source/s?path=opengrok.auth.plugin.LdapUserPlugin&amp;project=OpenGrok">opengrok.auth.plugin.LdapUserPlugin</a>&lt;/string&gt;
<a class="hl" name="90" href="#90">90</a>                    &lt;/void&gt;
<a class="l" name="91" href="#91">91</a>                    &lt;void property=&quot;flag&quot;&gt;
<a class="l" name="92" href="#92">92</a>                        &lt;string&gt;REQUISITE&lt;/string&gt;
<a class="l" name="93" href="#93">93</a>                    &lt;/void&gt;
<a class="l" name="94" href="#94">94</a>                &lt;/object&gt;
<a class="l" name="95" href="#95">95</a>    	        &lt;void property=&quot;setup&quot;&gt;
<a class="l" name="96" href="#96">96</a>                    &lt;void method=&quot;put&quot;&gt;
<a class="l" name="97" href="#97">97</a>                        &lt;string&gt;objectclass&lt;/string&gt;
<a class="l" name="98" href="#98">98</a>                        &lt;string&gt;posixAccount&lt;/string&gt;
<a class="l" name="99" href="#99">99</a>                    &lt;/void&gt;
<a class="hl" name="100" href="#100">100</a>                &lt;/void&gt;
<a class="l" name="101" href="#101">101</a>            &lt;/void&gt;
<a class="l" name="102" href="#102">102</a>
<a class="l" name="103" href="#103">103</a>            &lt;!-- Authorization stacks follow --&gt;
<a class="l" name="104" href="#104">104</a>
<a class="l" name="105" href="#105">105</a>            &lt;void method=&quot;add&quot;&gt;
<a class="l" name="106" href="#106">106</a>                &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationStack&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationStack</a>&quot;&gt;
<a class="l" name="107" href="#107">107</a>                    &lt;void property=&quot;forProjects&quot;&gt;
<a class="l" name="108" href="#108">108</a>                        &lt;void method=&quot;add&quot;&gt;
<a class="l" name="109" href="#109">109</a>                            &lt;string&gt;foo&lt;/string&gt;
<a class="hl" name="110" href="#110">110</a>                        &lt;/void&gt;
<a class="l" name="111" href="#111">111</a>                    &lt;/void&gt;
<a class="l" name="112" href="#112">112</a>                    &lt;void property=&quot;forGroups&quot;&gt;
<a class="l" name="113" href="#113">113</a>                        &lt;void method=&quot;add&quot;&gt;
<a class="l" name="114" href="#114">114</a>                            &lt;string&gt;mygroup&lt;/string&gt;
<a class="l" name="115" href="#115">115</a>                        &lt;/void&gt;
<a class="l" name="116" href="#116">116</a>                    &lt;/void&gt;
<a class="l" name="117" href="#117">117</a>                    &lt;void property=&quot;name&quot;&gt;
<a class="l" name="118" href="#118">118</a>                        &lt;string&gt;substack for some source code&lt;/string&gt;
<a class="l" name="119" href="#119">119</a>                    &lt;/void&gt;
<a class="hl" name="120" href="#120">120</a>                    &lt;void property=&quot;flag&quot;&gt;
<a class="l" name="121" href="#121">121</a>                        &lt;string&gt;REQUIRED&lt;/string&gt;
<a class="l" name="122" href="#122">122</a>                    &lt;/void&gt;
<a class="l" name="123" href="#123">123</a>                    &lt;void property=&quot;stack&quot;&gt;
<a class="l" name="124" href="#124">124</a>                        &lt;void method=&quot;add&quot;&gt;
<a class="l" name="125" href="#125">125</a>                            &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationPlugin&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationPlugin</a>&quot;&gt;
<a class="l" name="126" href="#126">126</a>                                &lt;void property=&quot;name&quot;&gt;
<a class="l" name="127" href="#127">127</a>                                    &lt;string&gt;<a href="/source/s?path=opengrok.auth.plugin.LdapAttrPlugin&amp;project=OpenGrok">opengrok.auth.plugin.LdapAttrPlugin</a>&lt;/string&gt;
<a class="l" name="128" href="#128">128</a>                                &lt;/void&gt;
<a class="l" name="129" href="#129">129</a>                                &lt;void property=&quot;flag&quot;&gt;
<a class="hl" name="130" href="#130">130</a>                                    &lt;string&gt;SUFFICIENT&lt;/string&gt;
<a class="l" name="131" href="#131">131</a>                                &lt;/void&gt;
<a class="l" name="132" href="#132">132</a>                                &lt;void property=&quot;setup&quot;&gt;
<a class="l" name="133" href="#133">133</a>                                    &lt;void method=&quot;put&quot;&gt;
<a class="l" name="134" href="#134">134</a>                                        &lt;string&gt;attribute&lt;/string&gt;
<a class="l" name="135" href="#135">135</a>                                        &lt;string&gt;mail&lt;/string&gt;
<a class="l" name="136" href="#136">136</a>                                    &lt;/void&gt;
<a class="l" name="137" href="#137">137</a>                                    &lt;void method=&quot;put&quot;&gt;
<a class="l" name="138" href="#138">138</a>                                        &lt;string&gt;file&lt;/string&gt;
<a class="l" name="139" href="#139">139</a>                                        &lt;string&gt;<a href="/source/s?path=/opengrok/auth/config/whitelists/mycode-whitelist-mail.txt&amp;project=OpenGrok">/opengrok/auth/config/whitelists/mycode-whitelist-mail.txt</a>&lt;/string&gt;
<a class="hl" name="140" href="#140">140</a>                                    &lt;/void&gt;
<a class="l" name="141" href="#141">141</a>                                &lt;/void&gt;
<a class="l" name="142" href="#142">142</a>                            &lt;/object&gt;
<a class="l" name="143" href="#143">143</a>                        &lt;/void&gt;
<a class="l" name="144" href="#144">144</a>                        &lt;void method=&quot;add&quot;&gt;
<a class="l" name="145" href="#145">145</a>                            &lt;object class=&quot;<a href="/source/s?path=org.opengrok.indexer.authorization.AuthorizationPlugin&amp;project=OpenGrok">org.opengrok.indexer.authorization.AuthorizationPlugin</a>&quot;&gt;
<a class="l" name="146" href="#146">146</a>                                &lt;void property=&quot;name&quot;&gt;
<a class="l" name="147" href="#147">147</a>                                    &lt;string&gt;<a href="/source/s?path=opengrok.auth.plugin.LdapFilterPlugin&amp;project=OpenGrok">opengrok.auth.plugin.LdapFilterPlugin</a>&lt;/string&gt;
<a class="l" name="148" href="#148">148</a>                                &lt;/void&gt;
<a class="l" name="149" href="#149">149</a>                                &lt;void property=&quot;flag&quot;&gt;
<a class="hl" name="150" href="#150">150</a>                                    &lt;string&gt;REQUIRED&lt;/string&gt;
<a class="l" name="151" href="#151">151</a>                                &lt;/void&gt;
<a class="l" name="152" href="#152">152</a>                                &lt;void property=&quot;setup&quot;&gt;
<a class="l" name="153" href="#153">153</a>                                    &lt;void method=&quot;put&quot;&gt;
<a class="l" name="154" href="#154">154</a>                                        &lt;string&gt;filter&lt;/string&gt;
<a class="l" name="155" href="#155">155</a>                                        &lt;string&gt;(&amp;amp;(objectclass=posixGroup)(cn=my_src*)(memberUid=%uid%))&lt;/string&gt;
<a class="l" name="156" href="#156">156</a>                                    &lt;/void&gt;
<a class="l" name="157" href="#157">157</a>                                &lt;/void&gt;
<a class="l" name="158" href="#158">158</a>                            &lt;/object&gt;
<a class="l" name="159" href="#159">159</a>                        &lt;/void&gt;
<a class="hl" name="160" href="#160">160</a>                    &lt;/void&gt;
<a class="l" name="161" href="#161">161</a>                &lt;/object&gt;
<a class="l" name="162" href="#162">162</a>            &lt;/void&gt;
<a class="l" name="163" href="#163">163</a>        &lt;/void&gt;
<a class="l" name="164" href="#164">164</a>
<a class="l" name="165" href="#165">165</a>   &lt;!-- Authorization config end --&gt;
<a class="l" name="166" href="#166">166</a>   &lt;/object&gt;
<a class="l" name="167" href="#167">167</a>```
<a class="l" name="168" href="#168">168</a>
<a class="l" name="169" href="#169">169</a>