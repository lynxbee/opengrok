<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>---
<a class="l" name="2" href="#2">2</a>name: Bug report
<a class="l" name="3" href="#3">3</a>about: Create a report to help us improve
<a class="l" name="4" href="#4">4</a>title: &apos;&apos;
<a class="l" name="5" href="#5">5</a>labels: &apos;&apos;
<a class="l" name="6" href="#6">6</a>assignees: &apos;&apos;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>---
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>**Describe the bug**
<a class="l" name="11" href="#11">11</a>A clear and concise description of what the bug is. Make sure you have done a search of the existing issues to prevent creating duplicates.
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>If you provide the exact version of OpenGrok, JDK used, OS(and its version) used and Tomcat(or your webapp server) used it can help figuring out an environment issue.
<a class="l" name="14" href="#14">14</a>For performance problem OS and JDK tunables might be needed. For SCM problems also version of SCM is helpfull (<a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> some mercurial versions have issues, some not).
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>**To Reproduce**
<a class="l" name="17" href="#17">17</a>Steps to reproduce the behavior:
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>**Expected behavior**
<a class="hl" name="20" href="#20">20</a>A clear and concise description of what you expected to happen.
<a class="l" name="21" href="#21">21</a>
<a class="l" name="22" href="#22">22</a>**Screenshots**
<a class="l" name="23" href="#23">23</a>If applicable, add screenshots to help explain your problem.
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>**Additional context**
<a class="l" name="26" href="#26">26</a>Add any other context about the problem here.
<a class="l" name="27" href="#27">27</a>