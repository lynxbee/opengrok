<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>---
<a class="l" name="2" href="#2">2</a>name: Feature request
<a class="l" name="3" href="#3">3</a>about: Suggest an idea for this project
<a class="l" name="4" href="#4">4</a>title: &apos;&apos;
<a class="l" name="5" href="#5">5</a>labels: enhancement
<a class="l" name="6" href="#6">6</a>assignees: &apos;&apos;
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>---
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>**Is your feature request related to a problem? Please describe.**
<a class="l" name="11" href="#11">11</a>A clear and concise description of what the problem is. Ex. I&apos;m always frustrated when [...]
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>**Describe the solution you&apos;d like**
<a class="l" name="14" href="#14">14</a>A clear and concise description of what you want to happen.
<a class="l" name="15" href="#15">15</a>
<a class="l" name="16" href="#16">16</a>**Describe alternatives you&apos;ve considered**
<a class="l" name="17" href="#17">17</a>A clear and concise description of any alternative solutions or features you&apos;ve considered.
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>**Additional context**
<a class="hl" name="20" href="#20">20</a>Add any other context or screenshots about the feature request here.
<a class="l" name="21" href="#21">21</a>