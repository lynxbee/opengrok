<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a># Contributor Covenant Code of Conduct
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>## Our Pledge
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>In the interest of fostering an open and welcoming environment, we as contributors and maintainers pledge to making participation in our project and our community a harassment-free experience for everyone, regardless of any personal property.
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>## Our Standards
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>Examples of behavior that contributes to creating a positive environment include:
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>* Using welcoming and inclusive language
<a class="l" name="12" href="#12">12</a>* Being respectful of differing viewpoints and experiences
<a class="l" name="13" href="#13">13</a>* Gracefully accepting constructive criticism
<a class="l" name="14" href="#14">14</a>* Focusing on what is best for the community
<a class="l" name="15" href="#15">15</a>* Showing empathy towards other community members
<a class="l" name="16" href="#16">16</a>
<a class="l" name="17" href="#17">17</a>Examples of unacceptable behavior by participants include:
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>* The use of sexualized language or imagery and unwelcome sexual attention or advances
<a class="hl" name="20" href="#20">20</a>* Trolling, <a href="/source/s?path=insulting/derogatory&amp;project=OpenGrok">insulting/derogatory</a> comments, and personal or political attacks
<a class="l" name="21" href="#21">21</a>* Public or private harassment
<a class="l" name="22" href="#22">22</a>* Publishing others&apos; private information, such as a physical or electronic address, without explicit permission
<a class="l" name="23" href="#23">23</a>* Other conduct which could reasonably be considered inappropriate in a professional setting
<a class="l" name="24" href="#24">24</a>
<a class="l" name="25" href="#25">25</a>## Our Responsibilities
<a class="l" name="26" href="#26">26</a>
<a class="l" name="27" href="#27">27</a>Project maintainers are responsible for clarifying the standards of acceptable behavior and are expected to take appropriate and fair corrective action in response to any instances of unacceptable behavior.
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>Project maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, or to ban temporarily or permanently any contributor for other behaviors that they deem inappropriate, threatening, offensive, or harmful.
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>## Scope
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>This Code of Conduct applies both within project spaces and in public spaces when an individual is representing the project or its community. Examples of representing a project or community include using an official project e-mail address, posting via an official social media account, or acting as an appointed representative at an online or offline event. Representation of a project may be further defined and clarified by project maintainers.
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>## Enforcement
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by contacting the project team at vlada@devnull.cz, tarzanek@gmail.com. The project team will review and investigate all complaints, and will respond in a way that it deems appropriate to the circumstances. The project team is obligated to maintain confidentiality with regard to the reporter of an incident. Further details of specific enforcement policies may be posted separately.
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>Project maintainers who do not follow or enforce the Code of Conduct in good faith may face temporary or permanent repercussions as determined by other members of the project&apos;s leadership.
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>## Attribution
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>This Code of Conduct is adapted from the [Contributor Covenant][homepage], version 1.4, available at [<a href="http://contributor-covenant.org/version/1/4">http://contributor-covenant.org/version/1/4</a>][version]
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>[homepage]: <a href="http://contributor-covenant.org">http://contributor-covenant.org</a>
<a class="l" name="46" href="#46">46</a>[version]: <a href="http://contributor-covenant.org/version/1/4/">http://contributor-covenant.org/version/1/4/</a>
<a class="l" name="47" href="#47">47</a>