<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Package","xp",[["org.opengrok.suggest.query",23]]],["Interface","xi",[["SuggesterQuery",33]]],["Method","xmt",[["getField",38],["getTermsEnumForSuggestions",46],["length",52]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER START
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * The contents of this file are subject to the terms of the
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Common Development and Distribution License (the &quot;License&quot;).
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * You may not use this file except in compliance with the License.
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span> * See <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a> included in this distribution for the specific
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span> * language governing permissions and limitations under the License.
<a class="hl" name="10" href="#10">10</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span> * When distributing Covered Code, include this CDDL HEADER in each
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span> * file and include the License file at <a href="/source/s?path=LICENSE.txt&amp;project=OpenGrok">LICENSE.txt</a>.
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span> * If applicable, add the following below this CDDL HEADER, with the
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span> * fields enclosed by brackets &quot;[]&quot; replaced with your own identifying
<a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span> * information: Portions Copyright [yyyy] [name of copyright owner]
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span> *
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span> * CDDL HEADER END
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="19" href="#19">19</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="20" href="#20">20</a><span class='fold-space'>&nbsp;</span><span class="c">/*
<a class="l" name="21" href="#21">21</a><span class='fold-space'>&nbsp;</span> * Copyright (c) 2018 Oracle <a href="/source/s?path=and/&amp;project=OpenGrok">and</a>/<a href="/source/s?path=and/or&amp;project=OpenGrok">or</a> its affiliates. All rights reserved.
<a class="l" name="22" href="#22">22</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="23" href="#23">23</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=opengrok&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">opengrok</a>.<a href="/source/s?defs=suggest&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">suggest</a>.<a href="/source/s?defs=query&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">query</a>&#59;
<a class="l" name="24" href="#24">24</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="25" href="#25">25</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=apache&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">apache</a>.<a href="/source/s?defs=lucene&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lucene</a>.<a href="/source/s?defs=index&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a>.<a href="/source/s?defs=Terms&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Terms</a>&#59;
<a class="l" name="26" href="#26">26</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=org&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">org</a>.<a href="/source/s?defs=apache&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">apache</a>.<a href="/source/s?defs=lucene&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">lucene</a>.<a href="/source/s?defs=index&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">index</a>.<a href="/source/s?defs=TermsEnum&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TermsEnum</a>&#59;
<a class="l" name="27" href="#27">27</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="28" href="#28">28</a><span class='fold-space'>&nbsp;</span><b>import</b> <a href="/source/s?defs=java&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">java</a>.<a href="/source/s?defs=io&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">io</a>.<a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
<a class="l" name="29" href="#29">29</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="30" href="#30">30</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="31" href="#31">31</a><span class='fold-space'>&nbsp;</span> * Query that selects the terms that could be used as suggestions.
<a class="l" name="32" href="#32">32</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="33" href="#33">33</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>interface</b> <a class="xi" name="SuggesterQuery"/><a href="/source/s?refs=SuggesterQuery&amp;project=OpenGrok" class="xi intelliWindow-symbol" data-definition-place="def">SuggesterQuery</a> &#123;
<a class="l" name="34" href="#34">34</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="35" href="#35">35</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="36" href="#36">36</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> field for which the query is
<a class="l" name="37" href="#37">37</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_24e2976a' class='scope-head'><span class='scope-signature'>getField()</span><a class="l" name="38" href="#38">38</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_24e2976a_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=String&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a> <a class="xmt" name="getField"/><a href="/source/s?refs=getField&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getField</a>()&#59;
</span><a class="l" name="39" href="#39">39</a><span class='fold-space'>&nbsp;</span>
<a class="hl" name="40" href="#40">40</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="41" href="#41">41</a><span class='fold-space'>&nbsp;</span>     * Returns terms that satisfy this query.
<a class="l" name="42" href="#42">42</a><span class='fold-space'>&nbsp;</span>     * <strong>@param</strong> <em>terms</em> terms from which to filter the ones that satisfy this query
<a class="l" name="43" href="#43">43</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> terms enum of the terms that satisfy this query
<a class="l" name="44" href="#44">44</a><span class='fold-space'>&nbsp;</span>     * <strong>@throws</strong> <em>IOException</em> if an error occurred
<a class="l" name="45" href="#45">45</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_a27da749' class='scope-head'><span class='scope-signature'>getTermsEnumForSuggestions(Terms terms)</span><a class="l" name="46" href="#46">46</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_a27da749_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <a href="/source/s?defs=TermsEnum&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">TermsEnum</a> <a class="xmt" name="getTermsEnumForSuggestions"/><a href="/source/s?refs=getTermsEnumForSuggestions&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">getTermsEnumForSuggestions</a>(<a href="/source/s?defs=Terms&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">Terms</a> <a class="xa" name="terms"/><a href="/source/s?refs=terms&amp;project=OpenGrok" class="xa intelliWindow-symbol" data-definition-place="def">terms</a>) <b>throws</b> <a href="/source/s?defs=IOException&amp;project=OpenGrok" class="intelliWindow-symbol" data-definition-place="undefined-in-file">IOException</a>&#59;
</span><a class="l" name="47" href="#47">47</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="48" href="#48">48</a><span class='fold-space'>&nbsp;</span>    <span class="c">/**
<a class="l" name="49" href="#49">49</a><span class='fold-space'>&nbsp;</span>     * Length of the query. Used for determining whether query is longer than specified in configuration.
<a class="hl" name="50" href="#50">50</a><span class='fold-space'>&nbsp;</span>     * <strong>@return</strong> query length
<a class="l" name="51" href="#51">51</a><span class='fold-space'>&nbsp;</span>     */</span>
<span id='scope_id_fbfd3804' class='scope-head'><span class='scope-signature'>length()</span><a class="l" name="52" href="#52">52</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_fbfd3804_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>int</b> <a class="xmt" name="length"/><a href="/source/s?refs=length&amp;project=OpenGrok" class="xmt intelliWindow-symbol" data-definition-place="def">length</a>()&#59;
</span><a class="l" name="53" href="#53">53</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="54" href="#54">54</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="55" href="#55">55</a><span class='fold-space'>&nbsp;</span>