<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>Any kind of contribution is welcome. If you are not sure whether your idea is in line with
<a class="l" name="2" href="#2">2</a>the general direction of the project, feel free to submit new Issue first and let&apos;s get the discussion started there.
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a>Please follow pre-existing coding style.
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>Asking questions via creating new Issue is fine also.
<a class="l" name="7" href="#7">7</a>
<a class="l" name="8" href="#8">8</a>When submitting a new Issue for what seems is a bug, please note the version you&apos;re running and ideally steps to reproduce.
<a class="l" name="9" href="#9">9</a>
<a class="hl" name="10" href="#10">10</a>Make sure to add a comment line line to the changeset saying which Issue it is is fixing, <a href="/source/s?path=e.g.&amp;project=OpenGrok">e.g.</a> &apos;fixes #XYZ&apos; so that the issue can be automatically closed when the associated pull request is merged.
<a class="l" name="11" href="#11">11</a>
<a class="l" name="12" href="#12">12</a>Each pull request should be accompanied by a comment explaining how the change was tested, unless unit tests are <a href="/source/s?path=provided/updated&amp;project=OpenGrok">provided/updated</a>.
<a class="l" name="13" href="#13">13</a>Please make every effort to make most of your changes covered by tests.
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>For a pull request to be merged, we need the contributor to sign Oracle Contributor Agreement first.
<a class="l" name="16" href="#16">16</a>See <a href="http://www.oracle.com/technetwork/community/oca-486395.html">http://www.oracle.com/technetwork/community/oca-486395.html</a> for details.
<a class="l" name="17" href="#17">17</a>