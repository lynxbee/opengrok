<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>
<a class="l" name="2" href="#2">2</a>Copyright (c) 2006, 2019 Oracle <a href="/source/s?path=and/or&amp;project=OpenGrok">and/or</a> its affiliates. All rights reserved.
<a class="l" name="3" href="#3">3</a>
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a># OpenGrok - a wicked fast source browser
<a class="l" name="6" href="#6">6</a>[![Travis status](<a href="https://travis-ci.org/oracle/opengrok.svg?branch=master)">https://travis-ci.org/oracle/opengrok.svg?branch=master)</a>](<a href="https://travis-ci.org/oracle/opengrok)">https://travis-ci.org/oracle/opengrok)</a>
<a class="l" name="7" href="#7">7</a>[![Coverage status](<a href="https://coveralls.io/repos/oracle/opengrok/badge.svg?branch=master)">https://coveralls.io/repos/oracle/opengrok/badge.svg?branch=master)</a>](<a href="https://coveralls.io/r/oracle/opengrok?branch=master)">https://coveralls.io/r/oracle/opengrok?branch=master)</a>
<a class="l" name="8" href="#8">8</a>[![SonarQube status](<a href="https://sonarcloud.io/api/project_badges/measure?project=org.opengrok%3Aopengrok-top&amp;metric=alert_status)">https://sonarcloud.io/api/project_badges/measure?project=org.opengrok%3Aopengrok-top&amp;metric=alert_status)</a>](<a href="https://sonarcloud.io/dashboard?id=org.opengrok%3Aopengrok-top)">https://sonarcloud.io/dashboard?id=org.opengrok%3Aopengrok-top)</a>
<a class="l" name="9" href="#9">9</a>[![License](<a href="https://img.shields.io/badge/License-CDDL%201.0-blue.svg)">https://img.shields.io/badge/License-CDDL%201.0-blue.svg)</a>](<a href="https://opensource.org/licenses/CDDL-1.0)">https://opensource.org/licenses/CDDL-1.0)</a>
<a class="hl" name="10" href="#10">10</a>
<a class="l" name="11" href="#11">11</a>- [OpenGrok - a wicked fast source browser](#opengrok---a-wicked-fast-source-browser)
<a class="l" name="12" href="#12">12</a>  - [1. Introduction](#1-introduction)
<a class="l" name="13" href="#13">13</a>  - [2. OpenGrok install and setup](#2-opengrok-install-and-setup)
<a class="l" name="14" href="#14">14</a>  - [3. Information for developers](#3-information-for-developers)
<a class="l" name="15" href="#15">15</a>  - [4. Authors](#4-authors)
<a class="l" name="16" href="#16">16</a>  - [5. Contact us](#5-contact-us)
<a class="l" name="17" href="#17">17</a>  - [6. Run as container](#6-run-as-container)
<a class="l" name="18" href="#18">18</a>
<a class="l" name="19" href="#19">19</a>## 1. Introduction
<a class="hl" name="20" href="#20">20</a>
<a class="l" name="21" href="#21">21</a>OpenGrok is a fast and usable source code search and cross reference
<a class="l" name="22" href="#22">22</a>engine, written in Java. It helps you search, cross-reference and navigate
<a class="l" name="23" href="#23">23</a>your source tree. It can understand various program file formats and
<a class="l" name="24" href="#24">24</a>version control histories of many source code management systems.
<a class="l" name="25" href="#25">25</a>
<a class="l" name="26" href="#26">26</a>Official page of the project is on:
<a class="l" name="27" href="#27">27</a>&lt;<a href="http://opengrok.github.com/OpenGrok/">http://opengrok.github.com/OpenGrok/</a>&gt;
<a class="l" name="28" href="#28">28</a>
<a class="l" name="29" href="#29">29</a>## 2. OpenGrok install and setup
<a class="hl" name="30" href="#30">30</a>
<a class="l" name="31" href="#31">31</a>See <a href="https://github.com/oracle/opengrok/wiki/How-to-setup-OpenGrok">https://github.com/oracle/opengrok/wiki/How-to-setup-OpenGrok</a>
<a class="l" name="32" href="#32">32</a>
<a class="l" name="33" href="#33">33</a>## 3. Information for developers
<a class="l" name="34" href="#34">34</a>
<a class="l" name="35" href="#35">35</a>See <a href="https://github.com/oracle/opengrok/wiki/Developer-intro">https://github.com/oracle/opengrok/wiki/Developer-intro</a> and <a href="https://github.com/oracle/opengrok/wiki/Developers">https://github.com/oracle/opengrok/wiki/Developers</a>
<a class="l" name="36" href="#36">36</a>
<a class="l" name="37" href="#37">37</a>## 4. Authors
<a class="l" name="38" href="#38">38</a>
<a class="l" name="39" href="#39">39</a>The project has been originally conceived in Sun Microsystems by Chandan <a href="/source/s?path=B.N.&amp;project=OpenGrok">B.N.</a>
<a class="hl" name="40" href="#40">40</a>
<a class="l" name="41" href="#41">41</a>For full list of contributors see <a href="https://github.com/oracle/opengrok/graphs/contributors">https://github.com/oracle/opengrok/graphs/contributors</a>
<a class="l" name="42" href="#42">42</a>
<a class="l" name="43" href="#43">43</a>## 5. Contact us
<a class="l" name="44" href="#44">44</a>
<a class="l" name="45" href="#45">45</a>Feel free to participate in discussion on the mailing lists:
<a class="l" name="46" href="#46">46</a>
<a class="l" name="47" href="#47">47</a>  `opengrok-users@yahoogroups.com` (user topics)
<a class="l" name="48" href="#48">48</a>
<a class="l" name="49" href="#49">49</a>  `opengrok-dev@yahoogroups.com` (developers&apos; discussion)
<a class="hl" name="50" href="#50">50</a>
<a class="l" name="51" href="#51">51</a>To subscribe, send email to `&lt;mailing_list_name&gt;-subscribe@yahoogroups.com`
<a class="l" name="52" href="#52">52</a>
<a class="l" name="53" href="#53">53</a>There are also Slack channels on <a href="https://opengrok.slack.com/">https://opengrok.slack.com/</a>
<a class="l" name="54" href="#54">54</a>
<a class="l" name="55" href="#55">55</a>## 6. Run as container
<a class="l" name="56" href="#56">56</a>
<a class="l" name="57" href="#57">57</a>You can run OpenGrok as a Docker container as described [here](<a href="/source/s?path=docker/README.md&amp;project=OpenGrok">docker/README.md</a>).
<a class="l" name="58" href="#58">58</a>