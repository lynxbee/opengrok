<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>This is a sample project students can use during Matthew&apos;s Git class.
<a class="l" name="2" href="#2">2</a>
<a class="l" name="3" href="#3">3</a>Here is an addition by me
<a class="l" name="4" href="#4">4</a>
<a class="l" name="5" href="#5">5</a>We can have a bit of fun with this repo, knowing that we can always reset it to a known good state.  We can apply labels, and branch, then add new code and merge it in to the master branch.
<a class="l" name="6" href="#6">6</a>
<a class="l" name="7" href="#7">7</a>As a quick reminder, this came from one of three locations in either SSH, Git, or HTTPS format:
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>* git@github.com:<a href="/source/s?path=matthewmccullough/hellogitworld.git&amp;project=hellogitworld">matthewmccullough/hellogitworld.git</a>
<a class="hl" name="10" href="#10">10</a>* git:/<a href="/source/s?path=/github.com/matthewmccullough/hellogitworld.git&amp;project=hellogitworld">/github.com/matthewmccullough/hellogitworld.git</a>
<a class="l" name="11" href="#11">11</a>* <a href="https://matthewmccullough@github.com/matthewmccullough/hellogitworld.git">https://matthewmccullough@github.com/matthewmccullough/hellogitworld.git</a>
<a class="l" name="12" href="#12">12</a>
<a class="l" name="13" href="#13">13</a>We can, as an example effort, even modify this README and change it as if it were source code for the purposes of the class.
<a class="l" name="14" href="#14">14</a>
<a class="l" name="15" href="#15">15</a>This demo also includes an image with changes on a branch for examination of image diff on GitHub.
<a class="l" name="16" href="#16">16</a>