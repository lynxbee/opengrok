<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>static int subtract(int val1, val2) {
<a class="l" name="2" href="#2">2</a>    val1 - val2
<a class="l" name="3" href="#3">3</a>}