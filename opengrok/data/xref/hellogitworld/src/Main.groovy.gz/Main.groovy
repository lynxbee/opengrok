<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [];} /* ]]> */</script><a class="l" name="1" href="#1">1</a>import static <a href="/source/s?path=Square.square&amp;project=hellogitworld">Square.square</a>
<a class="l" name="2" href="#2">2</a>import static <a href="/source/s?path=Division.divide&amp;project=hellogitworld">Division.divide</a>
<a class="l" name="3" href="#3">3</a>import static <a href="/source/s?path=Subtract.subtract&amp;project=hellogitworld">Subtract.subtract</a>
<a class="l" name="4" href="#4">4</a>import static <a href="/source/s?path=Sum.sum&amp;project=hellogitworld">Sum.sum</a>
<a class="l" name="5" href="#5">5</a>
<a class="l" name="6" href="#6">6</a>def name = &quot;Matthew&quot;
<a class="l" name="7" href="#7">7</a>int programmingPoints = 10
<a class="l" name="8" href="#8">8</a>
<a class="l" name="9" href="#9">9</a>println &quot;Hello ${name}&quot;
<a class="hl" name="10" href="#10">10</a>println &quot;${name} has at least ${programmingPoints} programming points.&quot;
<a class="l" name="11" href="#11">11</a>println &quot;${programmingPoints} squared is ${square(programmingPoints)}&quot;
<a class="l" name="12" href="#12">12</a>println &quot;${programmingPoints} divided by 2 bonus points is ${divide(programmingPoints, 2)}&quot;
<a class="l" name="13" href="#13">13</a>println &quot;${programmingPoints} minus 7 bonus points is ${subtract(programmingPoints, 7)}&quot;
<a class="l" name="14" href="#14">14</a>println &quot;${programmingPoints} plus 3 bonus points is ${sum(programmingPoints, 3)}&quot;