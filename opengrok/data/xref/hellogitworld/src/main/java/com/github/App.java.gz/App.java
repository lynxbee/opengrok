<script type="text/javascript">/* <![CDATA[ */
function get_sym_list(){return [["Class","xc",[["App",8]]],["Package","xp",[["com.github",1]]],["Method","xmt",[["main",10]]]];} /* ]]> */</script><a class="l" name="1" href="#1">1</a><span class='fold-space'>&nbsp;</span><b>package</b> <a href="/source/s?defs=com&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">com</a>.<a href="/source/s?defs=github&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">github</a>&#59;
<a class="l" name="2" href="#2">2</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="3" href="#3">3</a><span class='fold-space'>&nbsp;</span><span class="c">/**
<a class="l" name="4" href="#4">4</a><span class='fold-space'>&nbsp;</span> * Hello again
<a class="l" name="5" href="#5">5</a><span class='fold-space'>&nbsp;</span> * Hello world!
<a class="l" name="6" href="#6">6</a><span class='fold-space'>&nbsp;</span> * Hello
<a class="l" name="7" href="#7">7</a><span class='fold-space'>&nbsp;</span> */</span>
<a class="l" name="8" href="#8">8</a><span class='fold-space'>&nbsp;</span><b>public</b> <b>class</b> <a class="xc" name="App"/><a href="/source/s?refs=App&amp;project=hellogitworld" class="xc intelliWindow-symbol" data-definition-place="def">App</a>
<a class="l" name="9" href="#9">9</a><span class='fold-space'>&nbsp;</span>&#123;
<span id='scope_id_2ead9c3' class='scope-head'><span class='scope-signature'>main( String[] args )</span><a class="hl" name="10" href="#10">10</a><a style='cursor:pointer;' onclick='fold(this.parentNode.id)' id='scope_id_2ead9c3_fold_icon'><span class='fold-icon'>&nbsp;</span></a>    <b>public</b> <b>static</b> <b>void</b> <a class="xmt" name="main"/><a href="/source/s?refs=main&amp;project=hellogitworld" class="xmt intelliWindow-symbol" data-definition-place="def">main</a>( <a href="/source/s?defs=String&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">String</a>[] <a class="xa" name="args"/><a href="/source/s?refs=args&amp;project=hellogitworld" class="xa intelliWindow-symbol" data-definition-place="def">args</a> )</span>
<span id='scope_id_2ead9c3_fold' class='scope-body'><a class="l" name="11" href="#11">11</a><span class='fold-space'>&nbsp;</span>    &#123;
<a class="l" name="12" href="#12">12</a><span class='fold-space'>&nbsp;</span>    	<span class="c">//Comment</span>
<a class="l" name="13" href="#13">13</a><span class='fold-space'>&nbsp;</span>        <a href="/source/s?defs=System&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">System</a>.<a href="/source/s?defs=out&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">out</a>.<a href="/source/s?defs=println&amp;project=hellogitworld" class="intelliWindow-symbol" data-definition-place="undefined-in-file">println</a>( <span class="s">&quot;Hello World!&quot;</span> )&#59;
<a class="l" name="14" href="#14">14</a><span class='fold-space'>&nbsp;</span>    &#125;
</span><a class="l" name="15" href="#15">15</a><span class='fold-space'>&nbsp;</span>&#125;
<a class="l" name="16" href="#16">16</a><span class='fold-space'>&nbsp;</span>
<a class="l" name="17" href="#17">17</a><span class='fold-space'>&nbsp;</span><span class="c">//foo</span>
<a class="l" name="18" href="#18">18</a><span class='fold-space'>&nbsp;</span>